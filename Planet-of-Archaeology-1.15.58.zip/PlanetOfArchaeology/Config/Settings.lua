local _, RP = ...

local AddonSettings = {}
RP:RegisterModule("Settings", AddonSettings)

local LEFT_X, RIGHT_X, CONTROL_WIDTH = 20, 330, 280

local function AddHeading(panel, text, x, y)
    local heading = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    heading:SetPoint("TOPLEFT", x, y)
    heading:SetText(text)
    heading:SetTextColor(unpack(RP.colors.gold))
    return y - 28
end

local function AddCheck(panel, text, key, x, y)
    local check = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    check:SetPoint("TOPLEFT", x, y)
    check:SetSize(26, 26)
    local label = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    label:SetPoint("LEFT", check, "RIGHT", 5, 0)
    label:SetWidth(CONTROL_WIDTH - 36)
    label:SetJustifyH("LEFT")
    label:SetWordWrap(true)
    label:SetMaxLines(2)
    label:SetText(text)
    check.key = key
    check:SetScript("OnClick", function(self)
        RP.db.settings[self.key] = self:GetChecked() and true or false
        if self.key == "dockWindows" then RP.WindowLayout:SetDocking(self:GetChecked()); return end
        if self.key == "showArrow" or self.key == "lockHUD" then
            RP.HUD:ApplySettings()
            if RP.SiteTracker then RP.SiteTracker:Refresh() end
        end
        if self.key == "showMapPins" then
            local setter = C_CVar and C_CVar.SetCVar or SetCVar
            if setter then pcall(setter, "digSites", self:GetChecked() and "1" or "0") end
        end
        if self.key == "blizzardWaypoint" and RP.RoutePlanner.currentTarget and self:GetChecked() then
            RP.Navigation:SetBlizzardWaypoint(RP.RoutePlanner.currentTarget)
        end
        if self.key == "showTracker" and RP.SiteTracker then
            RP.SiteTracker:SetShownByUser(self:GetChecked() and true or false)
        end
    end)
    panel.controls[#panel.controls + 1] = check
    return y - 38
end

local function AddCycle(panel, prefix, key, values, labels, x, y)
    local button = RP.Widgets:CreateButton(panel, "", CONTROL_WIDTH, 28)
    button:SetPoint("TOPLEFT", x, y)
    button.key, button.values, button.labels, button.prefix = key, values, labels, prefix
    if key == "language" then
        local menu = CreateFrame("Frame", nil, button, "BackdropTemplate")
        menu:SetPoint("TOPRIGHT", button, "BOTTOMRIGHT", 0, -4)
        menu:SetSize(CONTROL_WIDTH, #values * 28 + 12)
        menu:SetFrameStrata("DIALOG")
        menu:SetFrameLevel(button:GetFrameLevel() + 20)
        menu:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
        menu:SetBackdropColor(0.035, 0.03, 0.02, 1)
        menu:SetBackdropBorderColor(0.65, 0.48, 0.16, 1)
        menu:EnableMouse(true)
        for i, value in ipairs(values) do
            local choice = RP.Widgets:CreateButton(menu, labels[i], CONTROL_WIDTH - 12, 26)
            choice:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 28)
            choice:SetScript("OnClick", function()
                RP.db.settings.language = value
                menu:Hide()
                RP.Localization:Apply()
            end)
        end
        menu:Hide()
        button:SetScript("OnClick", function() menu:SetShown(not menu:IsShown()) end)
        button:SetScript("OnHide", function() menu:Hide() end)
        panel.cycles[#panel.cycles + 1] = button
        return y - 32
    end
    button:SetScript("OnClick", function(self)
        local current = RP.db.settings[self.key]
        local nextIndex = 1
        for i = 1, #self.values do
            if self.values[i] == current then nextIndex = i % #self.values + 1 end
        end
        RP.db.settings[self.key] = self.values[nextIndex]
        if self.key == "language" then RP.Localization:Apply(); return end
        self:SetText(self.prefix .. ": " .. self.labels[nextIndex])
        RP:Fire("ROUTE_SETTINGS_CHANGED")
        if self.key == "distanceUnits" then
            if RP.MainFrame then RP.MainFrame:Refresh() end
            if RP.SiteTracker then RP.SiteTracker:Refresh() end
        end
    end)
    panel.cycles[#panel.cycles + 1] = button
    return y - 32
end

local function AddStepper(panel, label, key, minimum, maximum, step, x, y)
    local labelText = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    labelText:SetPoint("TOPLEFT", x + 6, y - 3)
    labelText:SetWidth(CONTROL_WIDTH - 12)
    labelText:SetJustifyH("LEFT")
    labelText:SetWordWrap(true)
    labelText:SetText(label)
    local slider = CreateFrame("Slider", nil, panel, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", x + 6, y - 30)
    slider:SetSize(210, 18)
    slider:SetMinMaxValues(minimum * 100, maximum * 100)
    slider:SetValueStep(step * 100)
    slider:SetObeyStepOnDrag(true)
    if slider.Low then slider.Low:SetText("") end
    if slider.High then slider.High:SetText("") end
    if slider.Text then slider.Text:SetText("") end
    local valueText = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    valueText:SetPoint("LEFT", slider, "RIGHT", 8, 0)
    valueText:SetWidth(42)
    valueText:SetJustifyH("CENTER")
    local function Change(_, value)
        if slider.refreshing then return end
        RP.db.settings[key] = math.max(minimum, math.min(maximum, math.floor(value / (step * 100) + 0.5) * step))
        valueText:SetFormattedText("%d%%", math.floor(RP.db.settings[key] * 100 + 0.5))
        if key == "uiScale" or key == "uiOpacity" then
            if RP.MainFrame then RP.MainFrame:ApplySettings() end
            if RP.HUD then RP.HUD:ApplySettings() end
            if RP.SiteTracker then RP.SiteTracker:ApplySettings() end
            if RP.Proximity then RP.Proximity:ApplySettings() end
            if RP.Notifications then RP.Notifications:ApplySettings() end
            if RP.MinimapButton then RP.MinimapButton:ApplySettings() end
        elseif key == "mainScale" and RP.MainFrame then
            RP.MainFrame:ApplySettings()
        elseif key == "minimapScale" and RP.MinimapButton then
            RP.MinimapButton:ApplySettings()
        elseif key == "trackerScale" and RP.SiteTracker then
            RP.SiteTracker:ApplySettings()
        elseif RP.HUD then
            RP.HUD:ApplySettings()
        end
    end
    slider:SetScript("OnValueChanged", Change)
    panel.steppers[#panel.steppers + 1] = { key = key, text = valueText, slider = slider }
    return y - 68
end

function AddonSettings:CreatePanel()
    local panel = CreateFrame("Frame", "PlanetOfArchaeologySettingsPanel")
    panel.name = RP.L.ADDON_NAME
    panel.controls, panel.cycles, panel.steppers = {}, {}, {}

    local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalHuge")
    title:SetPoint("TOPLEFT", 18, -18)
    title:SetText(RP.L.ADDON_NAME)
    local subtitle = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -5)
    subtitle:SetText(RP.L.SUBTITLE)
    AddCycle(panel, RP.L.LANGUAGE, "language",
        {"AUTO", "enUS", "ruRU", "ukUA", "deDE", "frFR", "itIT", "esES", "esMX", "ptBR", "koKR", "zhCN", "zhTW"},
        {RP.L.LANGUAGE_AUTO, "English", "Русский", "Українська", "Deutsch", "Français", "Italiano", "Español (ES)", "Español (MX)", "Português (BR)", "한국어", "简体中文", "繁體中文"}, RIGHT_X, -24)

    local root = panel
    local pages = {}
    local function Page(label)
        local page = CreateFrame("Frame", nil, root)
        page:SetPoint("TOPLEFT", 0, -116)
        page:SetPoint("BOTTOMRIGHT", 0, 42)
        page.controls, page.cycles, page.steppers = root.controls, root.cycles, root.steppers
        local tab = RP.Widgets:CreateButton(root, label, 192, 30)
        tab:SetPoint("TOPLEFT", LEFT_X + #pages * 198, -74)
        pages[#pages + 1] = { frame = page, button = tab }
        tab:SetScript("OnClick", function()
            for _, entry in ipairs(pages) do
                entry.frame:SetShown(entry.frame == page)
                entry.button:SetAlpha(entry.frame == page and 1 or 0.65)
            end
        end)
        page:Hide()
        return page
    end
    local interface = Page(RP.L.INTERFACE)
    local navigation = Page(RP.L.NAVIGATION)
    local advanced = Page(RP.L.ADVANCED)
    interface:Show()
    for i, entry in ipairs(pages) do entry.button:SetAlpha(i == 1 and 1 or 0.65) end
    panel = navigation

    local leftY = -8
    leftY = AddHeading(panel, RP.L.NAVIGATION, LEFT_X, leftY)
    leftY = AddCheck(panel, RP.L.AUTO_NEXT, "autoNext", LEFT_X, leftY)
    leftY = AddCycle(panel, RP.L.DISTANCE_UNITS, "distanceUnits", { "AUTO", "METRIC", "IMPERIAL", "METERS", "KILOMETERS" }, { RP.L.UNITS_AUTOMATIC, RP.L.UNITS_METRIC, RP.L.UNITS_IMPERIAL, RP.L.DISTANCE_METERS, RP.L.DISTANCE_KILOMETERS }, LEFT_X, leftY)
    leftY = AddCheck(panel, RP.L.BLIZZARD_WAYPOINT, "blizzardWaypoint", LEFT_X, leftY)
    leftY = AddCheck(panel, RP.L.SHOW_ARROW, "showArrow", LEFT_X, leftY)

    panel = interface
    leftY = AddHeading(panel, RP.L.HUD, LEFT_X, -8)
    leftY = AddCheck(panel, RP.L.LOCK_HUD, "lockHUD", LEFT_X, leftY)
    leftY = AddCheck(panel, RP.L.DOCK_WINDOWS, "dockWindows", LEFT_X, leftY)
    leftY = AddStepper(panel, RP.L.HUD_SCALE, "hudScale", 0.4, 1.6, 0.05, LEFT_X, leftY)
    leftY = AddStepper(panel, RP.L.HUD_OPACITY, "hudOpacity", 0.25, 1, 0.05, LEFT_X, leftY)
    panel = advanced
    leftY = AddHeading(panel, RP.L.ADVANCED, LEFT_X, -8)
    leftY = AddCheck(panel, RP.L.DEBUG, "debug", LEFT_X, leftY)

    local reset = RP.Widgets:CreateButton(panel, RP.L.RESET_POSITION, 230, 30)
    reset:SetPoint("TOPLEFT", LEFT_X, leftY - 2)
    reset:SetScript("OnClick", function() RP.Database:ResetPositions() end)
    local resetDB = RP.Widgets:CreateButton(panel, RP.L.RESET_DATABASE, 230, 30)
    resetDB:SetPoint("TOPLEFT", LEFT_X, leftY - 38)
    resetDB:SetScript("OnClick", function() StaticPopup_Show("PLANETOFARCHAEOLOGY_RESET_DATABASE") end)

    panel = navigation
    local rightY = -8
    rightY = AddHeading(panel, RP.L.EXPEDITION, RIGHT_X, rightY)
    rightY = AddCheck(panel, RP.L.SHOW_TRACKER, "showTracker", RIGHT_X, rightY)
    rightY = AddCheck(panel, RP.L.NOTIFICATIONS, "notifications", RIGHT_X, rightY)
    rightY = AddCheck(panel, RP.L.TARGET_ALERTS, "targetAlerts", RIGHT_X, rightY)
    rightY = AddCheck(panel, RP.L.SOUNDS, "sounds", RIGHT_X, rightY)
    rightY = AddHeading(panel, RP.L.MAP, RIGHT_X, rightY - 10)
    rightY = AddCheck(panel, RP.L.SHOW_MAP_PINS, "showMapPins", RIGHT_X, rightY)
    panel = interface
    leftY = AddStepper(panel, RP.L.TRACKER_SCALE, "trackerScale", 0.4, 1.6, 0.05, LEFT_X, -252)
    local resetInterface = RP.Widgets:CreateButton(panel, RP.L.RESET_INTERFACE, CONTROL_WIDTH, 30)
    resetInterface:SetPoint("TOPLEFT", LEFT_X, -334)
    resetInterface:SetScript("OnClick", function() RP.Database:ResetInterface(); self:RefreshPanel() end)
    rightY = AddHeading(panel, RP.L.INTERFACE, RIGHT_X, -8)
    rightY = AddStepper(panel, RP.L.MAIN_WINDOW_SCALE, "mainScale", 0.4, 1.35, 0.05, RIGHT_X, rightY)
    rightY = AddStepper(panel, RP.L.INTERFACE_SCALE, "uiScale", 0.4, 2.00, 0.05, RIGHT_X, rightY)
    rightY = AddStepper(panel, RP.L.INTERFACE_OPACITY, "uiOpacity", 0.35, 1, 0.05, RIGHT_X, rightY)
    rightY = AddStepper(panel, RP.L.MINIMAP_BUTTON_SCALE, "minimapScale", 0.4, 1.6, 0.05, RIGHT_X, rightY)

    panel = root
    local note = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    note:SetPoint("BOTTOMLEFT", LEFT_X, 14)
    note:SetWidth(600)
    note:SetJustifyH("CENTER")
    note:SetWordWrap(true)
    note:SetMaxLines(2)
    note:SetText(RP.L.RACE_DISCOVERY_NOTE)

    panel:SetScript("OnShow", function() self:RefreshPanel() end)
    self.panel = panel
end

function AddonSettings:RefreshPanel()
    local panel = self.panel
    if not panel or not RP.db then return end
    for i = 1, #panel.controls do
        panel.controls[i]:SetChecked(RP.db.settings[panel.controls[i].key])
    end
    for i = 1, #panel.cycles do
        local control = panel.cycles[i]
        local label = tostring(RP.db.settings[control.key])
        for j = 1, #control.values do
            if control.values[j] == RP.db.settings[control.key] then label = control.labels[j] end
        end
        control:SetText(control.prefix .. ": " .. label .. (control.key == "language" and "  v" or ""))
    end
    for i = 1, #panel.steppers do
        local control = panel.steppers[i]
        control.slider.refreshing = true
        control.slider:SetValue((RP.db.settings[control.key] or 1) * 100)
        control.slider.refreshing = nil
        control.text:SetFormattedText("%d%%", math.floor((RP.db.settings[control.key] or 1) * 100 + 0.5))
    end
end

function AddonSettings:OnLogin()
    StaticPopupDialogs.PLANETOFARCHAEOLOGY_RESET_DATABASE = {
        text = RP.L.RESET_DATABASE .. "?",
        button1 = YES,
        button2 = NO,
        OnAccept = function()
            RP.Database:ResetAll()
            RP:Print(RP.L.DATABASE_RESET)
            ReloadUI()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }
    self:CreatePanel()
    local cvarSetter = C_CVar and C_CVar.SetCVar or SetCVar
    if cvarSetter then pcall(cvarSetter, "digSites", RP.db.settings.showMapPins and "1" or "0") end
    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        local category = Settings.RegisterCanvasLayoutCategory(self.panel, RP.L.ADDON_NAME)
        Settings.RegisterAddOnCategory(category)
        self.category = category
        self.categoryID = category:GetID()
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(self.panel)
    end
end
