local _, RP = ...
local Achievements = { dirty = true, entries = {} }
RP:RegisterModule("Achievements", Achievements)

-- Content groups, not ID/patch heuristics. Unknown future entries remain visible.
-- Reference: https://www.wowdb.com/achievements/character/professions/archaeology
local expansionByID = {}
local function Group(key, ids)
    for _, id in ipairs(ids) do expansionByID[id] = key end
end
Group("cata", {4858,4859,5191,5192,5193,5194})
Group("mop", {6837,7612})
for id = 7331, 7378 do expansionByID[id] = "mop" end
for id = 8219, 8235 do expansionByID[id] = "mop" end
Group("wod", {9409,9410,9411,9412,9413,9414,9415,9419})
Group("legion", {10600,10601,10602,10603,10604,10605,10606,10607,10608,10609})
Group("bfa", {12760,12761,12762,12763,12764,12765})
function Achievements:GetExpansion(id)
    return expansionByID[id] or "general"
end

function Achievements:GetEntries()
    if not self.dirty then return self.entries end
    self.entries = {}
    if not GetCategoryList or not GetAchievementInfo then return self.entries end
    -- Resolve the category in the client's language, independently of addon language.
    local name = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(78670)
    if not name and GetSpellInfo then name = GetSpellInfo(78670) end
    if not name then return self.entries end
    local categories, included = GetCategoryList() or {}, {}
    for _, id in ipairs(categories) do
        local categoryName = GetCategoryInfo(id)
        if categoryName == name then included[id] = true end
    end
    local changed = true
    while changed do
        changed = false
        for _, id in ipairs(categories) do
            local _, parent = GetCategoryInfo(id)
            if included[parent] and not included[id] then included[id] = true; changed = true end
        end
    end
    if not next(included) then return self.entries end
    local seen = {}
    local function Add(id)
        if not id or seen[id] then return end
        seen[id] = true
        local actual, title, points, completed, month, day, year, description, flags, icon, reward, _, earnedByMe, earnedBy = GetAchievementInfo(id)
        if not actual or not title then return end
        self.entries[#self.entries + 1] = { id = actual, name = title, points = points or 0,
            completed = completed and true or false, description = description or "", icon = icon,
            month = month, day = day, year = year, reward = reward or "",
            earnedByMe = earnedByMe, earnedBy = earnedBy }
        -- Category rows can represent just one visible tier. Include the whole chain.
        if GetPreviousAchievement then Add(GetPreviousAchievement(id)) end
        if GetNextAchievement then Add(GetNextAchievement(id)) end
    end
    for category in pairs(included) do
        local count = GetCategoryNumAchievements(category, true) or 0
        for i = 1, count do Add(GetAchievementInfo(category, i)) end
    end
    table.sort(self.entries, function(a, b)
        if a.completed ~= b.completed then return not a.completed end
        if a.name == b.name then return a.id < b.id end
        return a.name < b.name
    end)
    self.dirty = #self.entries == 0
    return self.entries
end

function Achievements:IsWished(id)
    return RP.db.achievementWishes and RP.db.achievementWishes[id] == true
end

function Achievements:ToggleWish(id)
    RP.db.achievementWishes = RP.db.achievementWishes or {}
    RP.db.achievementWishes[id] = not self:IsWished(id) or nil
end

function Achievements:IsTracked(id)
    if C_ContentTracking and C_ContentTracking.GetTrackedIDs and Enum and Enum.ContentTrackingType then
        for _, trackedID in ipairs(C_ContentTracking.GetTrackedIDs(Enum.ContentTrackingType.Achievement) or {}) do
            if trackedID == id then return true end
        end
        return false
    end
    return C_ContentTracking and Enum and Enum.ContentTrackingType
        and C_ContentTracking.IsTracking(Enum.ContentTrackingType.Achievement, id) or false
end

function Achievements:RefreshNativeTracker(expand)
    local tracker = AchievementObjectiveTracker
    if not tracker and C_AddOns and C_AddOns.LoadAddOn then
        pcall(C_AddOns.LoadAddOn, "Blizzard_ObjectiveTracker")
        tracker = AchievementObjectiveTracker
    end
    if tracker then
        if expand and tracker.ForceExpand then tracker:ForceExpand() end
        if tracker.MarkDirty then tracker:MarkDirty() end
    end
end

function Achievements:ToggleTracking(id)
    if not C_ContentTracking or not Enum or not Enum.ContentTrackingType then
        RP:Print(RP.L.ACH_TRACK_ERROR); return
    end
    local ok, err
    local removing = self:IsTracked(id)
    if removing then
        ok, err = pcall(C_ContentTracking.StopTracking, Enum.ContentTrackingType.Achievement, id, Enum.ContentTrackingStopType.Manual)
    else
        local maximum = Constants and Constants.ContentTrackingConsts and Constants.ContentTrackingConsts.MaxTrackedAchievements
        if maximum and C_ContentTracking.GetTrackedIDs and #C_ContentTracking.GetTrackedIDs(Enum.ContentTrackingType.Achievement) >= maximum then
            RP:Print(RP.L.ACH_TRACK_ERROR); return
        end
        ok, err = pcall(C_ContentTracking.StartTracking, Enum.ContentTrackingType.Achievement, id)
    end
    if not ok or err then
        if ok and ContentTrackingUtil and ContentTrackingUtil.DisplayTrackingError then ContentTrackingUtil.DisplayTrackingError(err)
        else RP:Print(RP.L.ACH_TRACK_ERROR) end
        return
    end
    -- Use the same native list as the objective tracker, then refresh its layout.
    self:RefreshNativeTracker(not removing)
    C_Timer.After(0.1, function()
        local tracked = self:IsTracked(id)
        if tracked == removing then RP:Print(RP.L.ACH_TRACK_ERROR) end
        self:RefreshNativeTracker(tracked and not removing)
        self.criteriaRevision = (self.criteriaRevision or 0) + 1
        local page = RP.AchievementsPage
        if page and page.frame and page.frame:IsVisible() then page:Refresh() end
    end)
end

function Achievements:GetCriteria(id)
    local rows, completed = {}, 0
    local count = GetAchievementNumCriteria and GetAchievementNumCriteria(id) or 0
    for i = 1, count do
        local name, _, done, quantity, required = GetAchievementCriteriaInfo(id, i)
        if name and name ~= "" then
            required = type(required) == "number" and math.max(1, required) or 1
            quantity = done and required or (type(quantity) == "number" and math.max(0, math.min(required, quantity)) or 0)
            rows[#rows + 1] = {name = name, done = done and true or false, quantity = quantity, required = required, order = i}
            if done then completed = completed + 1 end
        end
    end
    table.sort(rows, function(a, b)
        if a.done ~= b.done then return not a.done end
        return a.order < b.order
    end)
    return rows, completed
end

function Achievements:GetDetails(entry, omitCriteria)
    local text = RP.ContentLocalization:Get("achievement", entry.id, entry.description)
    local reward = RP.ContentLocalization:AchievementReward(entry.id, entry.reward)
    if reward ~= "" then text = text .. "\n\n" .. RP.L.ACH_REWARD .. "\n" .. reward end
    if entry.completed and entry.month and entry.day and entry.year then
        local year = entry.year < 100 and entry.year + 2000 or entry.year
        text = text .. "\n\n" .. RP.L.ACH_EARNED .. " " .. string.format("%02d.%02d.%04d", entry.day, entry.month, year)
        if entry.earnedBy and entry.earnedBy ~= "" then text = text .. " • " .. entry.earnedBy end
    end
    if omitCriteria then return text end
    local count = GetAchievementNumCriteria and GetAchievementNumCriteria(entry.id) or 0
    if count > 0 then text = text .. "\n\n" .. RP.L.ACH_CRITERIA end
    for i = 1, count do
        local label, _, done, quantity, required, _, _, _, quantityString = GetAchievementCriteriaInfo(entry.id, i)
        if label and label ~= "" then
            local progress = ""
            if not done and type(required) == "number" and required > 1 then
                progress = " — " .. (quantityString and quantityString ~= "" and quantityString
                    or string.format("%s / %s", tostring(quantity or 0), tostring(required)))
            end
            text = text .. "\n" .. (done and "|cFF76C777" or "|cFFD1C5AA") .. "• " .. RP.ContentLocalization:Criterion(entry.id, i, label) .. progress .. "|r"
        end
    end
    return text
end

function Achievements:OnInitialize()
    local driver = CreateFrame("Frame")
    for _, event in ipairs({"ACHIEVEMENT_EARNED", "CRITERIA_UPDATE", "PLAYER_ENTERING_WORLD", "CONTENT_TRACKING_UPDATE"}) do driver:RegisterEvent(event) end
    driver:SetScript("OnEvent", function(_, event)
        if event == "ACHIEVEMENT_EARNED" or event == "PLAYER_ENTERING_WORLD" then self.dirty = true end
        self.criteriaRevision = (self.criteriaRevision or 0) + 1
        local page = RP.AchievementsPage
        if not page or not page.frame or not page.frame:IsVisible() then return end
        if self.pending then return end
        self.pending = true
        C_Timer.After(1, function()
            self.pending = nil
            if RP.AchievementsPage and RP.AchievementsPage.frame and RP.AchievementsPage.frame:IsVisible() then RP.AchievementsPage:Refresh() end
        end)
    end)
end
