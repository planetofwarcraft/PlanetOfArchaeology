local _, RP = ...

-- Proximity no longer owns a popup. It quietly detects the active dig-site
-- polygon and hands control to the compact secure Survey button.
local Proximity = { elapsed = 0, refreshElapsed = 0 }
RP:RegisterModule("Proximity", Proximity)

function Proximity:HidePrompt()
    -- Compatibility shim for older settings callbacks and saved layouts.
    if self.frame then self.frame:Hide() end
end

function Proximity:OnUpdate(elapsed)
    self.elapsed = self.elapsed + elapsed
    if self.elapsed < 0.5 then return end
    self.elapsed = 0

    if not RP.db or not RP.DigSites or not RP.Expedition then return end
    self.refreshElapsed = self.refreshElapsed + 0.5
    if #RP.DigSites.sites == 0 and self.refreshElapsed >= 15 then
        self.refreshElapsed = 0
        RP.DigSites:Refresh("proximity")
    else
        RP.DigSites:UpdateDistances()
    end

    local current = RP.DigSites:GetCurrentSite()
    if RP.MinimapButton then RP.MinimapButton:SetNearby(current ~= nil) end

    if RP.db.expedition.active and current then
        if not RP.Expedition:IsDigging(current) then
            RP.Expedition:BeginDigging(current)
        end
    elseif RP.Expedition:IsDigging() then
        RP.Expedition:EndDigging()
    end
end

function Proximity:OnInitialize()
    self.driver = CreateFrame("Frame")
    self.driver:SetScript("OnUpdate", function(_, elapsed) self:OnUpdate(elapsed) end)
    RP:On("EXPEDITION_CHANGED", self, function(_, active)
        if not active and RP.Expedition:IsDigging() then RP.Expedition:EndDigging() end
        if not active and RP.MinimapButton then RP.MinimapButton:SetNearby(false) end
    end)
end

function Proximity:ApplySettings()
end
