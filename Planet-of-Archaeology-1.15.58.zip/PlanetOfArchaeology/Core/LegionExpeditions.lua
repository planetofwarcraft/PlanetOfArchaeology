local _, RP = ...
local Legion = { requested = {} }
RP:RegisterModule("LegionExpeditions", Legion)

function Legion:Calculate(now, region, weeklyReset)
    local data = RP.SpecialExpeditionData.legion
    local anchor = data.anchors[region]
    if not anchor or not now then return nil end
    -- Snap the supplied UTC reference day to the live weekly reset phase.
    -- Modulo chooses the reset within +/- 3.5 days, never the user's OS timezone.
    if weeklyReset then
        local week = 7 * 86400
        anchor = anchor + ((weeklyReset - anchor + week / 2) % week - week / 2)
    end
    local slot = math.floor((now - anchor) / data.period)
    local index = (slot + 12) % 13 + 1
    local starts = anchor + slot * data.period
    return { index = index, nextIndex = index % 13 + 1, starts = starts,
        ends = starts + data.period, now = now, estimated = weeklyReset == nil, region = region }
end

function Legion:GetRotation()
    local now = GetServerTime and GetServerTime()
    local region = GetCurrentRegion and GetCurrentRegion()
    local reset
    if now and C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset then
        local seconds = C_DateAndTime.GetSecondsUntilWeeklyReset()
        if seconds and seconds >= 0 and seconds <= 7 * 86400 then reset = now + seconds end
    end
    return self:Calculate(now, region, reset)
end

function Legion:GetNextStart(index, rotation)
    local offset = (index - rotation.index) % 13
    if offset == 0 then offset = 13 end
    return rotation.starts + offset * RP.SpecialExpeditionData.legion.period
end

function Legion:Duration(seconds)
    local minutes = math.max(0, math.ceil(seconds / 60))
    if minutes >= 1440 then return RP.L.LEGION_DAYS:format(math.floor(minutes / 1440), math.floor(minutes / 60) % 24) end
    if minutes >= 60 then return RP.L.LEGION_HOURS:format(math.floor(minutes / 60), minutes % 60) end
    return RP.L.LEGION_MINUTES:format(minutes)
end

function Legion:Date(timestamp)
    if C_DateAndTime and C_DateAndTime.GetCurrentCalendarTime and C_DateAndTime.AdjustTimeByMinutes then
        local now = GetServerTime()
        local current = C_DateAndTime.GetCurrentCalendarTime()
        local calendar = C_DateAndTime.AdjustTimeByMinutes(current, math.floor(timestamp / 60) - math.floor(now / 60))
        return string.format("%02d.%02d.%04d %02d:%02d", calendar.monthDay, calendar.month, calendar.year, calendar.hour, calendar.minute)
            .. " • " .. RP.L.SERVER_TIME .. " (" .. (GetRealmName() or "") .. ")"
    end
    return date("!%d.%m.%Y %H:%M", timestamp) .. " UTC"
end

function Legion:GetInfo(entry)
    if not self.requested["quest" .. entry.questID] and C_QuestLog.RequestLoadQuestByID then
        self.requested["quest" .. entry.questID] = true
        C_QuestLog.RequestLoadQuestByID(entry.questID)
    end
    local name, _, _, _, _, _, _, _, _, icon = C_Item.GetItemInfo(entry.itemID)
    if not name and not self.requested[entry.itemID] then
        self.requested[entry.itemID] = true
        C_Item.RequestLoadItemDataByID(entry.itemID)
    end
    local race = RP.Archaeology:GetRace(entry.raceIndex)
    local chain = C_QuestLine and C_QuestLine.GetQuestLineQuests(entry.lineID) or {}
    chain = chain or {}
    local activeQuest
    for _, id in ipairs(chain) do if C_QuestLog.IsOnQuest(id) then activeQuest = id; break end end
    if not activeQuest and C_QuestLog.IsOnQuest(entry.questID) then activeQuest = entry.questID end
    local finalQuest = #chain > 1 and chain[#chain] or nil
    local completed = finalQuest and (C_QuestLog.IsQuestFlaggedCompleted(finalQuest)
        or (C_QuestLog.IsQuestFlaggedCompletedOnAccount and C_QuestLog.IsQuestFlaggedCompletedOnAccount(finalQuest)))
    if C_QuestLine and C_QuestLine.IsComplete and C_QuestLine.IsComplete(entry.lineID) then completed = true end
    local objectives = activeQuest and C_QuestLog.GetQuestObjectives(activeQuest) or {}
    local progress = {}
    for _, objective in ipairs(objectives or {}) do
        if objective.text and objective.text ~= "" then progress[#progress + 1] = objective.text end
    end
    local kind = entry.kind or "item"
    if C_ToyBox and C_ToyBox.GetToyInfo and C_ToyBox.GetToyInfo(entry.itemID) then kind = "toy" end
    local zone
    if activeQuest and C_QuestLog.GetNextWaypoint then
        local mapID = C_QuestLog.GetNextWaypoint(activeQuest)
        local map = mapID and C_Map.GetMapInfo(mapID)
        zone = map and map.name
    end
    return { name = RP.Localization:DisplayName(name or entry.name, entry.itemID), icon = icon or C_Item.GetItemIconByID(entry.itemID) or "Interface\\Icons\\Trade_Archaeology", zone = zone,
        race = race and RP.Localization:DisplayName(race.name) or RP.L.UNKNOWN_RACE, kind = RP.L["LEGION_KIND_" .. kind],
        completed = completed and true or false, known = finalQuest ~= nil, activeQuest = activeQuest,
        progress = table.concat(progress, "\n"), questName = C_QuestLog.GetTitleForQuestID(entry.questID) or ("Quest " .. entry.questID) }
end

function Legion:GetRewardDescription(entry, nativeOnly)
    if not nativeOnly then
        local translated = RP.ContentLocalization:Get("reward", entry.itemID)
        if translated then return translated end
    end
    local types = Enum and Enum.TooltipDataLineType
    if C_TooltipInfo and C_TooltipInfo.GetItemByID and types then
        local ok, tooltip = pcall(C_TooltipInfo.GetItemByID, entry.itemID)
        local lines = {}
        if ok and tooltip then
            for _, line in ipairs(tooltip.lines or {}) do
                if line.leftText and line.leftText ~= "" and
                    (line.type == types.ItemSpellTriggerOnUse or line.type == types.ItemSpellTriggerLearn
                    or line.type == types.ItemSpellTriggerOnEquip or line.type == types.ItemSpellTriggerOnProc) then
                    lines[#lines + 1] = line.leftText
                end
            end
        end
        if #lines > 0 then return table.concat(lines, "\n") end
    end
    if C_Item and C_Item.GetItemSpell and C_Spell and C_Spell.GetSpellDescription then
        local _, spellID = C_Item.GetItemSpell(entry.itemID)
        local description = spellID and C_Spell.GetSpellDescription(spellID)
        if description and description ~= "" then return description end
        if spellID and C_Spell.RequestLoadSpellData and not self.requested["spell" .. spellID] then
            self.requested["spell" .. spellID] = true
            C_Spell.RequestLoadSpellData(spellID)
        end
    end
    return RP.L.ARCHIVE_NO_DESCRIPTION
end

function Legion:Navigate(entry)
    local info = self:GetInfo(entry)
    if info.activeQuest then
        local mapID, x, y = C_QuestLog.GetNextWaypoint(info.activeQuest)
        if mapID and x and y and x >= 0 and x <= 1 and y >= 0 and y <= 1 then
            return self:Waypoint(mapID, x, y)
        end
        if C_SuperTrack and C_SuperTrack.SetSuperTrackedQuestID then C_SuperTrack.SetSuperTrackedQuestID(info.activeQuest) end
        RP:Print(RP.L.LEGION_NO_COORDS)
        return
    end
    local contact = RP.SpecialExpeditionData.legion.contact
    self:Waypoint(contact.mapID, contact.x, contact.y)
end

function Legion:Waypoint(mapID, x, y)
    local site = { mapID = mapID, position = CreateVector2D(x, y) }
    local success = RP.Navigation:SetBlizzardWaypoint(site, true)
    if RP.MainFrame and RP.MainFrame.frame then RP.MainFrame.frame:Hide() end
    local owned = RP.Navigation.ownedWaypoint
    if C_Map and C_Map.OpenWorldMap then C_Map.OpenWorldMap(success and owned and owned.uiMapID or mapID) end
    if not success then
        RP:Print(RP.L.LEGION_MAP_FALLBACK:format(x * 100, y * 100))
    end
    return success
end

function Legion:PrepareCalendar(index)
    local rotation = self:GetRotation()
    local entry = RP.SpecialExpeditionData.legion.entries[index]
    if not rotation or not entry or InCombatLockdown() then return end
    if C_AddOns and C_AddOns.LoadAddOn then C_AddOns.LoadAddOn("Blizzard_Calendar") end
    if not CalendarFrame or not CalendarDayContextMenu_CreateEvent or not C_DateAndTime.AdjustTimeByMinutes then
        RP:Print(RP.L.CALENDAR_UNAVAILABLE); return
    end
    -- Do not overwrite another unsaved calendar draft.
    if CalendarCreateEventFrame and CalendarCreateEventFrame:IsShown() then
        RP:Print(RP.L.CALENDAR_BUSY); return
    end
    local start = index == rotation.index and rotation.now + 300 or self:GetNextStart(index, rotation)
    local when = C_DateAndTime.AdjustTimeByMinutes(C_DateAndTime.GetCurrentCalendarTime(), math.ceil((start - rotation.now) / 60))
    if RP.MainFrame and RP.MainFrame.frame then RP.MainFrame.frame:Hide() end
    ShowUIPanel(CalendarFrame)
    C_Calendar.SetAbsMonth(when.month, when.year)
    CalendarFrame_Update()
    local dayButton
    for i = 1, 42 do
        local button = _G["CalendarDayButton" .. i]
        if button and button.monthOffset == 0 and button.day == when.monthDay then dayButton = button; break end
    end
    if not dayButton or not C_Calendar.CanAddEvent() then RP:Print(RP.L.CALENDAR_UNAVAILABLE); return end
    CalendarDayContextMenu_CreateEvent(dayButton)
    local info = self:GetInfo(entry)
    local title = "PlanetOfArchaeology: " .. info.name
    local description = RP.L.CALENDAR_DESCRIPTION .. "\n" .. info.name .. "\n" .. self:Date(start) .. "\n" .. RP.L.LEGION_CONTACT
    CalendarCreateEventTitleEdit:SetText(title)
    CalendarCreateEventDescriptionContainer.ScrollingEditBox:SetText(description)
    C_Calendar.EventSetTitle(title)
    C_Calendar.EventSetDescription(description)
    local hour = when.hour
    CalendarCreateEventFrame.selectedMinute = when.minute
    CalendarCreateEventFrame.selectedAM = hour < 12
    CalendarCreateEventFrame.selectedHour = CalendarFrame.militaryTime and hour or ((hour + 11) % 12 + 1)
    CalendarCreateEvent_UpdateEventTime()
    C_Calendar.EventSetTime(hour, when.minute)
    RP:Print(RP.L.CALENDAR_CONFIRM)
end

function Legion:Notify()
    RP:Fire("SPECIAL_EXPEDITIONS_UPDATED")
    if RP.loggedIn then self:CheckWishes() end
end

function Legion:IsWanted(entry)
    return RP.db and RP.db.legionWishes[tostring(entry.itemID)] == true
end

function Legion:ToggleWish(entry)
    local key = tostring(entry.itemID)
    RP.db.legionWishes[key] = not RP.db.legionWishes[key] or nil
    self:Notify()
end

function Legion:CheckWishes()
    if not RP.db or not RP.db.settings.notifications then return end
    local rotation = self:GetRotation()
    if not rotation then return end
    local entry = RP.SpecialExpeditionData.legion.entries[rotation.index]
    if not self:IsWanted(entry) then return end
    local key = tostring(entry.itemID)
    -- One reminder per availability window, including across /reload and logins.
    local cycle = math.floor(rotation.starts / 86400)
    if RP.db.legionWishNotified[key] == cycle then return end
    local info = self:GetInfo(entry)
    if info.completed or not RP.Notifications or not RP.Notifications.frame then return end
    RP.Notifications:Show(RP.L.WISH_AVAILABLE, info.name, nil, info.icon)
    RP.db.legionWishNotified[key] = cycle
end

function Legion:OnInitialize()
    local frame = CreateFrame("Frame")
    for _, event in ipairs({ "PLAYER_ENTERING_WORLD", "QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_LOG_UPDATE",
        "ACHIEVEMENT_EARNED", "ITEM_DATA_LOAD_RESULT", "QUEST_DATA_LOAD_RESULT", "SPELL_DATA_LOAD_RESULT" }) do frame:RegisterEvent(event) end
    frame:SetScript("OnEvent", function()
        if self.pending then return end
        self.pending = true
        C_Timer.After(0.3, function() self.pending = nil; self:Notify() end)
    end)
end

function Legion:OnLogin()
    self:Notify()
    C_Timer.After(3, function() self:CheckWishes() end)
    self.wishTimer = C_Timer.NewTicker(60, function() self:CheckWishes() end)
end
