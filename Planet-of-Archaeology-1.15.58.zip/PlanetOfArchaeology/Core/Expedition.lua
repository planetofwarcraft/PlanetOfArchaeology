local _, RP = ...

local Expedition = { diggingSiteID = nil }
RP:RegisterModule("Expedition", Expedition)

function Expedition:Start(preferredSite)
    if RP.db.expedition.active then return end
    self.diggingSiteID = nil
    RP.db.expedition.active = true
    RP.db.expedition.startedAt = time()
    RP.DigSites:Refresh("expedition-start")
    local currentSite = RP.DigSites:GetCurrentSite()
    if preferredSite and not currentSite then
        currentSite = RP.DigSites:GetSiteByID(preferredSite.researchSiteID)
    end
    local target
    if currentSite then
        target = RP.RoutePlanner:SetTarget(currentSite, RP.L.START_HERE)
    else
        target = RP.RoutePlanner:SelectNext()
    end
    if not target and RP.Notifications then
        local sound = SOUNDKIT and SOUNDKIT.IG_QUEST_LOG_OPEN
        RP.Notifications:Show(RP.L.EXPEDITION, RP.L.NO_MATCHING, sound)
    end
    -- Starting a new expedition is an explicit request to open its route window.
    -- Closing the tracker may have persisted showTracker=false from an earlier run.
    RP.db.settings.showTracker = true
    if RP.MainFrame and RP.MainFrame.frame then RP.MainFrame.frame:Hide() end
    RP:Fire("EXPEDITION_CHANGED", true)
end

function Expedition:BeginDigging(site)
    if not site then site = RP.DigSites:GetCurrentSite() or RP.DigSites:GetNearestSite() end
    if not site then return false end
    if not RP.db.expedition.active then self:Start(site) end
    if self:IsDigging(site) then
        if RP.HUD then RP.HUD:Show() end
        return true
    end
    self.diggingSiteID = site.researchSiteID
    RP.RoutePlanner:SetTarget(site, RP.L.START_DIGGING)
    if RP.HUD then RP.HUD:Show() end
    RP:Fire("DIGGING_CHANGED", true, site)
    return true
end

function Expedition:EndDigging()
    if not self.diggingSiteID then return end
    local siteID = self.diggingSiteID
    self.diggingSiteID = nil
    if RP.HUD then RP.HUD:Refresh() end
    RP:Fire("DIGGING_CHANGED", false, siteID)
end

function Expedition:IsDigging(site)
    if not self.diggingSiteID then return false end
    return not site or self.diggingSiteID == site.researchSiteID
end

function Expedition:Stop()
    if not RP.db.expedition.active then return end
    self:EndDigging()
    local started = RP.db.expedition.startedAt
    if started then
        RP.db.stats.totalExpeditionSeconds = (RP.db.stats.totalExpeditionSeconds or 0) + math.max(0, time() - started)
    end
    RP.db.expedition.active = false
    RP.db.expedition.startedAt = nil
    RP.Navigation:ClearTarget(true)
    RP.RoutePlanner.currentTarget = nil
    if RP.HUD then RP.HUD:Hide() end
    RP:Fire("EXPEDITION_CHANGED", false)
end

function Expedition:Toggle()
    if RP.db.expedition.active then self:Stop() else self:Start() end
end

function Expedition:GetCurrentDuration()
    if RP.db.expedition.active and RP.db.expedition.startedAt then
        return math.max(0, time() - RP.db.expedition.startedAt)
    end
    return 0
end

function Expedition:OnLogin()
    -- Do not count offline time as expedition time.
    self.diggingSiteID = nil
    if RP.db.expedition.active then
        RP.db.expedition.startedAt = time()
        C_Timer.After(1.2, function()
            RP.RoutePlanner:SelectNext("reload")
            if RP.HUD then RP.HUD:Refresh() end
        end)
    end
end
