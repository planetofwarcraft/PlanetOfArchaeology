local _, RP = ...

local Archaeology = { races = {}, artifactsByName = {}, archive = {}, archiveStats = {}, artifactItemRequests = {} }
RP:RegisterModule("Archaeology", Archaeology)

local continentBranches = {
    [12] = { 7, 8, 4, 3, 1 },
    [13] = { 7, 8, 4, 3, 1, 5 },
    [101] = { 6, 2 },
    [113] = { 27, 5, 4, 8 },
    [424] = { 231, 229, 29 },
    [572] = { 382, 350, 315 },
    [619] = { 408, 406, 404 },
    [876] = { 424, 423 },
    [875] = { 423, 424 },
}

function Archaeology:IsAvailable()
    return type(GetNumArchaeologyRaces) == "function" and type(GetArchaeologyRaceInfo) == "function"
end

function Archaeology:Refresh()
    wipe(self.races)
    wipe(self.artifactsByName)
    if not self:IsAvailable() then
        RP:Fire("ARCHAEOLOGY_UPDATED", self.races)
        return self.races
    end

    local ok, count = pcall(GetNumArchaeologyRaces)
    if not ok or type(count) ~= "number" then count = 0 end

    for raceIndex = 1, count do
        local infoOK, name, texture, keystoneItemID, fragments, required, maximum = pcall(GetArchaeologyRaceInfo, raceIndex, false)
        if infoOK and name and name ~= UNKNOWN then
            local race = {
                index = raceIndex,
                name = name,
                texture = texture,
                keystoneItemID = keystoneItemID,
                fragments = tonumber(fragments) or 0,
                required = tonumber(required) or 0,
                maximum = tonumber(maximum) or 0,
            }

            if type(GetActiveArtifactByRace) == "function" then
                local artifactOK, artifactName, description, rarity, icon, hoverDescription, numSockets, background = pcall(GetActiveArtifactByRace, raceIndex)
                if artifactOK and artifactName then
                    race.artifact = {
                        name = artifactName,
                        description = description,
                        rarity = tonumber(rarity) or 0,
                        icon = icon,
                        hoverDescription = hoverDescription,
                        numSockets = tonumber(numSockets) or 0,
                        background = background,
                    }
                    self.artifactsByName[artifactName] = race.artifact.rarity
                end
            end

            if keystoneItemID and keystoneItemID > 0 then
                if C_Item and C_Item.GetItemCount then
                    local itemOK, amount = pcall(C_Item.GetItemCount, keystoneItemID, false, false, false)
                    race.keystones = itemOK and tonumber(amount) or 0
                elseif GetItemCount then
                    local itemOK, amount = pcall(GetItemCount, keystoneItemID)
                    race.keystones = itemOK and tonumber(amount) or 0
                end
            else
                race.keystones = 0
            end

            race.canSolve = race.required > 0 and race.fragments >= race.required
            self.races[#self.races + 1] = race
        end
    end

    RP:Fire("ARCHAEOLOGY_UPDATED", self.races)
    return self.races
end

function Archaeology:GetRace(raceIndex)
    raceIndex = tonumber(raceIndex)
    for i = 1, #self.races do
        if self.races[i].index == raceIndex then return self.races[i] end
    end
end

function Archaeology:GetRaceByBranchID(branchID)
    if not branchID or type(GetArchaeologyRaceInfoByID) ~= "function" then return nil end
    local ok, branchName, texture = pcall(GetArchaeologyRaceInfoByID, branchID)
    if not ok or not branchName then return nil end
    for i = 1, #self.races do
        local race = self.races[i]
        if race.name == branchName or (texture and race.texture == texture) then
            race.branchID = branchID
            return race
        end
    end
    return { branchID = branchID, name = branchName, texture = texture }
end

function Archaeology:RefreshArchive()
    wipe(self.archive)
    self.archiveStats = { total = 0, obtained = 0, missing = 0, rare = 0, available = true }

    local historyAvailable = type(GetArtifactInfoByRace) == "function"
    if historyAvailable and type(IsArtifactCompletionHistoryAvailable) == "function" then
        local historyOK, available = pcall(IsArtifactCompletionHistoryAvailable)
        historyAvailable = historyOK and available and true or false
    end
    self.archiveStats.available = historyAvailable

    local liveByRace = {}
    if historyAvailable then
        for i = 1, #self.races do
            local race = self.races[i]
            local entries = {}
            local projectIndex = 1
            while projectIndex <= 500 do
                local ok, name, description, rarity, icon, spellDescription, numSockets, background,
                    spellID, firstCompletionTime, completionCount = pcall(GetArtifactInfoByRace, race.index, projectIndex)
                if not ok or not name then break end
                local lore = tonumber(rarity) == 0 and spellDescription or description
                if not lore or lore == "" then lore = description or spellDescription or "" end
                entries[#entries + 1] = {
                    projectIndex = projectIndex,
                    name = name,
                    description = lore,
                    spellDescription = spellDescription,
                    rarity = tonumber(rarity) or 0,
                    icon = icon,
                    spellID = spellID,
                    numSockets = tonumber(numSockets) or 0,
                    background = background,
                    firstCompletionTime = tonumber(firstCompletionTime),
                    completionCount = tonumber(completionCount) or 0,
                }
                projectIndex = projectIndex + 1
            end
            liveByRace[race.index] = entries
        end
    end

    local function NormalizeName(value)
        if type(value) ~= "string" then return nil end
        return value:lower():gsub("[%s%p%c]", "")
    end

    local function FindLive(entries, used, localizedName, englishName, icon)
        local localizedKey, englishKey = NormalizeName(localizedName), NormalizeName(englishName)
        for i = 1, #entries do
            local entry = entries[i]
            local liveKey = NormalizeName(entry.name)
            if not used[i] and liveKey and (liveKey == localizedKey or liveKey == englishKey) then return i, entry end
        end
        if icon then
            for i = 1, #entries do
                if not used[i] and entries[i].icon and tostring(entries[i].icon):lower() == tostring(icon):lower() then return i, entries[i] end
            end
        end
    end

    for raceIndex = 1, 20 do
        local catalog = RP.ArtifactCatalog and RP.ArtifactCatalog[raceIndex]
        local race = self:GetRace(raceIndex)
        local raceName = race and race.name
        if not raceName and type(GetArchaeologyRaceInfo) == "function" then
            local raceOK, apiRaceName = pcall(GetArchaeologyRaceInfo, raceIndex, false)
            if raceOK then raceName = apiRaceName end
        end
        raceName = raceName or RP.L.UNKNOWN

        if catalog and #catalog > 0 then
            local liveEntries, used = liveByRace[raceIndex] or {}, {}
            for i = 1, #catalog do
                local source = catalog[i]
                local itemName, itemIcon
                if C_Item and C_Item.GetItemInfo then
                    itemName, _, _, _, _, _, _, _, _, itemIcon = C_Item.GetItemInfo(source.itemID)
                    if not itemName and C_Item.RequestLoadItemDataByID and not self.artifactItemRequests[source.itemID] then
                        self.artifactItemRequests[source.itemID] = true
                        C_Item.RequestLoadItemDataByID(source.itemID)
                    end
                end
                -- The icon is available before the localized item cache. This
                -- lets native completion history match on a cold login too.
                if not itemIcon and C_Item and C_Item.GetItemIconByID then
                    itemIcon = C_Item.GetItemIconByID(source.itemID)
                end
                local liveIndex, live = FindLive(liveEntries, used, itemName, source.name, itemIcon)
                if liveIndex then used[liveIndex] = true end
                local artifact = {
                    key = tostring(raceIndex) .. ":item:" .. tostring(source.itemID),
                    raceIndex = raceIndex,
                    projectIndex = live and live.projectIndex,
                    itemID = source.itemID,
                    raceName = raceName,
                    name = itemName or (live and live.name) or source.name,
                    description = live and live.description or "",
                    spellDescription = live and live.spellDescription,
                    rarity = source.rare and 1 or (live and live.rarity or 0),
                    icon = itemIcon or (live and live.icon) or "Interface\\Icons\\INV_Misc_QuestionMark",
                    spellID = live and live.spellID,
                    numSockets = live and live.numSockets or 0,
                    background = live and live.background,
                    firstCompletionTime = live and live.firstCompletionTime,
                    completionCount = live and live.completionCount or 0,
                    obtained = live and live.completionCount > 0 or false,
                }
                self.archive[#self.archive + 1] = artifact
            end
        else
            for i = 1, #(liveByRace[raceIndex] or {}) do
                local live = liveByRace[raceIndex][i]
                live.key = tostring(raceIndex) .. ":api:" .. tostring(live.projectIndex)
                live.raceIndex = raceIndex
                live.raceName = raceName
                live.obtained = live.completionCount > 0
                self.archive[#self.archive + 1] = live
            end
        end
    end

    for i = 1, #self.archive do
        local artifact = self.archive[i]
        if RP.Localization and RP.Localization.RememberArtifact then
            RP.Localization:RememberArtifact(artifact.name, artifact.itemID)
        end
        self.archiveStats.total = self.archiveStats.total + 1
        if artifact.obtained then self.archiveStats.obtained = self.archiveStats.obtained + 1
        else self.archiveStats.missing = self.archiveStats.missing + 1 end
        if artifact.rarity == 1 then self.archiveStats.rare = self.archiveStats.rare + 1 end
    end

    table.sort(self.archive, function(a, b)
        if a.raceIndex ~= b.raceIndex then return a.raceIndex < b.raceIndex end
        if a.rarity ~= b.rarity then return a.rarity > b.rarity end
        return a.name < b.name
    end)
    local counts = {}
    for _, artifact in ipairs(self.archive) do
        local count = counts[artifact.raceIndex] or { total = 0, obtained = 0 }
        counts[artifact.raceIndex] = count
        count.total = count.total + 1
        if artifact.obtained then count.obtained = count.obtained + 1 end
    end
    self.collectionStats = {}
    for index, count in pairs(counts) do
        self.collectionStats[index] = (self.archiveStats.available and tostring(count.obtained) or "—") .. " / " .. count.total
    end
    return self.archive, self.archiveStats
end

function Archaeology:GetPossibleRaces()
    local branches
    local chain = RP.DigSites and RP.DigSites:GetMapChain() or {}
    for i = 1, #chain do
        if continentBranches[chain[i]] then
            branches = continentBranches[chain[i]]
            break
        end
    end
    local names, races = {}, {}
    for i = 1, #(branches or {}) do
        local race = self:GetRaceByBranchID(branches[i])
        if race and race.name then names[#names + 1] = RP.Localization:DisplayName(race.name); races[#races + 1] = race end
    end
    return names, races
end

function Archaeology:SetHighestPriority(raceIndex)
    raceIndex = tonumber(raceIndex)
    if not raceIndex then return end
    local priorities = RP.db.priorities
    for i = #priorities, 1, -1 do
        if tonumber(priorities[i]) == raceIndex then table.remove(priorities, i) end
    end
    table.insert(priorities, 1, raceIndex)
    RP.db.selectedRaces[tostring(raceIndex)] = true
    RP:Fire("ROUTE_SETTINGS_CHANGED")
end

function Archaeology:ToggleSelected(raceIndex)
    local key = tostring(raceIndex)
    RP.db.selectedRaces[key] = not RP.db.selectedRaces[key]
    if not RP.db.selectedRaces[key] then RP.db.selectedRaces[key] = nil end
    RP:Fire("ROUTE_SETTINGS_CHANGED")
end

function Archaeology:SelectProject(raceIndex)
    -- Do not switch Blizzard's selected project underneath an active restoration.
    if RP.AssemblyProgress and RP.AssemblyProgress:IsBusy()
        and tonumber(raceIndex) ~= tonumber(RP.AssemblyProgress.state.raceIndex) then return false end
    local race = self:GetRace(raceIndex)
    if not race or type(SetSelectedArtifact) ~= "function" then return false end
    if race.artifact and type(GetSelectedArtifactInfo) == "function" then
        local ok, name = pcall(GetSelectedArtifactInfo)
        if ok and name and name == race.artifact.name then return true end
    end
    return pcall(SetSelectedArtifact, raceIndex)
end

function Archaeology:GetProjectState(raceIndex)
    raceIndex = tonumber(raceIndex)
    local race = raceIndex and self:GetRace(raceIndex)
    if not race or type(SetSelectedArtifact) ~= "function" then return nil end
    -- UI reads must not select a project: changing selection clears socketed stones.
    -- Only an explicit keystone/solve click may change Blizzard's selection.
    local selectedOK, selectedName = false, nil
    if type(GetSelectedArtifactInfo) == "function" then
        selectedOK, selectedName = pcall(GetSelectedArtifactInfo)
    end
    if not selectedOK or not race.artifact or selectedName ~= race.artifact.name then
        return { race = race, artifact = race.artifact, base = race.fragments or 0,
            adjusted = 0, required = race.required or 0,
            sockets = race.artifact and tonumber(race.artifact.numSockets) or 0,
            socketed = 0, canSolve = race.canSolve and true or false }
    end

    local artifact = race.artifact
    if type(GetSelectedArtifactInfo) == "function" then
        local artifactOK, name, description, rarity, icon, hoverDescription, numSockets, background, spellID = pcall(GetSelectedArtifactInfo)
        if artifactOK and name then
            artifact = {
                name = name,
                description = description,
                rarity = tonumber(rarity) or 0,
                icon = icon,
                hoverDescription = hoverDescription,
                numSockets = tonumber(numSockets) or 0,
                background = background,
                spellID = spellID,
            }
            race.artifact = artifact
            self.artifactsByName[name] = artifact.rarity
        end
    end

    local base, adjusted, required = race.fragments or 0, 0, race.required or 0
    if type(GetArtifactProgress) == "function" then
        local progressOK, apiBase, apiAdjusted, apiRequired = pcall(GetArtifactProgress)
        if progressOK then
            base = tonumber(apiBase) or base
            adjusted = tonumber(apiAdjusted) or 0
            required = tonumber(apiRequired) or required
        end
    end

    local sockets = artifact and tonumber(artifact.numSockets) or 0
    local socketed = 0
    if type(ItemAddedToArtifact) == "function" then
        for index = 1, sockets do
            local socketOK, added = pcall(ItemAddedToArtifact, index)
            if socketOK and added then socketed = socketed + 1 end
        end
    end

    local canSolve = false
    if type(CanSolveArtifact) == "function" then
        local canOK, value = pcall(CanSolveArtifact)
        canSolve = canOK and value and true or false
    end

    return {
        race = race,
        artifact = artifact,
        base = base,
        adjusted = adjusted,
        required = required,
        sockets = sockets,
        socketed = socketed,
        canSolve = canSolve,
    }
end

function Archaeology:ToggleKeystone(raceIndex, remove)
    if RP.AssemblyProgress and RP.AssemblyProgress:IsBusy() then return false end
    raceIndex = tonumber(raceIndex)
    local race = raceIndex and self:GetRace(raceIndex)
    if not race or type(SetSelectedArtifact) ~= "function" then return false end
    if not self:SelectProject(raceIndex) then return false end

    local api = remove and RemoveItemFromArtifact or SocketItemToArtifact
    if type(api) ~= "function" then return false end
    if not remove and (tonumber(race.keystones) or 0) <= 0 then return false end
    local before = self:GetProjectState(raceIndex)
    if not before or (remove and before.socketed == 0)
        or (not remove and before.socketed >= before.sockets) then return false end
    local ok, err = pcall(api)
    local after = self:GetProjectState(raceIndex)
    local changed = ok and after and after.socketed ~= before.socketed
    if not changed then
        RP:Debug("Keystone: race=%s before=%s after=%s API=%s", tostring(raceIndex),
            tostring(before.socketed), tostring(after and after.socketed), tostring(err))
        RP:Print(RP.L.KEYSTONE_NOT_ADDED)
    end
    return changed and true or false
end

function Archaeology:Solve(raceIndex)
    if RP.AssemblyProgress and RP.AssemblyProgress:IsBusy() then return false end
    if type(SetSelectedArtifact) ~= "function" or type(CanSolveArtifact) ~= "function" or type(SolveArtifact) ~= "function" then
        return false
    end
    local ok = self:SelectProject(raceIndex)
    if not ok then return false end
    local canOK, canSolve = pcall(CanSolveArtifact)
    if canOK and canSolve then
        local race = self:GetRace(raceIndex)
        self.pendingSolveRarity = race and race.artifact and race.artifact.rarity or 0
        local state = self:GetProjectState(raceIndex)
        local tracking = RP.AssemblyProgress and RP.AssemblyProgress:Prepare(raceIndex, state and state.artifact)
        local solved, result = pcall(SolveArtifact)
        if tracking then
            if not solved or result == false then RP.AssemblyProgress:Finish(false)
            else RP.AssemblyProgress:UpdateCast() end
        end
        return solved and result ~= false
    end
    return false
end

function Archaeology:OnLogin()
    self:Refresh()
end
