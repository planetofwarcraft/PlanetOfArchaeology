local _, RP = ...

local Navigation = { target = nil, waypointOwned = false, lastRotation = 0 }
RP:RegisterModule("Navigation", Navigation)

local TWO_PI = math.pi * 2

local function SameWaypoint(point, owned)
    if not point or not owned or point.uiMapID ~= owned.uiMapID then return false end
    local x1, y1 = RP:GetVectorXY(point.position)
    local x2, y2 = RP:GetVectorXY(owned.position)
    return x1 and x2 and math.abs(x1 - x2) < 0.00002 and math.abs(y1 - y2) < 0.00002
end

function Navigation:CreatePoint(mapID, position)
    if UiMapPoint and UiMapPoint.CreateFromVector2D then
        return UiMapPoint.CreateFromVector2D(mapID, position)
    end
    return { uiMapID = mapID, position = position }
end

function Navigation:ResolveWaypoint(site)
    local mapID, position = site.mapID, site.position
    if not C_Map or not C_Map.CanSetUserWaypointOnMap then return mapID, position end
    local ok, canSet = pcall(C_Map.CanSetUserWaypointOnMap, mapID)
    if ok and canSet then return mapID, position end

    if C_Map.GetMapInfoAtPosition and C_Map.GetMapPosFromWorldPos and site.worldVector and site.continentID then
        local infoOK, info = pcall(C_Map.GetMapInfoAtPosition, mapID, site.x, site.y)
        if infoOK and info and info.mapID then
            local canOK, childCanSet = pcall(C_Map.CanSetUserWaypointOnMap, info.mapID)
            if canOK and childCanSet then
                local posOK, resolvedMapID, resolvedPosition = pcall(C_Map.GetMapPosFromWorldPos, site.continentID, site.worldVector, info.mapID)
                if posOK and resolvedPosition then return resolvedMapID, resolvedPosition end
            end
        end
    end
    -- Some city maps reject waypoints. Project the same world position onto an
    -- allowed parent map rather than reusing city coordinates on the continent.
    if C_Map.GetWorldPosFromMapPos and C_Map.GetMapPosFromWorldPos and C_Map.GetMapInfo then
        local worldOK, continent, world = pcall(C_Map.GetWorldPosFromMapPos, mapID, position)
        local parentID, visited = mapID, {}
        while worldOK and world and parentID and not visited[parentID] do
            visited[parentID] = true
            local info = C_Map.GetMapInfo(parentID)
            parentID = info and info.parentMapID
            if not parentID or parentID == 0 then break end
            local canOK, allowed = pcall(C_Map.CanSetUserWaypointOnMap, parentID)
            if canOK and allowed then
                local posOK, resolvedID, resolved = pcall(C_Map.GetMapPosFromWorldPos, continent, world, parentID)
                if posOK and resolved and resolvedID == parentID then
                    local x, y = RP:GetVectorXY(resolved)
                    if x and y and x >= 0 and x <= 1 and y >= 0 and y <= 1 then return resolvedID, resolved end
                end
            end
        end
    end
    return mapID, position
end

function Navigation:SetBlizzardWaypoint(site, explicitClick)
    if (not explicitClick and not RP.db.settings.blizzardWaypoint) or not C_Map or not C_Map.SetUserWaypoint then return false end
    local mapID, position = self:ResolveWaypoint(site)
    if C_Map.CanSetUserWaypointOnMap then
        local canOK, canSet = pcall(C_Map.CanSetUserWaypointOnMap, mapID)
        if canOK and not canSet then return false end
    end
    local point = self:CreatePoint(mapID, position)
    -- Let WaypointUI own its presentation instead of creating an anonymous pin.
    local api = WaypointUIAPI and WaypointUIAPI.Navigation
    if api and type(api.NewUserNavigation) == "function" then
        local x, y = RP:GetVectorXY(position)
        local integrated, result = pcall(api.NewUserNavigation, {
            mapID = mapID, x = x * 100, y = y * 100,
            name = site.name or RP.L.ROUTE_WINDOW,
            -- Leave icon overrides unset to preserve WaypointUI's standard marker.
            suppressAudio = true,
        })
        if integrated and result then
            self.ownedWaypoint, self.waypointOwned = point, true
            return true
        end
    end
    local ok, wasSet = pcall(C_Map.SetUserWaypoint, point)
    if ok and wasSet ~= false then
        self.ownedWaypoint = point
        self.waypointOwned = true
        if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
            pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true)
        end
        return true
    end
    return false
end

function Navigation:SetTarget(site)
    self.target = site
    if RP.db.settings.blizzardWaypoint and not self:SetBlizzardWaypoint(site) then
        RP:Debug("Blizzard waypoint was unavailable for map %s", tostring(site.mapID))
    end
end

function Navigation:ClearTarget(clearWaypoint)
    self.target = nil
    if clearWaypoint ~= false and self.waypointOwned and C_Map and C_Map.GetUserWaypoint and C_Map.ClearUserWaypoint then
        local ok, point = pcall(C_Map.GetUserWaypoint)
        if ok and SameWaypoint(point, self.ownedWaypoint) then pcall(C_Map.ClearUserWaypoint) end
    end
    self.waypointOwned = false
    self.ownedWaypoint = nil
end

function Navigation:GetDirectionTo(site)
    if not site or not C_Map or not C_Map.GetPlayerMapPosition then return nil end
    local ok, playerPosition = pcall(C_Map.GetPlayerMapPosition, site.mapID, "player")
    if not ok then playerPosition = nil end
    local px, py = RP:GetVectorXY(playerPosition)
    local facing = type(GetPlayerFacing) == "function" and GetPlayerFacing() or nil
    if not facing then return nil end

    -- Prefer world coordinates: different maps and sub-zones can use different
    -- aspect ratios. C_Map world vectors use +X north, +Y west.
    local dx, dy
    if C_Map.GetWorldPosFromMapPos and site.worldX and site.worldY then
        local continentID, worldPX, worldPY = RP.DigSites:GetPlayerWorldPosition(site.mapID)
        if worldPX and continentID ~= site.continentID then return nil end
        if worldPX and continentID == site.continentID then
            dx, dy = site.worldX - worldPX, site.worldY - worldPY
        end
    end

    local bearing
    if dx then
        bearing = math.atan2(dy, dx) % TWO_PI
    else
        if not px or not py then return nil end
        dx, dy = site.x - px, site.y - py
        if C_Map.GetMapWorldSize then
            local sizeOK, width, height = pcall(C_Map.GetMapWorldSize, site.mapID)
            if sizeOK and width and height then dx, dy = dx * width, dy * height end
        end
        bearing = math.atan2(-dx, -dy) % TWO_PI
    end

    -- Both bearings and our line-drawn needle rotate counterclockwise from north.
    local rotation = (bearing - facing) % TWO_PI
    return rotation
end

function Navigation:GetDirection()
    return self:GetDirectionTo(self.target)
end

function Navigation:GetDistance()
    if not self.target then return nil end
    RP.DigSites:UpdateDistances()
    return self.target.distance
end
