local _, RP = ...

local Events = { refreshPending = false, archiveRefreshPending = false }
RP:RegisterModule("Events", Events)

local trackedEvents = {
    "ARCHAEOLOGY_SURVEY_CAST",
    "ARCHAEOLOGY_FIND_COMPLETE",
    "ARTIFACT_DIGSITE_COMPLETE",
    "RESEARCH_ARTIFACT_DIG_SITE_UPDATED",
    "RESEARCH_ARTIFACT_UPDATE",
    "RESEARCH_ARTIFACT_COMPLETE",
    "PLAYER_ENTERING_WORLD",
    "PLAYER_MAP_CHANGED",
    "ZONE_CHANGED_NEW_AREA",
    "SKILL_LINES_CHANGED",
    "CURRENCY_DISPLAY_UPDATE",
    "BAG_UPDATE_DELAYED",
    "ITEM_DATA_LOAD_RESULT",
}

function Events:OnInitialize()
    local frame = CreateFrame("Frame")
    for i = 1, #trackedEvents do frame:RegisterEvent(trackedEvents[i]) end
    frame:SetScript("OnEvent", function(_, event, ...) self:OnEvent(event, ...) end)
    self.frame = frame
end

function Events:ScheduleRefresh(reason, delay)
    if self.refreshPending then return end
    self.refreshPending = true
    C_Timer.After(delay or 0.35, function()
        self.refreshPending = false
        RP.Archaeology:Refresh()
        RP.DigSites:Refresh(reason)
        if RP.HUD then RP.HUD:OnArchaeologyUpdated() end
        if RP.db.expedition.active then RP.RoutePlanner:ReconcileTarget() end
    end)
end

-- First fragments can create a project after the survey event. Retry only for
-- a short event-driven window, never scan all races every HUD frame.
function Events:RefreshNewProject(branchID, attempt)
    if not branchID then return end
    local race = RP.Archaeology:GetRaceByBranchID(branchID)
    if race and race.artifact and (race.required or 0) > 0 then return end
    self.projectRefreshTokens = self.projectRefreshTokens or {}
    if attempt == nil then
        if self.projectRefreshTokens[branchID] then return end
        self.projectRefreshTokens[branchID] = true
        attempt = 0
    end
    if attempt >= 4 then self.projectRefreshTokens[branchID] = nil; return end
    C_Timer.After(0.5, function()
        RP.Archaeology:Refresh()
        local loaded = RP.Archaeology:GetRaceByBranchID(branchID)
        if loaded and loaded.artifact and (loaded.required or 0) > 0 then
            self.projectRefreshTokens[branchID] = nil
            if RP.HUD then RP.HUD:OnArchaeologyUpdated() end
        else
            self:RefreshNewProject(branchID, attempt + 1)
        end
    end)
end

function Events:ScheduleArchiveRefresh()
    if self.archiveRefreshPending then return end
    self.archiveRefreshPending = true
    C_Timer.After(0.35, function()
        self.archiveRefreshPending = false
        if RP.MainFrame and RP.MainFrame.frame and RP.MainFrame.frame:IsShown() and RP.MainFrame.selectedPage == "archive" then
            RP.MainFrame.archiveDirty = true
            RP.MainFrame:RefreshArchive()
        end
    end)
end

function Events:RecordArtifact(name)
    local stats = RP.db.stats
    stats.artifacts = (stats.artifacts or 0) + 1
    local rarity = RP.Archaeology.pendingSolveRarity or RP.Archaeology.artifactsByName[name]
    if tonumber(rarity) == 1 then stats.rareArtifacts = (stats.rareArtifacts or 0) + 1 end
    RP.Archaeology.pendingSolveRarity = nil
    table.insert(stats.recentArtifacts, 1, name or RP.L.UNKNOWN)
    while #stats.recentArtifacts > 10 do table.remove(stats.recentArtifacts) end
    return tonumber(rarity)
end

function Events:CheckFirstArtifact(name, completedAt, attempt)
    if type(name) ~= "string" or type(GetArtifactInfoByRace) ~= "function" then return end
    local character = UnitGUID("player")
    if not character then return end
    local available = not IsArtifactCompletionHistoryAvailable or IsArtifactCompletionHistoryAvailable()
    if available then
        for _, race in ipairs(RP.Archaeology.races) do
            for index = 1, 500 do
                local ok, title, _, _, icon, _, _, _, spellID, firstTime, count = pcall(GetArtifactInfoByRace, race.index, index)
                if not ok or not title then break end
                if title == name then
                    if tonumber(count) and count > 1 then return end
                    -- Require a fresh native history entry, not just a matching
                    -- catalog icon or an old one-solve record on a repeat solve.
                    if count == 1 and type(firstTime) == "number" and firstTime >= completedAt - 5 then
                        RP.db.firstArtifactAlerts = RP.db.firstArtifactAlerts or {}
                        local seen = RP.db.firstArtifactAlerts[character] or {}
                        RP.db.firstArtifactAlerts[character] = seen
                        local key = tostring(race.index) .. ":" .. tostring(spellID or name)
                        if seen[key] then return end
                        seen[key] = true
                        RP.Notifications:Show(RP.L.FIRST_ARTIFACT, name,
                            SOUNDKIT and SOUNDKIT.UI_EPICLOOT_TOAST, icon, "completed")
                        return
                    end
                end
            end
        end
    end
    -- History can arrive after the completion event. Bounded, event-only retries.
    if attempt < 4 then
        C_Timer.After(1, function() self:CheckFirstArtifact(name, completedAt, attempt + 1) end)
    end
end

function Events:OnEvent(event, ...)
    if RP.db and RP.db.settings.debug then
        local values = { ... }
        for i = 1, #values do values[i] = tostring(values[i]) end
        RP:Debug("event=%s args=%s", event, table.concat(values, ", "))
    end

    if event == "ARCHAEOLOGY_SURVEY_CAST" then
        local completed, total, branchID = ...
        RP.db.stats.surveys = (RP.db.stats.surveys or 0) + 1
        RP.DigSites:LearnCurrentSite(branchID)
        RP:Fire("ARCHAEOLOGY_PROGRESS", completed, total, branchID)
        self:RefreshNewProject(branchID)
    elseif event == "ARCHAEOLOGY_FIND_COMPLETE" then
        local completed, total, branchID = ...
        RP.DigSites:LearnCurrentSite(branchID)
        RP:Fire("ARCHAEOLOGY_PROGRESS", completed, total, branchID)
        self:ScheduleRefresh("find-complete", 0.2)
        self:RefreshNewProject(branchID)
    elseif event == "ARTIFACT_DIGSITE_COMPLETE" then
        local branchID = ...
        self.completionPending = true
        RP.DigSites:UpdateDistances()
        local completedSite, completedDistance = RP.DigSites:GetNearestSite()
        if completedSite and completedDistance and completedDistance <= 1200 then
            RP.RoutePlanner.lastCompletedSiteID = completedSite.researchSiteID
        end
        RP.DigSites:LearnCurrentSite(branchID)
        local race = RP.Archaeology:GetRaceByBranchID(branchID)
        RP.db.stats.digSites = (RP.db.stats.digSites or 0) + 1
        local raceName = race and race.name or RP.L.UNKNOWN
        RP.db.stats.byRace[raceName] = (RP.db.stats.byRace[raceName] or 0) + 1
        RP:Fire("ARCHAEOLOGY_PROGRESS", 0, 0, branchID)
        RP.Expedition:EndDigging()
        -- Blizzard already plays UI_DIG_SITE_COMPLETION_TOAST for this event.
        RP.Notifications:Show(RP.L.DIG_SITE_COMPLETE, raceName, nil, race and race.texture or "Interface\\Icons\\Trade_Archaeology", "completed", race and race.texture ~= nil)
        C_Timer.After(1.2, function()
            self.completionPending = false
            RP.Archaeology:Refresh()
            RP.DigSites:Refresh("dig-site-complete")
            if RP.db.expedition.active and RP.db.settings.autoNext then RP.RoutePlanner:SelectNext() end
        end)
    elseif event == "RESEARCH_ARTIFACT_COMPLETE" then
        local name = ...
        self:RecordArtifact(name)
        local completedAt = GetServerTime()
        C_Timer.After(0.7, function() self:CheckFirstArtifact(name, completedAt, 1) end)
        self:ScheduleRefresh("artifact-complete", 0.4)
        C_Timer.After(0.7, function()
            if RP.MainFrame and RP.MainFrame.frame:IsShown() then
                RP.Archaeology:RefreshArchive()
                RP.MainFrame:RefreshProjectRaceSelector()
            end
        end)
    elseif event == "RESEARCH_ARTIFACT_DIG_SITE_UPDATED" then
        if not self.completionPending then self:ScheduleRefresh("dig-sites-updated", 0.45) end
    elseif event == "ITEM_DATA_LOAD_RESULT" then
        self:ScheduleArchiveRefresh()
    elseif event == "RESEARCH_ARTIFACT_UPDATE" or event == "CURRENCY_DISPLAY_UPDATE" or event == "BAG_UPDATE_DELAYED" or event == "SKILL_LINES_CHANGED" then
        RP.Archaeology:Refresh()
    elseif event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_MAP_CHANGED" or event == "ZONE_CHANGED_NEW_AREA" then
        self:ScheduleRefresh(event, 0.8)
    end
end

local function SlashCommand(input)
    local command = strtrim(input or ""):lower()
    if command == "exporttexts" then
        RP.ContentLocalization:Export()
    elseif command == "start" then
        RP.Expedition:Start()
    elseif command == "stop" then
        RP.Expedition:Stop()
    elseif command == "next" then
        RP.DigSites:Refresh("slash-next")
        RP.RoutePlanner:SelectNext()
    elseif command == "hud" then
        RP.HUD:Toggle()
    elseif command == "lock" then
        RP.db.settings.lockHUD = not RP.db.settings.lockHUD
        RP:Print(RP.db.settings.lockHUD and RP.L.HUD_LOCKED or RP.L.HUD_UNLOCKED)
    elseif command == "debug" then
        RP.db.settings.debug = not RP.db.settings.debug
        RP:Print(RP.db.settings.debug and RP.L.DEBUG_ENABLED or RP.L.DEBUG_DISABLED)
        if RP.db.settings.debug then
            local mapID = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
            local info = mapID and C_Map.GetMapInfo(mapID)
            local position = mapID and C_Map.GetPlayerMapPosition(mapID, "player")
            local x, y = RP:GetVectorXY(position)
            RP:Debug("uiMapID=%s parentMapID=%s player=%.4f,%.4f", tostring(mapID), tostring(info and info.parentMapID), x or 0, y or 0)
            RP.DigSites:Refresh("debug")
        end
    elseif command == "reset" then
        RP.Database:ResetPositions()
    else
        RP.MainFrame:Toggle()
    end
end

SLASH_PLANETOFARCHAEOLOGY1 = "/planetofarchaeology"
SLASH_PLANETOFARCHAEOLOGY2 = "/rp"
SLASH_PLANETOFARCHAEOLOGY3 = "/poa"
SlashCmdList.PLANETOFARCHAEOLOGY = SlashCommand
