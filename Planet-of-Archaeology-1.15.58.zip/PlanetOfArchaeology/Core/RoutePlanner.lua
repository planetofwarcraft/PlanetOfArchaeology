local _, RP = ...

local RoutePlanner = { currentTarget = nil, lastReason = nil }
RP:RegisterModule("RoutePlanner", RoutePlanner)

local function HasSelectedRaces()
    local _, races = RP.Archaeology:GetPossibleRaces()
    for _, race in ipairs(races) do
        if RP.db.selectedRaces[tostring(race.index)] then return true end
    end
    return false
end

function RoutePlanner:IsEligible(site)
    if self.lastCompletedSiteID and site.researchSiteID == self.lastCompletedSiteID then return false, "just-completed" end
    if RP.db.blacklistedSites[tostring(site.researchSiteID)] then return false, "site-blacklist" end
    if site.raceIndex and RP.db.blacklistedRaces[tostring(site.raceIndex)] then return false, "race-blacklist" end

    return true
end

function RoutePlanner:Score(site)
    local distance = site.distance or math.huge
    if not HasSelectedRaces() then
        return distance, RP.L.ROUTE_NEAREST
    end

    local selected = site.raceIndex and RP.db.selectedRaces[tostring(site.raceIndex)]
    if selected then
        return distance, site.raceName or RP.L.ROUTE_NEAREST
    end
    return 900000000 + distance, RP.L.ROUTE_NEAREST
end

function RoutePlanner:Choose(sites)
    local best, bestScore, bestReason
    for i = 1, #(sites or {}) do
        local site = sites[i]
        local eligible = self:IsEligible(site)
        if eligible then
            local score, reason = self:Score(site)
            if not bestScore or score < bestScore then
                best, bestScore, bestReason = site, score, reason
            end
        end
    end
    return best, bestReason
end

function RoutePlanner:SetTarget(site, reason)
    local previousID = self.currentTarget and self.currentTarget.researchSiteID
    local nextID = site and site.researchSiteID
    self.currentTarget = site
    self.lastReason = reason
    RP:Debug("target=%s siteID=%s race=%s reason=%s", tostring(site and site.name),
        tostring(site and site.researchSiteID), tostring(site and site.raceName), tostring(reason))
    if site then
        RP.Navigation:SetTarget(site)
    else
        RP.Navigation:ClearTarget(true)
    end
    if previousID ~= nextID then RP:Fire("TARGET_CHANGED", site, reason) end
    return site
end

function RoutePlanner:SelectNext(reason)
    RP.DigSites:UpdateDistances()
    local site, selectionReason = self:Choose(RP.DigSites.sites)
    return self:SetTarget(site, reason or selectionReason or RP.L.SELECTED_REASON)
end

function RoutePlanner:CycleTarget()
    RP.DigSites:UpdateDistances()
    local candidates = {}
    for _, site in ipairs(RP.DigSites.sites or {}) do
        if self:IsEligible(site) then candidates[#candidates + 1] = site end
    end
    table.sort(candidates, function(a, b)
        local sa, sb = self:Score(a), self:Score(b)
        if sa == sb then return (a.researchSiteID or 0) < (b.researchSiteID or 0) end
        return sa < sb
    end)
    if #candidates == 0 then return self:SetTarget(nil, RP.L.MANUAL_TARGET) end
    local nextIndex = 1
    for i, site in ipairs(candidates) do
        if self.currentTarget and site.researchSiteID == self.currentTarget.researchSiteID then
            nextIndex = i % #candidates + 1
            break
        end
    end
    return self:SetTarget(candidates[nextIndex], RP.L.MANUAL_TARGET)
end

function RoutePlanner:SelectManual(researchSiteID)
    local site = RP.DigSites:GetSiteByID(researchSiteID)
    if site then return self:SetTarget(site, RP.L.MANUAL_TARGET) end
end

function RoutePlanner:ReconcileTarget()
    if self.lastCompletedSiteID and not RP.DigSites:GetSiteByID(self.lastCompletedSiteID) then
        self.lastCompletedSiteID = nil
    end
    if not self.currentTarget then return end
    local replacement = RP.DigSites:GetSiteByID(self.currentTarget.researchSiteID)
    if replacement then
        self.currentTarget = replacement
        RP.Navigation.target = replacement
    elseif RP.db.expedition.active and RP.db.settings.autoNext then
        self:SelectNext()
    else
        self:SetTarget(nil)
    end
end

function RoutePlanner:OnInitialize()
    RP:On("DIG_SITES_UPDATED", self, self.ReconcileTarget)
    RP:On("ROUTE_SETTINGS_CHANGED", self, function(owner)
        if RP.db.expedition.active then owner:SelectNext() end
    end)
end
