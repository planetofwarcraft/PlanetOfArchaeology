local _, RP = ...

local Database = {}
RP:RegisterModule("Database", Database)

local defaults = {
    schema = 11,
    settings = {
        dockWindows = true,
        autoNext = true,
        routeMode = "PRIORITY",
        raceFilter = "PREFER",
        distanceUnits = "AUTO",
        blizzardWaypoint = true,
        showArrow = true,
        arrowScale = 1,
        lockHUD = false,
        hudScale = 1,
        hudOpacity = 0.94,
        trackerScale = 1,
        mainScale = 1,
        minimapScale = 1,
        uiScale = 0.90,
        uiOpacity = 1,
        notifications = true,
        targetAlerts = false,
        sounds = true,
        rareAlert = true,
        autoPrompt = false,
        showTracker = true,
        minimalTracker = false,
        minimalMain = false,
        language = "AUTO",
        showMapPins = true,
        debug = false,
    },
    positions = {
        main = { point = "CENTER", relativePoint = "CENTER", x = 0, y = 20 },
        hud = { point = "CENTER", relativePoint = "CENTER", x = 260, y = -90 },
        tracker = { point = "CENTER", relativePoint = "CENTER", x = 450, y = 0 },
        minimapAngle = 220,
    },
    selectedRaces = {},
    legionWishes = {},
    achievementWishes = {},
    legionWishNotified = {},
    priorities = {},
    blacklistedSites = {},
    blacklistedRaces = {},
    learnedSiteRaces = {},
    expedition = { active = false, startedAt = nil },
    stats = {
        surveys = 0,
        digSites = 0,
        artifacts = 0,
        rareArtifacts = 0,
        totalExpeditionSeconds = 0,
        byRace = {},
        recentArtifacts = {},
    },
}

local function CopyDefaults(target, source)
    for key, value in pairs(source) do
        if type(value) == "table" then
            if type(target[key]) ~= "table" then target[key] = {} end
            CopyDefaults(target[key], value)
        elseif target[key] == nil then
            target[key] = value
        end
    end
end

function Database:Initialize()
    if type(PlanetOfArchaeologyDB) ~= "table" then PlanetOfArchaeologyDB = {} end
    local previousSchema = tonumber(PlanetOfArchaeologyDB.schema) or 0
    CopyDefaults(PlanetOfArchaeologyDB, defaults)
    if previousSchema < 3 then
        -- Version 1.2 reused the old large-HUD coordinates for the new compact
        -- shovel, which could place its counter over the route list.
        PlanetOfArchaeologyDB.positions.hud = { point = "TOP", relativePoint = "TOP", x = 0, y = -95 }
        PlanetOfArchaeologyDB.settings.targetAlerts = false
    end
    if previousSchema < 5 then
        -- The old proximity card was replaced by an automatic, in-site shovel.
        PlanetOfArchaeologyDB.settings.autoPrompt = false
    end
    if previousSchema < 9 then
        -- The vertical HUD must not inherit the old horizontal HUD position,
        -- which could overlap the independently movable route window.
        PlanetOfArchaeologyDB.positions.hud = { point = "TOP", relativePoint = "TOP", x = 0, y = -95 }
    end
    if previousSchema < 10 then
        -- Apply the compact layout once to existing profiles while preserving
        -- every window's individual scale and saved position.
        local currentScale = tonumber(PlanetOfArchaeologyDB.settings.uiScale) or 1
        local compactScale = math.max(0.75, math.min(1.25, currentScale * 0.90))
        PlanetOfArchaeologyDB.settings.uiScale = math.floor(compactScale * 20 + 0.5) / 20
    end
    if previousSchema < 11 then
        -- Only migrate factory anchors: never replace a player's custom position.
        local hud, tracker = PlanetOfArchaeologyDB.positions.hud, PlanetOfArchaeologyDB.positions.tracker
        if hud.point == "TOP" and hud.relativePoint == "TOP" and hud.x == 0 and hud.y == -95 then
            PlanetOfArchaeologyDB.positions.hud = { point = "CENTER", relativePoint = "CENTER", x = 260, y = -90 }
        end
        if tracker.point == "RIGHT" and tracker.relativePoint == "RIGHT" and tracker.x == -70 and tracker.y == 0 then
            PlanetOfArchaeologyDB.positions.tracker = { point = "CENTER", relativePoint = "CENTER", x = 450, y = 0 }
        end
    end
    PlanetOfArchaeologyDB.schema = defaults.schema
    RP.db = PlanetOfArchaeologyDB
end

function Database:ResetPositions()
    RP.db.positions.main = { point = "CENTER", relativePoint = "CENTER", x = 0, y = 20 }
    RP.db.positions.hud = { point = "CENTER", relativePoint = "CENTER", x = 260, y = -90 }
    RP.db.positions.tracker = { point = "CENTER", relativePoint = "CENTER", x = 450, y = 0 }
    RP.db.positions.minimapAngle = 220
    if RP.MainFrame then RP.MainFrame:RestorePosition() end
    if RP.HUD then RP.HUD:RestorePosition() end
    if RP.SiteTracker then RP.SiteTracker:RestorePosition() end
    if RP.MinimapButton and RP.MinimapButton.button then RP.MinimapButton:UpdatePosition() end
    RP:Print(RP.L.POSITIONS_RESET)
end

function Database:ResetInterface()
    for _, key in ipairs({"dockWindows", "lockHUD", "hudScale", "hudOpacity", "trackerScale", "mainScale", "minimapScale", "uiScale", "uiOpacity", "minimalMain", "minimalTracker", "arrowScale"}) do
        RP.db.settings[key] = defaults.settings[key]
    end
    RP.db.dockOffsets = {}
    self:ResetPositions()
    for _, key in ipairs({"MainFrame", "HUD", "SiteTracker", "Proximity", "Notifications", "MinimapButton"}) do
        local module = RP[key]
        if module and module.ApplySettings then module:ApplySettings() end
    end
    if RP.WindowLayout then RP.WindowLayout:SetDocking(true) end
end

function Database:ResetAll()
    PlanetOfArchaeologyDB = {}
    CopyDefaults(PlanetOfArchaeologyDB, defaults)
    RP.db = PlanetOfArchaeologyDB
end
