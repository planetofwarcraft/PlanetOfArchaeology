local _, RP = ...
local Layout = {}
RP:RegisterModule("WindowLayout", Layout)

local function Rect(frame)
    local scale = frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return (frame:GetLeft() or 0) * scale, (frame:GetTop() or 0) * scale,
        frame:GetWidth() * scale, frame:GetHeight() * scale
end

local function Place(frame, left, top)
    -- The resize grip owns this anchor until release; do not fight the cursor.
    if frame.relicResizing or frame.relicDragging then return end
    local currentLeft, currentTop = Rect(frame)
    -- Avoid rebuilding anchors while the window is stationary.
    if math.abs(currentLeft - left) < 0.01 and math.abs(currentTop - top) < 0.01 then return end
    local scale = frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left / scale, top / scale)
end

function Layout:PlaceDocked(frame, key, x, y)
    local offset = RP.db.dockOffsets and RP.db.dockOffsets[key]
    frame.relicDockBase = { key = key, x = x, y = y }
    Place(frame, x + (offset and offset.x or 0), y + (offset and offset.y or 0))
end

function Layout:SaveDockOffset(frame)
    local base = frame.relicDockBase
    if RP.db.settings.dockWindows == false or not base then return end
    local x,y = Rect(frame)
    RP.db.dockOffsets = RP.db.dockOffsets or {}
    RP.db.dockOffsets[base.key] = {x = x - base.x, y = y - base.y}
end

function Layout:SetDocking(enabled)
    RP.db.settings.dockWindows = enabled and true or false
    if not enabled then
        -- Keep the current side-by-side arrangement, not old overlapping anchors.
        for _, entry in ipairs({{RP.SiteTracker.frame, "tracker"}, {RP.HUD.frame, "hud"}}) do
            if not entry[1].relicDragging then RP.Widgets:SavePosition(entry[1], entry[2]) end
        end
        self.routeDocked, self.hudDocked = nil, nil
    end
    self.freeSignature = nil
    if RP.Settings and RP.Settings.RefreshPanel then RP.Settings:RefreshPanel() end
    self:Apply()
end

function Layout:ArrangeFree(frames)
    local placed = {}
    local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
    local function fits(x, y, w, h)
        if x < 8 or x + w > sw - 8 or y > sh - 8 or y - h < 8 then return false end
        for _, r in ipairs(placed) do
            if x < r[1]+r[3]+12 and x+w+12 > r[1] and y > r[2]-r[4]-12 and y-h-12 < r[2] then return false end
        end
        return true
    end
    for _, frame in ipairs(frames) do
        local x,y,w,h = Rect(frame)
        if #placed > 0 and not fits(x,y,w,h) then
            local candidates = {}
            for _, r in ipairs(placed) do
                candidates[#candidates+1] = {r[1]+r[3]+12,r[2]}
                candidates[#candidates+1] = {r[1]-w-12,r[2]}
                candidates[#candidates+1] = {r[1],r[2]-r[4]-12}
                candidates[#candidates+1] = {r[1],r[2]+h+12}
            end
            for _, p in ipairs(candidates) do
                local cx,cy = math.max(8,math.min(sw-w-8,p[1])), math.min(sh-8,math.max(h+8,p[2]))
                if fits(cx,cy,w,h) then Place(frame,cx,cy);x,y=cx,cy;break end
            end
        end
        placed[#placed+1] = {x,y,w,h}
    end
end

function Layout:Apply()
    if self.applying or InCombatLockdown() then return end
    local main, route, hud = RP.MainFrame.frame, RP.SiteTracker.frame, RP.HUD.frame
    if not main or not route or not hud then return end
    if not route.relicDragging then route.relicDockBase = nil end
    if not hud.relicDragging then hud.relicDockBase = nil end
    self.applying = true
    local gap, margin = 12, 8
    local screenW, screenH = UIParent:GetWidth(), UIParent:GetHeight()
    local _, _, rw, rh = Rect(route)
    local _, _, hw, hh = Rect(hud)
    local wantRoute = RP.db.settings.showTracker and RP.db.expedition.active
    local wantHUD = RP.HUD.wantsVisible and true or false
    local showRoute, showHUD = wantRoute, wantHUD
    if RP.db.settings.dockWindows == false then
        local signature = tostring(main:IsShown()) .. tostring(wantRoute) .. tostring(wantHUD)
        if route.relicDragging or hud.relicDragging then self.freeSignature = signature end
        if self.freeSignature ~= signature and not route.relicDragging and not hud.relicDragging then
            local frames = {}
            if main:IsShown() then frames[#frames+1] = main end
            if wantRoute then frames[#frames+1] = route end
            if wantHUD then frames[#frames+1] = hud end
            self:ArrangeFree(frames)
            self.freeSignature = signature
        end
        RP.HUD.layoutSuppressed = not showHUD
        if route:IsShown() ~= (showRoute and true or false) then route:SetShown(showRoute and true or false) end
        if hud:IsShown() ~= (showHUD and true or false) then hud:SetShown(showHUD and true or false) end
        self.applying = nil
        return
    end
    if main:IsShown() then
        local left, top, width, height = Rect(main)
        -- Keep the complete default dock group on screen, not just its main frame.
        -- Never move a frame while the player is dragging it.
        local reserve = wantRoute and rw + gap or (wantHUD and hw + gap or 0)
        if reserve > 0 and width + reserve <= screenW - 2 * margin and not main.relicDragging and not main.relicResizing then
            local targetLeft = math.max(0, math.min(screenW - margin - width - reserve, left))
            local targetTop = math.min(screenH - margin, math.max(height + margin, top))
            Place(main, targetLeft, targetTop)
            left, top = Rect(main)
        end
        local x = left + width + gap
        top = math.min(screenH - margin, math.max(rh + margin, top))
        showRoute = wantRoute and x + rw <= screenW - margin and rh <= screenH - 2 * margin
        if showRoute then
            self:PlaceDocked(route, "routeMain", x, top)
            self.routeDocked = true
            x, top = Rect(route)
        end
        if wantHUD then
            if showRoute and top - rh - gap - hh >= margin then
                self:PlaceDocked(hud, "hudMain", x, top - rh - gap)
                self.hudDocked = true
            elseif x + (showRoute and rw + gap or 0) + hw <= screenW - margin then
                self:PlaceDocked(hud, "hudMain", x + (showRoute and rw + gap or 0), math.min(screenH - margin, top))
                self.hudDocked = true
            else
                showHUD = false
            end
        end
    else
        if self.routeDocked then
            RP.Widgets:RestorePosition(route, "tracker")
            self.routeDocked = nil
        end
        if showRoute and showHUD then
            -- Follow the route without overwriting the HUD's standalone anchor.
            local left, top = Rect(route)
            local x = left - gap - hw
            if x < margin then x = left + rw + gap end
            x = math.max(margin, math.min(screenW - margin - hw, x))
            self:PlaceDocked(hud, "hudRoute", x, math.min(screenH - margin, math.max(hh + margin, top - rh + hh)))
            self.hudDocked = true
        elseif self.hudDocked then
            RP.Widgets:RestorePosition(hud, "hud")
            self.hudDocked = nil
        end
    end
    RP.HUD.layoutSuppressed = not showHUD
    if route:IsShown() ~= (showRoute and true or false) then route:SetShown(showRoute and true or false) end
    if hud:IsShown() ~= (showHUD and true or false) then hud:SetShown(showHUD and true or false) end
    self.applying = nil
end

function Layout:OpenWindow(key)
    if InCombatLockdown() then return end
    if key == "main" then
        RP.MainFrame:Toggle()
    elseif key == "hud" then
        if RP.HUD.frame:IsShown() then
            RP.HUD:Hide()
        else
            RP.HUD.openedFromWindow = true
            RP.HUD:Show()
        end
    elseif key == "route" then
        if RP.SiteTracker.frame:IsShown() then
            RP.SiteTracker:SetShownByUser(false)
            self:Apply()
            return
        end
        RP.db.settings.showTracker = true
        if not RP.db.expedition.active then
            local keepMain = RP.MainFrame.frame:IsShown()
            RP.Expedition:Start()
            if keepMain then RP.MainFrame.frame:Show() end
        end
        RP.SiteTracker:SetShownByUser(true)
    end
    self:Apply()
end

function Layout:AddWindowRail(frame, ownKey)
    if frame.relicWindowRailWidth then return end
    frame.relicWindowRailWidth = 0
    local index = 0
    for _, spec in ipairs({
        {"main", "RESEARCH", "Interface\\Icons\\INV_Misc_Book_09"},
        {"route", "ROUTE_WINDOW", "Interface\\Icons\\INV_Misc_Map_01"},
        {"hud", "SURVEY", "Interface\\Icons\\Trade_Archaeology"},
    }) do
        if spec[1] ~= ownKey then
            local key, label = spec[1], spec[2]
            local button = RP.Widgets:CreateButton(frame, "", 16, 18)
            -- Section-wide drag handles otherwise intercept these root-level
            -- buttons, especially when the journal's left section is hidden.
            button:SetFrameLevel(frame:GetFrameLevel() + 30)
            button:EnableMouse(true)
            button:RegisterForClicks("LeftButtonUp")
            button:SetHitRectInsets(-2, -2, -2, -2)
            if ownKey == "main" then
                button:SetPoint("BOTTOMLEFT", 18 + index * 20, 16)
            elseif ownKey == "route" then
                button:SetPoint("TOPLEFT", 6 + index * 20, -5)
            else
                button:SetPoint("TOPLEFT", 7, -9 - index * 22)
            end
            local icon = button:CreateTexture(nil, "ARTWORK")
            icon:SetSize(12, 12); icon:SetPoint("CENTER")
            icon:SetTexture(spec[3]); icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            button:HookScript("OnEnter", function(b)
                GameTooltip:SetOwner(b, "ANCHOR_LEFT")
                GameTooltip:AddLine(RP.L[label] or RP.L.RESEARCH)
                GameTooltip:Show()
            end)
            button:HookScript("OnLeave", GameTooltip_Hide)
            button:SetScript("OnClick", function() self:OpenWindow(key) end)
            index = index + 1
        end
    end
end

function Layout:OnLogin()
    RP.SiteTracker.frame:HookScript("OnDragStop", function(frame) self:SaveDockOffset(frame) end)
    RP.HUD.frame:HookScript("OnDragStop", function(frame) self:SaveDockOffset(frame) end)
    RP.HUD.frame.info:HookScript("OnDragStop", function() self:SaveDockOffset(RP.HUD.frame) end)
    self:AddWindowRail(RP.MainFrame.frame, "main")
    self:AddWindowRail(RP.SiteTracker.frame, "route")
    self:AddWindowRail(RP.HUD.frame, "hud")
    for _, frame in ipairs({ RP.MainFrame.frame, RP.SiteTracker.frame, RP.HUD.frame }) do
        frame:HookScript("OnShow", function() self:Apply() end)
        frame:HookScript("OnHide", function() self:Apply() end)
    end
    local driver = CreateFrame("Frame")
    -- Follow native dragging/resizing every rendered frame, without timer lag.
    -- Apply only reads geometry; unchanged positions/visibility cause no UI writes.
    driver:SetScript("OnUpdate", function()
        self:Apply()
    end)
    driver:RegisterEvent("PLAYER_REGEN_ENABLED")
    driver:SetScript("OnEvent", function() self:Apply() end)
    self:Apply()
end
