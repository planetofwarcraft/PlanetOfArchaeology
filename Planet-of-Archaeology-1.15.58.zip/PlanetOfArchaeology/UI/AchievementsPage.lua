local _, RP = ...
local Page = { rows = {}, filter = "all", expansion = "all" }
RP:RegisterModule("AchievementsPage", Page)

local upper = {"А","Б","В","Г","Д","Е","Ё","Ж","З","И","Й","К","Л","М","Н","О","П","Р","С","Т","У","Ф","Х","Ц","Ч","Ш","Щ","Ъ","Ы","Ь","Э","Ю","Я","І","Ї","Є","Ґ"}
local lower = {"а","б","в","г","д","е","ё","ж","з","и","й","к","л","м","н","о","п","р","с","т","у","ф","х","ц","ч","ш","щ","ъ","ы","ь","э","ю","я","і","ї","є","ґ"}
function Page:SearchText(text)
    -- Byte-wise lower() can corrupt UTF-8 under a non-C system locale.
    text = (text or ""):gsub("[A-Z]", function(c) return string.char(c:byte() + 32) end)
    for i, letter in ipairs(upper) do text = text:gsub(letter, lower[i]) end
    return text:match("^%s*(.-)%s*$")
end

function Page:MatchesSearch(entry)
    local query = self:SearchText(self.query)
    local name = RP.ContentLocalization:AchievementName(entry.id, entry.name)
    return query == "" or self:SearchText(name):find(query, 1, true) ~= nil
end

local function Label(parent, font, x, y, width)
    local text = parent:CreateFontString(nil, "OVERLAY", font)
    text:SetPoint("TOPLEFT", x, y)
    text:SetWidth(width)
    text:SetJustifyH("LEFT")
    return text
end

local function Scrollbar(parent, scroll, child)
    local bar = CreateFrame("Slider", nil, parent)
    bar:SetWidth(12)
    bar:SetPoint("TOPLEFT", scroll, "TOPRIGHT", 3, -2)
    bar:SetPoint("BOTTOMLEFT", scroll, "BOTTOMRIGHT", 3, 2)
    bar:SetOrientation("VERTICAL")
    bar:SetMinMaxValues(0, 1)
    bar:SetValueStep(1)
    bar:SetObeyStepOnDrag(false)
    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetWidth(2); track:SetPoint("TOP", 0, 0); track:SetPoint("BOTTOM", 0, 0)
    track:SetColorTexture(0.40, 0.29, 0.15, 0.65)
    local thumb = bar:CreateTexture(nil, "OVERLAY")
    thumb:SetSize(12, 36); thumb:SetColorTexture(0.04, 0.03, 0.02, 1)
    bar:SetThumbTexture(thumb)
    local handle = CreateFrame("Frame", nil, bar)
    handle:SetAllPoints(thumb)
    handle:EnableMouse(false)
    RP.Theme:ApplyNineSlice(handle, {cut = 3, fillAlpha = 0.95, borderAlpha = 0.95, grainAlpha = 0.05})
    for _, y in ipairs({-3, 0, 3}) do
        local grip = handle:CreateTexture(nil, "OVERLAY")
        grip:SetSize(6, 1); grip:SetPoint("CENTER", 0, y)
        grip:SetColorTexture(0.85, 0.64, 0.31, 0.85)
    end
    bar:HookScript("OnEnter", function() handle:SetRelicState("hover") end)
    bar:HookScript("OnLeave", function() handle:SetRelicState("normal") end)
    local syncing = false
    local function Update()
        if syncing then return end
        syncing = true
        local maximum = math.max(0, child:GetHeight() - scroll:GetHeight())
        local value = math.max(0, math.min(maximum, scroll:GetVerticalScroll()))
        bar:SetMinMaxValues(0, math.max(1, maximum))
        bar:SetValue(value)
        bar:SetShown(maximum > 0)
        thumb:SetHeight(math.max(24, math.min(scroll:GetHeight(), scroll:GetHeight() * scroll:GetHeight() / math.max(1, child:GetHeight()))))
        if value ~= scroll:GetVerticalScroll() then scroll:SetVerticalScroll(value) end
        syncing = false
    end
    bar:SetScript("OnValueChanged", function(_, value)
        if not syncing then scroll:SetVerticalScroll(value) end
    end)
    scroll:HookScript("OnVerticalScroll", Update)
    scroll:HookScript("OnSizeChanged", Update)
    return Update, bar
end

function Page:Create(parent)
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetAllPoints()
    self.frame = frame
    Label(frame, "GameFontNormalLarge", 14, -12, 300):SetText(RP.L.ACHIEVEMENTS)
    self.counter = Label(frame, "GameFontHighlightSmall", 330, -16, 320)
    self.counter:SetJustifyH("RIGHT")
    self.filters = {}
    for i, key in ipairs({"all", "earned", "missing", "wished"}) do
        local label = key == "wished" and RP.L.WISH_TAB or (key == "all" and RP.L.ARCHIVE_ALL or (key == "earned" and RP.L.ACH_EARNED or RP.L.ACH_MISSING))
        local button = RP.Widgets:CreateButton(frame, label, 142, 26)
        button:SetPoint("TOPLEFT", 14 + (i - 1) * 150, -44)
        button:SetScript("OnClick", function()
            self.filter = key; self.scroll:SetVerticalScroll(0); self:Refresh()
        end)
        self.filters[key] = button
    end
    self.expansionButton = RP.Widgets:CreateButton(frame, RP.L.ACH_EXP_ALL, 300, 26)
    self.expansionButton:SetPoint("TOPLEFT", 14, -78)
    local search = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
    search:SetSize(280, 26)
    search:SetPoint("TOPLEFT", 350, -78)
    search:SetAutoFocus(false)
    search:SetMaxLetters(100)
    local hint = Label(frame, "GameFontDisableSmall", 356, -85, 265)
    hint:SetText(RP.L.SEARCH_ACHIEVEMENTS)
    search:SetScript("OnTextChanged", function(box)
        self.query = box:GetText()
        hint:SetShown(self.query == "")
        if self.scroll then self.scroll:SetVerticalScroll(0); self:Refresh() end
    end)
    search:SetScript("OnEscapePressed", function(box) box:SetText(""); box:ClearFocus() end)
    search:SetScript("OnEnterPressed", function(box) box:ClearFocus() end)
    search:SetScript("OnHide", function(box) box:ClearFocus() end)
    self.search = search
    local menu = CreateFrame("Frame", nil, frame)
    menu:SetPoint("TOPLEFT", self.expansionButton, "BOTTOMLEFT", 0, -3)
    menu:SetSize(300, 220)
    menu:SetFrameLevel(frame:GetFrameLevel() + 20)
    RP.Widgets:ApplyRelicCard(menu)
    menu:EnableMouse(true)
    menu:Hide()
    self.expansionMenu = menu
    self.expansionOptions = {}
    for i, key in ipairs({"all", "general", "cata", "mop", "wod", "legion", "bfa"}) do
        local button = RP.Widgets:CreateButton(menu, RP.L["ACH_EXP_" .. string.upper(key)], 288, 28)
        button:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 30)
        button:SetScript("OnClick", function()
            self.expansion = key; menu:Hide(); self.scroll:SetVerticalScroll(0); self:Refresh()
        end)
        self.expansionOptions[key] = button
    end
    self.expansionButton:SetScript("OnClick", function() menu:SetShown(not menu:IsShown()) end)
    frame:SetScript("OnHide", function() menu:Hide() end)
    local scroll = CreateFrame("ScrollFrame", nil, frame)
    scroll:SetPoint("TOPLEFT", 14, -116)
    scroll:SetPoint("BOTTOMLEFT", 14, 8)
    scroll:SetWidth(300)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(300, 1)
    scroll:SetScrollChild(child)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(s, delta)
        s:SetVerticalScroll(math.max(0, math.min(math.max(0, child:GetHeight() - s:GetHeight()), s:GetVerticalScroll() - delta * 58)))
    end)
    scroll:SetScript("OnVerticalScroll", function() self:RenderRows() end)
    scroll:SetScript("OnSizeChanged", function() self:RenderRows() end)
    self.scroll, self.child = scroll, child
    self.UpdateScrollbar, self.scrollbar = Scrollbar(frame, scroll, child)
    self.empty = Label(frame, "GameFontDisable", 24, -130, 270)
    self.empty:SetWordWrap(true)
    local detail = CreateFrame("Frame", nil, frame)
    detail:SetPoint("TOPLEFT", 344, -116)
    detail:SetPoint("BOTTOMRIGHT", -14, 8)
    RP.Widgets:ApplyRelicCard(detail)
    detail.icon = detail:CreateTexture(nil, "ARTWORK")
    detail.icon:SetSize(48, 48)
    detail.icon:SetPoint("TOPLEFT", 14, -14)
    detail.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    detail.title = Label(detail, "GameFontNormal", 74, -16, 230)
    detail.title:SetPoint("RIGHT", detail, "RIGHT", -14, 0)
    detail.title:SetHeight(36)
    detail.title:SetWordWrap(true)
    detail.title:SetMaxLines(2)
    detail.status = Label(detail, "GameFontHighlightSmall", 14, -70, 290)
    local bodyScroll = CreateFrame("ScrollFrame", nil, detail)
    bodyScroll:SetPoint("TOPLEFT", 14, -94)
    bodyScroll:SetPoint("BOTTOMRIGHT", -28, 82)
    local body = CreateFrame("Frame", nil, bodyScroll)
    body:SetSize(290, 1)
    bodyScroll:SetScrollChild(body)
    local updateBodyBar = Scrollbar(detail, bodyScroll, body)
    detail.text = Label(body, "GameFontHighlightSmall", 0, 0, 290)
    detail.text:SetWordWrap(true)
    detail.criteriaRows = {}
    detail.body = body
    detail.wish = RP.Widgets:CreateButton(detail, RP.L.ACH_WISH_ADD, 280, 26)
    detail.wish:SetPoint("BOTTOMLEFT", 14, 44)
    detail.wish:SetPoint("BOTTOMRIGHT", -14, 44)
    detail.wish:SetScript("OnClick", function()
        if not self.selectedEntry then return end
        RP.Achievements:ToggleWish(self.selectedEntry.id)
        self.lastEntries = nil; self:Refresh()
    end)
    detail.track = RP.Widgets:CreateButton(detail, RP.L.ACH_TRACK, 280, 26)
    detail.track:SetPoint("BOTTOMLEFT", 14, 12)
    detail.track:SetPoint("BOTTOMRIGHT", -14, 12)
    detail.track:SetScript("OnClick", function()
        if not self.selectedEntry then return end
        RP.Achievements:ToggleTracking(self.selectedEntry.id)
        self:ShowDetail(self.selectedEntry, false)
    end)
    bodyScroll:EnableMouseWheel(true)
    local function Size()
        local width = math.max(1, bodyScroll:GetWidth())
        body:SetWidth(width); detail.text:SetWidth(width)
        local offset = detail.text:GetStringHeight() + 12
        for _, row in ipairs(detail.criteriaRows) do
            if row:IsShown() then
                row:SetWidth(width); row:ClearAllPoints(); row:SetPoint("TOPLEFT", 0, -offset)
                offset = offset + 60
            end
        end
        body:SetHeight(math.max(1, offset))
        updateBodyBar()
    end
    bodyScroll:SetScript("OnSizeChanged", Size)
    bodyScroll:SetScript("OnMouseWheel", function(s, delta)
        s:SetVerticalScroll(math.max(0, math.min(math.max(0, body:GetHeight() - s:GetHeight()), s:GetVerticalScroll() - delta * 30)))
    end)
    detail.scroll, detail.ResizeText = bodyScroll, Size
    self.detail = detail
    frame:SetScript("OnShow", function() self.lastEntries = nil; self:Refresh() end)
    return frame
end

function Page:RenderRows()
    if not self.scroll or not self.visible then return end
    local first = math.floor(self.scroll:GetVerticalScroll() / 58) + 1
    local count = math.ceil(self.scroll:GetHeight() / 58) + 1
    if self.renderFirst == first and self.renderCount == count and self.renderSelected == self.selectedID and self.renderEntries == self.visible then return end
    self.renderFirst, self.renderCount, self.renderSelected, self.renderEntries = first, count, self.selectedID, self.visible
    for i = 1, math.max(count, #self.rows) do
        local entry = i <= count and self.visible[first + i - 1] or nil
        local row = self.rows[i]
        if entry and not row then
            row = CreateFrame("Button", nil, self.child)
            row:SetSize(298, 54)
            RP.Widgets:ApplyRelicCard(row)
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(40, 40); row.icon:SetPoint("LEFT", 8, 0)
            row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            row.title = Label(row, "GameFontHighlightSmall", 56, -8, 228)
            row.title:SetHeight(26); row.title:SetMaxLines(2); row.title:SetWordWrap(true)
            row.status = Label(row, "GameFontDisableSmall", 56, -36, 228)
            row:SetScript("OnClick", function(b) self.selectedID = b.entry.id; self:RenderRows(); self:ShowDetail(b.entry, true) end)
            self.rows[i] = row
        end
        if row then
            row:SetShown(entry ~= nil)
            if entry then
                row.entry = entry
                row:ClearAllPoints(); row:SetPoint("TOPLEFT", 0, -(first + i - 2) * 58)
                row.icon:SetTexture(entry.icon or "Interface\\Icons\\Trade_Archaeology")
                row.icon:SetDesaturated(not entry.completed)
                row.title:SetText(RP.ContentLocalization:AchievementName(entry.id, entry.name))
                row.status:SetText((entry.completed and RP.L.ACH_EARNED or RP.L.ACH_MISSING) .. " • " .. RP.L.ACH_POINTS:format(entry.points))
                row:SetRelicState(self.selectedID == entry.id and "selected" or (entry.completed and "completed" or "normal"), true)
            end
        end
    end
end

function Page:ShowDetail(entry, reset)
    self.selectedEntry = entry
    self.detail:SetShown(entry ~= nil)
    if not entry then return end
    local detail = self.detail
    detail.icon:SetTexture(entry.icon or "Interface\\Icons\\Trade_Archaeology")
    detail.title:SetText(RP.ContentLocalization:AchievementName(entry.id, entry.name))
    detail.status:SetText((entry.completed and RP.L.ACH_EARNED or RP.L.ACH_MISSING) .. " • " .. RP.L.ACH_POINTS:format(entry.points))
    local service = RP.Achievements
    detail.wish.text:SetText(service:IsWished(entry.id) and RP.L.ACH_WISH_REMOVE or RP.L.ACH_WISH_ADD)
    detail.wish:SetAccent(service:IsWished(entry.id))
    local tracked = service:IsTracked(entry.id)
    detail.track.text:SetText(tracked and RP.L.ACH_UNTRACK or RP.L.ACH_TRACK)
    detail.track:SetEnabled(not entry.earnedByMe or tracked)
    detail.track:SetAccent(tracked)
    local criteria, completed = service:GetCriteria(entry.id)
    detail.text:SetText(service:GetDetails(entry, true) .. (#criteria > 0 and ("\n\n" .. RP.L.ACH_PROGRESS:format(completed, #criteria)) or ""))
    for i = 1, math.max(#criteria, #detail.criteriaRows) do
        local data, row = criteria[i], detail.criteriaRows[i]
        if data and not row then
            row = CreateFrame("Frame", nil, detail.body)
            row:SetSize(280, 54)
            RP.Widgets:ApplyRelicCard(row)
            row.label = Label(row, "GameFontHighlightSmall", 8, -6, 260)
            row.label:SetPoint("TOPRIGHT", -8, -6); row.label:SetHeight(26); row.label:SetWordWrap(true); row.label:SetMaxLines(2)
            row.bar = CreateFrame("StatusBar", nil, row)
            row.bar:SetPoint("BOTTOMLEFT", 10, 6); row.bar:SetPoint("BOTTOMRIGHT", -10, 6); row.bar:SetHeight(3)
            row.bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
            local bg = row.bar:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints(); bg:SetColorTexture(0.12, 0.10, 0.06, 0.9)
            row.value = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.value:SetPoint("BOTTOMRIGHT", -10, 12)
            detail.criteriaRows[i] = row
        end
        if row then
            row:SetShown(data ~= nil)
            if data then
                row.label:SetText(RP.ContentLocalization:Criterion(entry.id, data.order, data.name))
                row:SetRelicState(data.done and "completed" or "normal", true)
                row.bar:SetMinMaxValues(0, data.required); row.bar:SetValue(data.quantity)
                row.bar:SetStatusBarColor(data.done and 0.46 or 0.88, data.done and 0.38 or 0.63, data.done and 0.23 or 0.25, 0.9)
                row.value:SetTextColor(data.done and 0.68 or 0.95, data.done and 0.62 or 0.79, data.done and 0.47 or 0.43)
                row.value:SetText(data.done and RP.L.ACH_DONE or (tostring(data.quantity) .. " / " .. tostring(data.required)))
            end
        end
    end
    detail.ResizeText()
    if reset then detail.scroll:SetVerticalScroll(0) end
end

function Page:Refresh()
    if not self.frame or not self.frame:IsVisible() then return end
    local service = RP.Achievements
    local revision = service.criteriaRevision or 0
    if not service.dirty and self.lastEntries == service.entries and self.lastFilter == self.filter
        and self.lastExpansion == self.expansion and self.lastLanguage == RP.L.ACHIEVEMENTS and self.lastQuery == self.query then
        if self.lastRevision ~= revision then
            self.lastRevision = revision
            if self.selectedEntry then self:ShowDetail(self.selectedEntry, false) end
        end
        return
    end
    local entries = RP.Achievements:GetEntries()
    self.lastEntries, self.lastFilter, self.lastExpansion = entries, self.filter, self.expansion
    self.lastLanguage, self.lastRevision = RP.L.ACHIEVEMENTS, revision
    self.lastQuery = self.query
    local completed, total, selected = 0, 0, nil
    self.visible = {}
    for _, entry in ipairs(entries) do
        local expansionMatch = self.expansion == "all" or RP.Achievements:GetExpansion(entry.id) == self.expansion
        if expansionMatch then total = total + 1; if entry.completed then completed = completed + 1 end end
        if expansionMatch and self:MatchesSearch(entry) and (self.filter == "all" or (self.filter == "earned" and entry.completed) or (self.filter == "missing" and not entry.completed) or (self.filter == "wished" and service:IsWished(entry.id))) then
            self.visible[#self.visible + 1] = entry
            if entry.id == self.selectedID then selected = entry end
        end
    end
    local oldID = self.selectedID
    selected = selected or self.visible[1]
    self.selectedEntry = selected
    self.selectedID = selected and selected.id
    self.counter:SetText(RP.L.ACH_COUNTER:format(completed, total))
    self.expansionButton.text:SetText(RP.L["ACH_EXP_" .. string.upper(self.expansion)] .. "  v")
    for key, button in pairs(self.expansionOptions) do button:SetAccent(key == self.expansion) end
    for key, button in pairs(self.filters) do button:SetAccent(key == self.filter) end
    self.child:SetHeight(math.max(1, #self.visible * 58))
    self.scroll:SetVerticalScroll(math.min(self.scroll:GetVerticalScroll(), math.max(0, self.child:GetHeight() - self.scroll:GetHeight())))
    self.UpdateScrollbar()
    self.empty:SetText(#entries == 0 and RP.L.ACH_UNAVAILABLE or RP.L.ACH_EMPTY)
    self.empty:SetShown(#self.visible == 0)
    self:RenderRows()
    self:ShowDetail(selected, oldID ~= self.selectedID)
end
