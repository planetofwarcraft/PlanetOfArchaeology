local _, RP = ...
local Page = {}
RP:RegisterModule("ExpeditionsPage", Page)

local function Text(parent, template, x, y, width)
    local text = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlightSmall")
    text:SetPoint("TOPLEFT", x, y)
    text:SetWidth(width)
    text:SetJustifyH("LEFT")
    return text
end

function Page:Create(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetAllPoints()
    self.frame = page
    Text(page, "GameFontNormalLarge", 14, -10, 650):SetText(RP.L.LEGION_TITLE)
    Text(page, "GameFontDisableSmall", 14, -34, 650):SetText(RP.L.LEGION_SUBTITLE)
    local current = CreateFrame("Button", nil, page)
    current:SetPoint("TOPLEFT", 14, -58)
    current:SetPoint("TOPRIGHT", -14, -58)
    current:SetHeight(158)
    RP.Widgets:ApplyRelicCard(current, 0.93, 0.9)
    current.heading = Text(current, "GameFontNormalSmall", 14, -10, 450)
    current.heading:SetText(RP.L.LEGION_CURRENT)
    current.icon = current:CreateTexture(nil, "ARTWORK")
    current.icon:SetSize(42, 42)
    current.icon:SetPoint("TOPLEFT", 14, -31)
    current.name = Text(current, "GameFontNormalLarge", 68, -30, 530)
    current.meta = Text(current, "GameFontDisableSmall", 68, -55, 530)
    current.time = Text(current, "GameFontHighlightSmall", 14, -83, 415)
    current.time:SetHeight(34)
    current.progress = Text(current, "GameFontHighlightSmall", 14, -124, 420)
    current.progress:SetHeight(24)
    current.action = RP.Widgets:CreateButton(current, "", 198, 28)
    current.action:SetPoint("BOTTOMRIGHT", -12, 12)
    current.action:SetScript("OnClick", function()
        local rotation = RP.LegionExpeditions:GetRotation()
        if rotation then RP.LegionExpeditions:Navigate(RP.SpecialExpeditionData.legion.entries[rotation.index]) end
    end)
    current:EnableMouse(true)
    current:HookScript("OnEnter", function(b)
        local r = RP.LegionExpeditions:GetRotation()
        if not r then return end
        GameTooltip:SetOwner(b, "ANCHOR_RIGHT")
        GameTooltip:SetItemByID(RP.SpecialExpeditionData.legion.entries[r.index].itemID)
    end)
    current:SetScript("OnClick", function()
        local r = RP.LegionExpeditions:GetRotation()
        if r then
            self.detail:Hide()
            self.selectedIndex = self.selectedIndex ~= r.index and r.index or nil
            self:Refresh()
            if self.selectedIndex and self.selectedOffset then self.scroll:SetVerticalScroll(math.min(self.selectedOffset, math.max(0, self.child:GetHeight() - self.scroll:GetHeight()))) end
        end
    end)
    current:HookScript("OnLeave", GameTooltip_Hide)
    self.current = current
    local nextRow = CreateFrame("Frame", nil, page)
    nextRow:SetPoint("TOPLEFT", 14, -224)
    nextRow:SetPoint("TOPRIGHT", -14, -224)
    nextRow:SetHeight(48)
    RP.Widgets:ApplyRelicCard(nextRow, 0.75, 0.55)
    nextRow.icon = nextRow:CreateTexture(nil, "ARTWORK")
    nextRow.icon:SetSize(28, 28)
    nextRow.icon:SetPoint("LEFT", 12, 0)
    nextRow.text = Text(nextRow, "GameFontHighlightSmall", 50, -8, 580)
    nextRow.text:SetHeight(35)
    self.nextRow = nextRow
    self.filters = {}
    for i, key in ipairs({ "all", "wanted" }) do
        local button = RP.Widgets:CreateButton(page, key == "all" and RP.L.LEGION_ALL or RP.L.WISH_TAB, 150, 24)
        button:SetPoint("TOPLEFT", 14 + (i - 1) * 158, -280)
        button:SetScript("OnClick", function()
            self.wantedOnly = key == "wanted"
            self.scroll:SetVerticalScroll(0)
            self:Refresh()
        end)
        self.filters[key] = button
    end
    local scroll = CreateFrame("ScrollFrame", nil, page)
    scroll:SetPoint("TOPLEFT", 14, -312)
    scroll:SetPoint("BOTTOMRIGHT", -14, 8)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(650, 13 * 32)
    scroll:SetScrollChild(child)
    self.scroll, self.child = scroll, child
    self.empty = Text(page, "GameFontDisableSmall", 24, -322, 580)
    self.empty:SetText(RP.L.WISH_EMPTY)
    self.empty:Hide()
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnSizeChanged", function(s, width)
        child:SetWidth(width)
        s:SetVerticalScroll(math.min(s:GetVerticalScroll(), math.max(0, child:GetHeight() - s:GetHeight())))
    end)
    scroll:SetScript("OnMouseWheel", function(s, delta)
        s:SetVerticalScroll(math.max(0, math.min(math.max(0, child:GetHeight() - s:GetHeight()), s:GetVerticalScroll() - delta * 32)))
    end)
    self.rows = {}
    for i, entry in ipairs(RP.SpecialExpeditionData.legion.entries) do
        local row = RP.Widgets:CreateButton(child, "", 650, 30)
        row:SetPoint("TOPLEFT", 0, -(i - 1) * 32)
        row:SetPoint("TOPRIGHT", 0, -(i - 1) * 32)
        row.text:SetText("")
        row.mark = row:CreateTexture(nil, "OVERLAY")
        row.mark:SetSize(6, 6)
        row.mark:SetPoint("LEFT", 12, 0)
        row.mark:SetRotation(math.pi / 4)
        row.wishMark = row:CreateTexture(nil, "OVERLAY")
        row.wishMark:SetColorTexture(0.95, 0.73, 0.28, 1)
        row.wishMark:SetSize(30, 1)
        row.wishMark:SetPoint("BOTTOMLEFT", 26, 3)
        row.wishMark:Hide()
        row.completed = RP.Widgets:CreateStatusMarker(row, "completed")
        row.completed:SetScale(0.6)
        row.completed:SetPoint("LEFT", 4, 0)
        row.completed:Hide()
        row.name = Text(row, "GameFontHighlightSmall", 26, -8, 380)
        row.status = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        row.status:SetPoint("RIGHT", -12, 0)
        row.status:SetWidth(210)
        row.status:SetJustifyH("RIGHT")
        row:HookScript("OnEnter", function(b)
            GameTooltip:SetOwner(b, "ANCHOR_RIGHT")
            GameTooltip:SetItemByID(entry.itemID)
        end)
        row:HookScript("OnLeave", GameTooltip_Hide)
        row:SetScript("OnClick", function()
            self.detail:Hide()
            self.selectedIndex = self.selectedIndex ~= i and i or nil
            self:Refresh()
        end)
        self.rows[i] = row
    end
    local detail = CreateFrame("Frame", nil, child)
    detail:SetSize(650, 174)
    detail:SetFrameLevel(page:GetFrameLevel() + 30)
    detail:EnableMouse(true)
    RP.Widgets:ApplyRelicCard(detail, 1, 1)
    detail.icon = CreateFrame("Button", nil, detail)
    detail.icon:SetSize(56, 56)
    detail.icon:SetPoint("TOPLEFT", 14, -14)
    detail.icon.texture = detail.icon:CreateTexture(nil, "ARTWORK")
    detail.icon.texture:SetAllPoints()
    detail.icon.texture:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    detail.icon:SetScript("OnEnter", function(b)
        local entry = self.selectedIndex and RP.SpecialExpeditionData.legion.entries[self.selectedIndex]
        if entry then GameTooltip:SetOwner(b, "ANCHOR_RIGHT"); GameTooltip:SetItemByID(entry.itemID) end
    end)
    detail.icon:SetScript("OnLeave", GameTooltip_Hide)
    detail.text = Text(detail, "GameFontHighlightSmall", 82, -14, 530)
    detail.text:SetPoint("RIGHT", detail, "RIGHT", -18, 0)
    detail.text:SetHeight(32)
    detail.text:SetJustifyV("TOP")
    detail.description = Text(detail, "GameFontHighlightSmall", 82, -49, 530)
    detail.description:SetPoint("RIGHT", detail, "RIGHT", -18, 0)
    detail.description:SetHeight(40)
    detail.description:SetMaxLines(3)
    detail.description:SetJustifyV("TOP")
    detail.description:SetTextColor(0.84, 0.80, 0.70)
    detail.dates = Text(detail, "GameFontDisableSmall", 14, -96, 610)
    detail.dates:SetPoint("RIGHT", detail, "RIGHT", -18, 0)
    detail.dates:SetHeight(30)
    detail.dates:SetJustifyV("TOP")
    local close = CreateFrame("Button", nil, detail, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT")
    close:SetScript("OnClick", function() self.selectedIndex = nil; self:Refresh() end)
    detail.wish = RP.Widgets:CreateButton(detail, "", 292, 26)
    detail.wish:SetPoint("BOTTOMLEFT", 14, 12)
    detail.wish:SetScript("OnClick", function()
        local entry = self.selectedIndex and RP.SpecialExpeditionData.legion.entries[self.selectedIndex]
        if entry then RP.LegionExpeditions:ToggleWish(entry); self:RefreshWishButton() end
    end)
    detail.calendar = RP.Widgets:CreateButton(detail, RP.L.CALENDAR_ADD, 292, 26)
    detail.calendar:SetPoint("BOTTOMRIGHT", -14, 12)
    detail.calendar:SetScript("OnClick", function()
        if self.selectedIndex then RP.LegionExpeditions:PrepareCalendar(self.selectedIndex) end
    end)
    detail:Hide()
    RP.Theme:BindAppearance(detail, 0.24)
    self.detail = detail
    page:SetScript("OnShow", function()
        self:Refresh()
        if self.timer then self.timer:Cancel() end
        self.timer = C_Timer.NewTicker(30, function() self:Refresh() end)
    end)
    page:SetScript("OnHide", function()
        if self.timer then self.timer:Cancel(); self.timer = nil end
        detail:Hide()
    end)
    RP:On("SPECIAL_EXPEDITIONS_UPDATED", self, self.Refresh)
    return page
end

function Page:RefreshWishButton()
    local entry = self.selectedIndex and RP.SpecialExpeditionData.legion.entries[self.selectedIndex]
    if not entry then return end
    local wanted = RP.LegionExpeditions:IsWanted(entry)
    self.detail.wish:SetText(wanted and RP.L.WISH_REMOVE or RP.L.WISH_ADD)
    self.detail.wish:SetAccent(wanted)
end

function Page:RefreshDetail()
    local entry = RP.SpecialExpeditionData.legion.entries[self.selectedIndex]
    local service = RP.LegionExpeditions
    local info, rotation = service:GetInfo(entry), service:GetRotation()
    self.detail.icon.texture:SetTexture(info.icon)
    self.detail.text:SetText(info.name .. "\n" .. info.race .. " • " .. info.kind
        .. " • " .. (info.completed and RP.L.LEGION_DONE or RP.L.LEGION_NOT_DONE))
    self.detail.description:SetText(service:GetRewardDescription(entry))
    if rotation then
        local starts = rotation.index == self.selectedIndex and rotation.starts or service:GetNextStart(self.selectedIndex, rotation)
        self.detail.dates:SetText(RP.L.LEGION_BEGINS .. service:Date(starts) .. "\n"
            .. RP.L.LEGION_ENDS .. service:Date(starts + RP.SpecialExpeditionData.legion.period))
    else self.detail.dates:SetText(RP.L.LEGION_UNKNOWN) end
end

function Page:Details(index)
    local entry = RP.SpecialExpeditionData.legion.entries[index]
    local info, rotation = RP.LegionExpeditions:GetInfo(entry), RP.LegionExpeditions:GetRotation()
    local result = info.name .. "\n" .. info.race .. " • " .. info.kind .. "\n"
    result = result .. (info.completed and RP.L.LEGION_DONE or (info.known and RP.L.LEGION_NOT_DONE or RP.L.LEGION_UNKNOWN))
    if RP.LegionExpeditions:IsWanted(entry) then result = result .. "\n" .. RP.L.WISH_TAB end
    if rotation and rotation.index == index then result = result .. "\n" .. RP.L.LEGION_NOW end
    if rotation then
        local starts = rotation.index == index and rotation.starts or RP.LegionExpeditions:GetNextStart(index, rotation)
        result = result .. "\n\n" .. RP.L.LEGION_BEGINS .. RP.LegionExpeditions:Date(starts)
            .. "\n" .. RP.L.LEGION_ENDS .. RP.LegionExpeditions:Date(starts + RP.SpecialExpeditionData.legion.period)
        if rotation.estimated then result = result .. "\n" .. RP.L.LEGION_ESTIMATED end
    end
    if info.progress ~= "" then result = result .. "\n\n" .. info.progress end
    return result
end

function Page:Refresh()
    if not self.frame or not self.frame:IsVisible() then return end
    local service = RP.LegionExpeditions
    if self.selectedIndex then
        self:RefreshDetail()
        self:RefreshWishButton()
    end
    local rotation = service:GetRotation()
    if not rotation then
        self.detail:Hide()
        self.empty:Hide()
        self.current.name:SetText(RP.L.LEGION_UNSUPPORTED)
        self.current.meta:SetText(""); self.current.time:SetText(""); self.current.progress:SetText("")
        self.current.action:Disable()
        self.nextRow.text:SetText(RP.L.LEGION_UNKNOWN)
        for _, row in ipairs(self.rows) do row:Hide() end
        return
    end
    local entries = RP.SpecialExpeditionData.legion.entries
    local info = service:GetInfo(entries[rotation.index])
    self.current.icon:SetTexture(info.icon)
    self.current.name:SetText(info.name)
    self.current.meta:SetText(info.race .. " • " .. info.kind .. (info.zone and " • " .. info.zone or "") .. (info.completed and " • " .. RP.L.LEGION_DONE or ""))
    self.current.time:SetText(RP.L.LEGION_REMAINING .. service:Duration(rotation.ends - rotation.now) .. "\n"
        .. RP.L.LEGION_ENDS .. service:Date(rotation.ends) .. (rotation.estimated and " *" or ""))
    self.current.progress:SetText(info.progress ~= "" and info.progress or (info.completed and RP.L.LEGION_DONE or (info.known and RP.L.LEGION_NOT_DONE or RP.L.LEGION_UNKNOWN)))
    self.current.action:SetText(info.activeQuest and RP.L.LEGION_CONTINUE or RP.L.LEGION_CONTACT)
    self.current.action:Enable()
    self.current.action:SetAccent(true)
    local nextInfo = service:GetInfo(entries[rotation.nextIndex])
    self.nextRow.icon:SetTexture(nextInfo.icon)
    self.nextRow.text:SetText(RP.L.LEGION_NEXT .. ": " .. nextInfo.name .. "\n" .. service:Duration(rotation.ends - rotation.now) .. " • " .. service:Date(rotation.ends))
    local visible, offset, expanded = 0, 0, false
    self.filters.all:SetAccent(not self.wantedOnly)
    self.filters.wanted:SetAccent(self.wantedOnly)
    for i, row in ipairs(self.rows) do
        local item = service:GetInfo(entries[i])
        local active = i == rotation.index
        local show = not self.wantedOnly or service:IsWanted(entries[i])
        row:SetShown(show)
        if show then
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 0, -offset)
            row:SetPoint("TOPRIGHT", 0, -offset)
            offset = offset + 32
            if self.selectedIndex == i then
                self.selectedOffset = offset - 32
                self.detail:ClearAllPoints()
                self.detail:SetPoint("TOPLEFT", 0, -offset)
                self.detail:SetPoint("TOPRIGHT", 0, -offset)
                offset = offset + self.detail:GetHeight() + 8
                expanded = true
            end
            visible = visible + 1
        end
        row.name:SetText(item.name .. (entries[i].kind == "mount" and " • " .. RP.L.LEGION_KIND_mount or ""))
        row.name:SetTextColor(entries[i].kind == "mount" and 0.95 or 0.85, entries[i].kind == "mount" and 0.76 or 0.82, entries[i].kind == "mount" and 0.4 or 0.74)
        row.status:SetText(active and RP.L.LEGION_NOW or (item.completed and RP.L.LEGION_DONE or
            service:Duration(service:GetNextStart(i, rotation) - rotation.now)))
        row.mark:SetColorTexture(active and 1 or (item.completed and 0.4 or 0.5), active and 0.76 or (item.completed and 0.75 or 0.5), active and 0.25 or 0.4, 1)
        row.mark:SetShown(not item.completed)
        row.completed:SetShown(item.completed)
        row.wishMark:SetShown(service:IsWanted(entries[i]))
        row:SetAccent(active)
    end
    self.detail:SetShown(expanded)
    self.child:SetHeight(math.max(1, offset))
    self.empty:SetShown(visible == 0)
    self.scroll:SetVerticalScroll(math.min(self.scroll:GetVerticalScroll(), math.max(0, self.child:GetHeight() - self.scroll:GetHeight())))
end
