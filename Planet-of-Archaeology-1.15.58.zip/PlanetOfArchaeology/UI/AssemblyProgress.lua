local _, RP = ...

local Progress = {}
RP:RegisterModule("AssemblyProgress", Progress)

-- Only suppress a duplicate restoration bar while our own display is visible.
-- Keep Blizzard's events, cast state and the alpha it would otherwise use intact.
function Progress:UpdateCastbar()
    local bar, state = PlayerCastingBarFrame, self.state
    if not bar or self.settingCastAlpha then return end
    local spellID = bar.spellID
    local readable = not issecretvalue or not issecretvalue(spellID)
    local suppress = readable and state and state.phase ~= "pending" and spellID == state.spellID
        and self.display and self.display:IsVisible()
    self.settingCastAlpha = true
    if suppress then
        if not self.castSuppressed then
            self.castAlpha = bar:GetAlpha()
            self.suppressedSpellID = spellID
        end
        self.castSuppressed = true
        -- Blizzard's PlayFadeAnim requires GetAlpha() > 0 to finish the cast.
        -- An effectively invisible, nonzero alpha preserves that lifecycle.
        bar:SetAlpha(0.001)
    elseif self.castSuppressed then
        self.castSuppressed = nil
        -- Never reveal a completed suppressed cast when our result message expires.
        -- If the player has begun another cast/channel, leave its visibility alone.
        if readable and spellID == self.suppressedSpellID
            and not UnitCastingInfo("player") and not UnitChannelInfo("player") then
            bar:Hide()
        end
        bar:SetAlpha(self.castAlpha or 1)
        self.castAlpha = nil
        self.suppressedSpellID = nil
    end
    self.settingCastAlpha = nil
end

function Progress:IsBusy()
    return self.state and (self.state.phase == "pending" or self.state.phase == "casting")
end

function Progress:Prepare(raceIndex, artifact)
    if self:IsBusy() or not artifact or not artifact.spellID then return false end
    self.state = { raceIndex = raceIndex, name = artifact.name, spellID = artifact.spellID,
        phase = "pending", deadline = GetTime() + 2, value = 0 }
    self.driver:Show()
    return true
end

function Progress:Finish(success)
    local state = self.state
    if not self:IsBusy() then return end
    state.phase = success and "complete" or "cancelled"
    state.revealedAt = state.revealedAt or GetTime()
    state.deadline = GetTime() + (success and 2 or 1.2)
    if success then state.value = 1 end
    self:Render()
end

function Progress:CreateDisplay(parent)
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetHeight(32)
    frame:SetPoint("BOTTOMLEFT", 42, 84)
    frame:SetPoint("BOTTOMRIGHT", -42, 84)
    frame.label = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.label:SetPoint("TOPLEFT")
    frame.label:SetPoint("TOPRIGHT")
    frame.label:SetJustifyH("LEFT")
    frame.label:SetWordWrap(false)
    frame.bar = RP.Widgets:CreateProgress(frame, 594, 8)
    frame.bar:SetPoint("BOTTOMLEFT")
    frame.bar:SetPoint("BOTTOMRIGHT")
    frame.bar:SetMinMaxValues(0, 1)
    frame.spark = frame.bar:CreateTexture(nil, "OVERLAY")
    frame.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
    frame.spark:SetBlendMode("ADD")
    frame.spark:SetSize(16, 22)
    frame.spark:SetVertexColor(1, 0.82, 0.40, 0.75)
    frame:Hide()
    self.display = frame
    frame:HookScript("OnHide", function() self:UpdateCastbar() end)
    return frame
end

function Progress:Render()
    local frame, state = self.display, self.state
    if not frame then return end
    local page = RP.MainFrame and RP.MainFrame.pages and RP.MainFrame.pages.projects
    local selected = page and page.projectState
    local visible = state and state.phase ~= "pending" and selected
        and selected.race.index == state.raceIndex
    frame:SetShown(visible and true or false)
    self:UpdateCastbar()
    if not visible then return end
    local remaining = state.phase == "casting" and math.max(0, state.ends - GetTime()) or 0
    local label = state.phase == "complete" and RP.L.RESTORE_COMPLETE
        or state.phase == "cancelled" and RP.L.RESTORE_CANCELLED
        or RP.L.RESTORE_CAST:format(remaining)
    local text = label .. "  •  " .. (state.name or "")
    if frame.lastText ~= text then
        frame.label:SetText(text)
        frame.lastText = text
    end
    frame.bar:SetValue(state.value)
    if state.phase == "complete" then
        frame.bar:SetStatusBarColor(0.42, 0.76, 0.37)
    elseif state.phase == "cancelled" then
        frame.bar:SetStatusBarColor(0.65, 0.27, 0.20)
    else
        frame.bar:SetStatusBarColor(0.82, 0.59, 0.23)
    end
    frame.spark:SetShown(state.phase == "casting")
    frame.spark:ClearAllPoints()
    frame.spark:SetPoint("CENTER", frame.bar, "LEFT", frame.bar:GetWidth() * state.value, 0)
    frame:SetAlpha(math.min(1, math.max(0, (GetTime() - (state.revealedAt or GetTime())) / 0.16),
        math.max(0, (state.deadline - GetTime()) / 0.3)))
end

function Progress:UpdateCast()
    local state = self.state
    if not self:IsBusy() then return end
    local name, _, _, startMS, endMS, _, _, _, spellID = UnitCastingInfo("player")
    if name and spellID == state.spellID and startMS and endMS then
        state.phase = "casting"
        state.revealedAt = state.revealedAt or GetTime()
        state.starts, state.ends = startMS / 1000, endMS / 1000
        state.deadline = state.ends + 1
    end
end

function Progress:OnInitialize()
    self.driver = CreateFrame("Frame")
    self.driver:Hide()
    for _, event in ipairs({ "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_DELAYED",
        "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_INTERRUPTED" }) do
        self.driver:RegisterUnitEvent(event, "player")
    end
    self.driver:RegisterEvent("RESEARCH_ARTIFACT_COMPLETE")
    self.driver:SetScript("OnEvent", function(_, event, unit, _, spellID)
        if not self:IsBusy() then return end
        if event == "RESEARCH_ARTIFACT_COMPLETE" then
            if unit == self.state.name then self:Finish(true) end
        elseif unit == "player" and spellID == self.state.spellID then
            if event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_DELAYED" then
                self:UpdateCast()
            elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
                self:Finish(true)
            else
                self:Finish(false)
            end
        end
    end)
    self.driver:SetScript("OnUpdate", function()
        local state = self.state
        if not state then self.driver:Hide(); return end
        local now = GetTime()
        if now >= state.deadline then
            if self:IsBusy() then self:Finish(false)
            else self.state = nil; self.driver:Hide() end
        elseif state.phase == "casting" then
            state.value = math.max(0, math.min(1, (now - state.starts) / math.max(0.001, state.ends - state.starts)))
        end
        self:Render()
    end)
end

-- Skin only the artwork: Blizzard retains events, edit-mode placement and lifetime.
function Progress:SkinDigsiteBar()
    local frame = ArcheologyDigsiteProgressBar
    if not frame or frame.relicSkinned then return end
    frame.relicSkinned = true
    -- Finish the native bar normally, but do not enqueue its duplicate toast.
    -- PlanetOfArchaeology's ARTIFACT_DIGSITE_COMPLETE handler already shows the result.
    if frame.AnimOutAndTriggerToast then
        frame.AnimOutAndTriggerToast:SetScript("OnFinished", function()
            frame.shouldShow = false
            frame:UpdateShownState()
            if SOUNDKIT and SOUNDKIT.UI_DIG_SITE_COMPLETION_TOAST then
                PlaySound(SOUNDKIT.UI_DIG_SITE_COMPLETION_TOAST)
            end
        end)
    end
    frame.Shadow:SetAlpha(0)
    frame.BarBorderAndOverlay:SetAlpha(0)
    frame.Flash:SetTexture(nil)
    frame.BarBackground:SetTexture("Interface\\Buttons\\WHITE8X8")
    frame.BarBackground:SetTexCoord(0, 1, 0, 1)
    frame.BarBackground:SetVertexColor(0.035, 0.027, 0.020, 0.75)
    frame.FillBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    frame.FillBar:SetStatusBarColor(0.70, 0.49, 0.20)
    frame.BarTitle:SetTextColor(0.85, 0.72, 0.46)
    local border = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    border:SetPoint("TOPLEFT", frame.FillBar, "TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", frame.FillBar, "BOTTOMRIGHT", 1, -1)
    border:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    border:SetBackdropBorderColor(0.56, 0.41, 0.23, 0.85)
    frame.relicBorder = border
    self:AnimateDigsiteBar(frame)
end

function Progress:AnimateDigsiteBar(frame)
    -- Hide only the stock fill texture; it remains the authoritative data source.
    frame.FillBar:SetAlpha(0)
    local bar = CreateFrame("StatusBar", nil, frame)
    bar:SetAllPoints(frame.FillBar)
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetStatusBarColor(0.70, 0.49, 0.20)
    local spark = bar:CreateTexture(nil, "OVERLAY")
    spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
    spark:SetBlendMode("ADD")
    spark:SetSize(12, 18)
    spark:SetVertexColor(1, 0.79, 0.34, 0.7)
    spark:Hide()
    local function Update(completed, total, animate)
        completed, total = tonumber(completed), tonumber(total)
        if not completed or not total or total <= 0 then return end
        local value = math.max(0, math.min(total, completed))
        local previous = bar:GetValue()
        local sameSite = bar.total == total
        bar.total = total
        bar:SetMinMaxValues(0, total)
        bar:SetScript("OnUpdate", nil)
        spark:Hide()
        if not animate or not sameSite or value <= previous or not frame:IsShown() then
            bar:SetValue(value)
            return
        end
        local elapsed = 0
        bar:SetScript("OnUpdate", function(_, dt)
            elapsed = elapsed + dt
            local t = math.min(1, elapsed / 0.6)
            local shown = previous + (value - previous) * (1 - (1 - t) ^ 3)
            bar:SetValue(shown)
            spark:ClearAllPoints()
            spark:SetPoint("CENTER", bar, "LEFT", bar:GetWidth() * shown / total, 0)
            spark:SetAlpha(math.sin(math.pi * t) * 0.75)
            spark:Show()
            if t >= 1 then bar:SetScript("OnUpdate", nil); spark:Hide() end
        end)
    end
    hooksecurefunc(frame, "OnSurveyCast", function(_, completed, total) Update(completed, total, false) end)
    hooksecurefunc(frame, "OnFindComplete", function(_, completed, total) Update(completed, total, true) end)
    frame:HookScript("OnHide", function()
        bar:SetScript("OnUpdate", nil)
        spark:Hide()
    end)
    local _, total = frame.FillBar:GetMinMaxValues()
    Update(frame.FillBar:GetValue(), total, false)
    frame.relicAnimatedFill = bar
end

function Progress:OnLogin()
    self:SkinDigsiteBar()
    local bar = PlayerCastingBarFrame
    if bar then
        hooksecurefunc(bar, "SetAlpha", function(_, alpha)
            if self.settingCastAlpha then return end
            if self.castSuppressed then self.castAlpha = alpha end
            self:UpdateCastbar()
        end)
        bar:HookScript("OnShow", function() self:UpdateCastbar() end)
        bar:HookScript("OnEvent", function() self:UpdateCastbar() end)
    end
end
