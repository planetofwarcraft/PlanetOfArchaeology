local _, RP = ...

local Theme = {}
RP:RegisterModule("Theme", Theme)

Theme.colors = {
    charcoal = { 0.020, 0.017, 0.014, 0.96 },
    brown = { 0.090, 0.054, 0.030, 0.96 },
    bronze = { 0.46, 0.34, 0.20, 1 },
    gold = { 0.92, 0.66, 0.22, 1 },
    parchment = { 0.91, 0.86, 0.75, 1 },
    ink = { 0.16, 0.09, 0.04, 1 },
    muted = { 0.59, 0.53, 0.44, 1 },
    green = { 0.35, 0.80, 0.39, 1 },
    amber = { 0.98, 0.68, 0.08, 1 },
    disabled = { 0.33, 0.31, 0.28, 1 },
}
RP.colors = Theme.colors

Theme.states = {
    normal = {
        border = { 0.48, 0.36, 0.22, 0.88 },
        inner = { 0.78, 0.58, 0.29, 0.22 },
        fill = { 0.030, 0.024, 0.019, 0.88 },
        overlay = { 0.18, 0.09, 0.025, 0.00 },
    },
    hover = {
        border = { 0.88, 0.64, 0.25, 0.98 },
        inner = { 1.00, 0.76, 0.31, 0.42 },
        fill = { 0.045, 0.031, 0.021, 0.94 },
        overlay = { 0.42, 0.20, 0.045, 0.12 },
    },
    pressed = {
        border = { 0.72, 0.43, 0.13, 1.00 },
        inner = { 0.92, 0.57, 0.18, 0.36 },
        fill = { 0.060, 0.034, 0.018, 0.98 },
        overlay = { 0.30, 0.11, 0.025, 0.16 },
    },
    selected = {
        border = { 1.00, 0.72, 0.20, 1.00 },
        inner = { 1.00, 0.86, 0.46, 0.58 },
        fill = { 0.052, 0.036, 0.021, 0.96 },
        overlay = { 0.48, 0.22, 0.040, 0.14 },
    },
    completed = {
        border = { 0.61, 0.48, 0.27, 0.96 },
        inner = { 0.46, 0.78, 0.38, 0.30 },
        fill = { 0.028, 0.027, 0.020, 0.92 },
        overlay = { 0.08, 0.24, 0.08, 0.08 },
    },
    progress = {
        border = { 0.74, 0.50, 0.16, 0.98 },
        inner = { 0.98, 0.68, 0.10, 0.36 },
        fill = { 0.042, 0.030, 0.018, 0.94 },
        overlay = { 0.42, 0.20, 0.025, 0.10 },
    },
    disabled = {
        border = { 0.31, 0.29, 0.26, 0.78 },
        inner = { 0.40, 0.37, 0.32, 0.18 },
        fill = { 0.022, 0.021, 0.019, 0.82 },
        overlay = { 0.10, 0.10, 0.10, 0.22 },
    },
}

local function ColorTexture(texture, color, multiplier)
    multiplier = multiplier or 1
    texture:SetColorTexture(color[1], color[2], color[3], (color[4] or 1) * multiplier)
end

local function CreateLine(parent, layer, subLevel)
    local texture = parent:CreateTexture(nil, layer or "BORDER", nil, subLevel or 0)
    texture:SetTexture("Interface\\Buttons\\WHITE8X8")
    -- Thin borders must keep fractional coverage while a window is scaled.
    texture:SetSnapToPixelGrid(false)
    texture:SetTexelSnappingBias(0)
    return texture
end

function Theme:ApplyNineSlice(frame, options)
    if frame.RelicNineSlice then return frame.RelicNineSlice end
    options = options or {}
    local cut = options.cut or 9
    local ns = { pieces = {}, options = options }

    local function CreateChamferFill(layer, subLevel, inset, texturePath)
        inset = inset or 0
        local radius = math.max(1, cut - inset)
        local segmentCount = math.max(2, math.ceil(radius / 2))
        local segmentHeight = radius / segmentCount
        local pieces = {}
        local function AddPiece(texture)
            texture:SetTexture(texturePath or "Interface\\Buttons\\WHITE8X8")
            pieces[#pieces + 1] = texture
            return texture
        end
        local middle = AddPiece(frame:CreateTexture(nil, layer, nil, subLevel))
        middle:SetPoint("TOPLEFT", inset, -cut)
        middle:SetPoint("BOTTOMRIGHT", -inset, cut)
        for index = 1, segmentCount do
            local distance = (index - 1) * segmentHeight
            local sideInset = inset + radius - ((index - 0.5) * segmentHeight)
            local top = AddPiece(frame:CreateTexture(nil, layer, nil, subLevel))
            top:SetPoint("TOPLEFT", sideInset, -(inset + distance))
            top:SetPoint("TOPRIGHT", -sideInset, -(inset + distance))
            top:SetHeight(segmentHeight)

            local bottom = AddPiece(frame:CreateTexture(nil, layer, nil, subLevel))
            bottom:SetPoint("BOTTOMLEFT", sideInset, inset + distance)
            bottom:SetPoint("BOTTOMRIGHT", -sideInset, inset + distance)
            bottom:SetHeight(segmentHeight)
        end
        return pieces
    end

    ns.FillPieces = CreateChamferFill("BACKGROUND", -8, 0)
    ns.Center, ns.CenterTop, ns.CenterBottom = unpack(ns.FillPieces)
    ns.GrainPieces = CreateChamferFill("BACKGROUND", -7, 0, "Interface\\FrameGeneral\\UI-Background-Rock")
    ns.Grain, ns.GrainTop, ns.GrainBottom = unpack(ns.GrainPieces)
    for i = 1, #ns.GrainPieces do ns.GrainPieces[i]:SetAlpha(options.grainAlpha or 0.10) end
    ns.OverlayPieces = CreateChamferFill("BACKGROUND", -6, 2)
    ns.Overlay, ns.OverlayTop, ns.OverlayBottom = unpack(ns.OverlayPieces)

    ns.TopEdge = CreateLine(frame, "BORDER", 1)
    ns.TopEdge:SetPoint("TOPLEFT", cut, -1)
    ns.TopEdge:SetPoint("TOPRIGHT", -cut, -1)
    ns.TopEdge:SetHeight(1)
    ns.BottomEdge = CreateLine(frame, "BORDER", 1)
    ns.BottomEdge:SetPoint("BOTTOMLEFT", cut, 1)
    ns.BottomEdge:SetPoint("BOTTOMRIGHT", -cut, 1)
    ns.BottomEdge:SetHeight(1)
    ns.LeftEdge = CreateLine(frame, "BORDER", 1)
    ns.LeftEdge:SetPoint("TOPLEFT", 1, -cut)
    ns.LeftEdge:SetPoint("BOTTOMLEFT", 1, cut)
    ns.LeftEdge:SetWidth(1)
    ns.RightEdge = CreateLine(frame, "BORDER", 1)
    ns.RightEdge:SetPoint("TOPRIGHT", -1, -cut)
    ns.RightEdge:SetPoint("BOTTOMRIGHT", -1, cut)
    ns.RightEdge:SetWidth(1)

    ns.TopLeftCorner = CreateLine(frame, "BORDER", 2)
    ns.TopLeftCorner:SetSize(1, cut * 1.42)
    ns.TopLeftCorner:SetPoint("CENTER", frame, "TOPLEFT", cut / 2, -cut / 2)
    ns.TopLeftCorner:SetRotation(math.rad(-45))
    ns.TopRightCorner = CreateLine(frame, "BORDER", 2)
    ns.TopRightCorner:SetSize(1, cut * 1.42)
    ns.TopRightCorner:SetPoint("CENTER", frame, "TOPRIGHT", -cut / 2, -cut / 2)
    ns.TopRightCorner:SetRotation(math.rad(45))
    ns.BottomLeftCorner = CreateLine(frame, "BORDER", 2)
    ns.BottomLeftCorner:SetSize(1, cut * 1.42)
    ns.BottomLeftCorner:SetPoint("CENTER", frame, "BOTTOMLEFT", cut / 2, cut / 2)
    ns.BottomLeftCorner:SetRotation(math.rad(45))
    ns.BottomRightCorner = CreateLine(frame, "BORDER", 2)
    ns.BottomRightCorner:SetSize(1, cut * 1.42)
    ns.BottomRightCorner:SetPoint("CENTER", frame, "BOTTOMRIGHT", -cut / 2, cut / 2)
    ns.BottomRightCorner:SetRotation(math.rad(-45))

    ns.InnerTop = CreateLine(frame, "BACKGROUND", -5)
    ns.InnerTop:SetPoint("TOPLEFT", cut + 2, -4)
    ns.InnerTop:SetPoint("TOPRIGHT", -cut - 2, -4)
    ns.InnerTop:SetHeight(1)
    ns.InnerBottom = CreateLine(frame, "BACKGROUND", -5)
    ns.InnerBottom:SetPoint("BOTTOMLEFT", cut + 2, 4)
    ns.InnerBottom:SetPoint("BOTTOMRIGHT", -cut - 2, 4)
    ns.InnerBottom:SetHeight(1)

    ns.pieces = {
        ns.TopEdge, ns.BottomEdge, ns.LeftEdge, ns.RightEdge,
        ns.TopLeftCorner, ns.TopRightCorner, ns.BottomLeftCorner, ns.BottomRightCorner,
    }
    frame.RelicNineSlice = ns
    frame.SetRelicState = function(owner, state, persistent)
        Theme:SetState(owner, state, persistent)
    end
    self:SetState(frame, options.state or "normal", true)
    return ns
end

local transitions = {}
local motionDriver
local colorKeys = { "border", "inner", "fill", "overlay" }

local function CopyPalette(source)
    local result = {}
    for _, key in ipairs(colorKeys) do
        result[key] = { unpack(source[key]) }
    end
    return result
end

function Theme:PaintState(frame, spec)
    local ns = frame and frame.RelicNineSlice
    if not ns then return end
    local borderAlpha = ns.options.borderAlpha or 1
    local fillAlpha = ns.options.fillAlpha or 1
    for i = 1, #ns.pieces do ColorTexture(ns.pieces[i], spec.border, borderAlpha) end
    ColorTexture(ns.InnerTop, spec.inner, borderAlpha)
    ColorTexture(ns.InnerBottom, spec.inner, borderAlpha)
    if ns.options.transparentCenter then
        for i = 1, #ns.FillPieces do ns.FillPieces[i]:SetColorTexture(0, 0, 0, 0) end
        for i = 1, #ns.OverlayPieces do ns.OverlayPieces[i]:SetColorTexture(0, 0, 0, 0) end
        for i = 1, #ns.GrainPieces do ns.GrainPieces[i]:Hide() end
    else
        for i = 1, #ns.FillPieces do ColorTexture(ns.FillPieces[i], spec.fill, fillAlpha) end
        for i = 1, #ns.OverlayPieces do ColorTexture(ns.OverlayPieces[i], spec.overlay, fillAlpha) end
        for i = 1, #ns.GrainPieces do ns.GrainPieces[i]:Show() end
    end
end

function Theme:SetState(frame, state, persistent)
    if not frame or not frame.RelicNineSlice then return end
    state = self.states[state] and state or "normal"
    if persistent then
        frame.relicPersistentState = state
        if frame.relicInteractive and state ~= "disabled" and frame:IsEnabled() then
            if frame.relicMouseDown then state = "pressed"
            elseif frame:IsMouseOver() then state = "hover" end
        end
    end
    if frame.relicInteractive and not frame:IsEnabled() then state = "disabled" end
    if frame.relicVisualState == state then return end
    frame.relicVisualState = state
    local target = self.states[state]
    if not frame.relicPalette or not frame:IsVisible() or not frame.relicInteractive then
        transitions[frame] = nil
        frame.relicPalette = CopyPalette(target)
        self:PaintState(frame, target)
        return
    end
    transitions[frame] = { from = CopyPalette(frame.relicPalette), target = target,
        elapsed = 0, duration = state == "pressed" and 0.07 or 0.16 }
    if not motionDriver then
        motionDriver = CreateFrame("Frame")
        motionDriver:SetScript("OnUpdate", function(driver, elapsed)
            for owner, transition in pairs(transitions) do
                transition.elapsed = transition.elapsed + elapsed
                local t = math.min(1, transition.elapsed / transition.duration)
                if not owner:IsVisible() then t = 1 end
                local eased = 1 - (1 - t) ^ 3
                for _, key in ipairs(colorKeys) do
                    for i = 1, 4 do
                        owner.relicPalette[key][i] = transition.from[key][i]
                            + (transition.target[key][i] - transition.from[key][i]) * eased
                    end
                end
                Theme:PaintState(owner, owner.relicPalette)
                if t == 1 then transitions[owner] = nil end
            end
            if not next(transitions) then driver:Hide() end
        end)
    end
    motionDriver:Show()
end

-- Native alpha animations keep layout and the user's saved opacity intact.
function Theme:BindAppearance(frame, duration, manual)
    if not frame or frame.relicAppearance then return end
    local group = frame:CreateAnimationGroup()
    local alpha = group:CreateAnimation("Alpha")
    alpha:SetFromAlpha(0)
    alpha:SetToAlpha(1)
    alpha:SetDuration(duration or 0.20)
    alpha:SetSmoothing("OUT")
    frame.relicAppearance = group
    local function Play(owner)
        local parent = owner:GetParent()
        while parent do
            if parent.relicAppearance and parent.relicAppearance:IsPlaying() then return end
            parent = parent:GetParent()
        end
        group:Stop()
        group:Play()
    end
    frame.PlayRelicAppearance = Play
    if not manual then frame:HookScript("OnShow", Play) end
    frame:HookScript("OnHide", function() group:Stop() end)
end

function Theme:OnLogin()
    self:BindAppearance(RP.MainFrame and RP.MainFrame.frame, 0.22)
    self:BindAppearance(RP.SiteTracker and RP.SiteTracker.frame, 0.22)
    self:BindAppearance(RP.HUD and RP.HUD.frame, 0.18)
    self:BindAppearance(RP.MinimapButton and RP.MinimapButton.menu, 0.16)
    for _, page in pairs(RP.MainFrame and RP.MainFrame.pages or {}) do
        self:BindAppearance(page, 0.16, true)
    end
end

function Theme:BindInteractive(frame)
    if frame.relicInteractive or type(frame.IsEnabled) ~= "function" then return end
    frame.relicInteractive = true
    frame:HookScript("OnHide", function(owner)
        owner.relicMouseDown = nil
        transitions[owner] = nil
        owner.relicVisualState = nil
        Theme:SetState(owner, owner.relicPersistentState or "normal")
    end)
    frame:HookScript("OnEnter", function(owner)
        if owner:IsEnabled() then Theme:SetState(owner, "hover") end
    end)
    frame:HookScript("OnLeave", function(owner)
        owner.relicMouseDown = nil
        Theme:SetState(owner, owner.relicPersistentState or "normal")
    end)
    frame:HookScript("OnMouseDown", function(owner)
        owner.relicMouseDown = true
        if owner:IsEnabled() then Theme:SetState(owner, "pressed") end
    end)
    frame:HookScript("OnMouseUp", function(owner)
        owner.relicMouseDown = nil
        if owner:IsEnabled() then Theme:SetState(owner, owner:IsMouseOver() and "hover" or (owner.relicPersistentState or "normal")) end
    end)
    frame:HookScript("OnDisable", function(owner) Theme:SetState(owner, "disabled") end)
    frame:HookScript("OnEnable", function(owner) Theme:SetState(owner, owner.relicPersistentState or "normal") end)
end

function Theme:ApplyPanel(frame, alpha)
    return self:ApplyNineSlice(frame, { cut = 11, fillAlpha = alpha or 0.90, borderAlpha = 0.92, grainAlpha = 0.08 })
end

function Theme:ApplyListItem(frame, compact)
    local ns = self:ApplyNineSlice(frame, { cut = compact and 7 or 9, fillAlpha = 0.94, borderAlpha = 0.94, grainAlpha = 0.07 })
    self:BindInteractive(frame)
    return ns
end

function Theme:ApplyButton(frame)
    local ns = self:ApplyNineSlice(frame, { cut = 7, fillAlpha = 0.98, borderAlpha = 1, grainAlpha = 0.06 })
    self:BindInteractive(frame)
    return ns
end

function Theme:ApplyTab(frame)
    local ns = self:ApplyNineSlice(frame, { cut = 8, fillAlpha = 0.72, borderAlpha = 0.78, grainAlpha = 0.04 })
    self:BindInteractive(frame)
    return ns
end

function Theme:ApplyIconBorder(frame, state)
    local ns = self:ApplyNineSlice(frame, { cut = 6, transparentCenter = true, borderAlpha = 1, grainAlpha = 0 })
    self:SetState(frame, state or "normal", true)
    self:BindInteractive(frame)
    return ns
end
