local _, RP = ...

local HUD = { elapsed = 0, shownByUser = true, surveyCompleted = 0, surveyTotal = 0 }
RP:RegisterModule("HUD", HUD)

local SURVEY_SPELL_ID = 80451

local function CropIcon(texture)
    texture:SetTexCoord(0.07, 0.93, 0.07, 0.93)
end

function HUD:OnInitialize()
    local frame = CreateFrame("Frame", "PlanetOfArchaeologySurveyWidget", UIParent)
    frame:SetSize(128, 146)
    -- Keep Blizzard panels above this window and its children.
    frame:SetFrameStrata("LOW")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetSize(22, 22)
    close:SetPoint("TOPRIGHT", 1, 1)
    close:SetFrameLevel(frame:GetFrameLevel() + 25)
    close:SetScript("OnClick", function() HUD:Hide() end)
    frame:SetScript("OnDragStart", function(f)
        if not RP.db.settings.lockHUD then f.relicDragging = true; f:StartMoving() end
    end)
    frame:SetScript("OnDragStop", function(f)
        f:StopMovingOrSizing()
        f.relicDragging = nil
        RP.Widgets:SavePosition(f, "hud")
    end)

    local shell = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    shell:SetAllPoints()
    shell:SetFrameLevel(frame:GetFrameLevel())
    RP.Widgets:ApplyRelicCard(shell, 1, 0.92)

    -- The Survey cast remains a genuine hardware action.
    local survey = CreateFrame("Button", "PlanetOfArchaeologySurveyActionButton", frame, "SecureActionButtonTemplate")
    survey:SetSize(44, 44)
    survey:SetPoint("TOP", 0, -10)
    survey:RegisterForClicks("AnyDown", "AnyUp")
    survey:SetAttribute("useOnKeyDown", false)
    survey:SetAttribute("type", "spell")
    survey:SetAttribute("spell", SURVEY_SPELL_ID)
    survey:EnableMouse(true)
    survey:SetNormalTexture("Interface\\Icons\\INV_Misc_Shovel_01")
    survey:SetPushedTexture("Interface\\Icons\\INV_Misc_Shovel_01")
    survey:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    local normalTexture, pushedTexture = survey:GetNormalTexture(), survey:GetPushedTexture()
    for _, texture in ipairs({ normalTexture, pushedTexture }) do
        if texture then
            texture:ClearAllPoints()
            texture:SetPoint("TOPLEFT", survey, "TOPLEFT", 4, -4)
            texture:SetPoint("BOTTOMRIGHT", survey, "BOTTOMRIGHT", -4, 4)
            CropIcon(texture)
        end
    end
    if pushedTexture then
        pushedTexture:ClearAllPoints()
        pushedTexture:SetPoint("TOPLEFT", survey, "TOPLEFT", 5, -5)
        pushedTexture:SetPoint("BOTTOMRIGHT", survey, "BOTTOMRIGHT", -3, 3)
    end
    RP.Theme:ApplyIconBorder(survey, "normal")

    local badge = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    badge:SetSize(20, 16)
    badge:SetPoint("TOPRIGHT", survey, "TOPRIGHT", 1, -1)
    badge:SetFrameLevel(survey:GetFrameLevel() + 4)
    RP.Theme:ApplyNineSlice(badge, { cut = 4, fillAlpha = 1, borderAlpha = 1, grainAlpha = 0 })
    badge:SetRelicState("progress", true)
    badge.text = badge:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    badge.text:SetPoint("CENTER")
    badge:Hide()

    local info = CreateFrame("Frame", nil, frame)
    info:SetPoint("TOP", 0, -59)
    info:SetSize(110, 18)
    info:EnableMouse(true)
    info:RegisterForDrag("LeftButton")
    info:SetScript("OnDragStart", function()
        if not RP.db.settings.lockHUD then frame.relicDragging = true; frame:StartMoving() end
    end)
    info:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        frame.relicDragging = nil
        RP.Widgets:SavePosition(frame, "hud")
    end)
    info.title = info:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    info.title:SetPoint("CENTER")
    info.title:SetWidth(110)
    info.title:SetJustifyH("CENTER")
    info.title:SetWordWrap(false)
    info.title:SetTextColor(unpack(RP.colors.parchment))
    info.detail = info:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    info.detail:SetPoint("BOTTOMLEFT", 1, 8)
    info.detail:SetPoint("RIGHT", -2, 0)
    info.detail:SetJustifyH("LEFT")
    info.detail:SetWordWrap(false)
    info.detail:Hide()

    frame.fragmentBar = RP.Widgets:CreateProgress(info, 94, 6)
    frame.fragmentBar:SetPoint("CENTER", 0, 0)
    frame.fragmentBar:SetStatusBarColor(0.78, 0.55, 0.22, 0.9)
    frame.fragmentBar:Hide()

    local divider = frame:CreateTexture(nil, "ARTWORK")
    divider:SetColorTexture(0.52, 0.38, 0.20, 0.62)
    divider:SetPoint("TOPLEFT", 10, -82)
    divider:SetSize(108, 1)

    local artifactButton = CreateFrame("Button", nil, frame)
    artifactButton:SetSize(36, 36)
    artifactButton:SetPoint("BOTTOMLEFT", 16, 12)
    artifactButton:RegisterForClicks("LeftButtonUp")
    artifactButton.icon = artifactButton:CreateTexture(nil, "ARTWORK")
    artifactButton.icon:SetPoint("TOPLEFT", 5, -5)
    artifactButton.icon:SetPoint("BOTTOMRIGHT", -5, 5)
    CropIcon(artifactButton.icon)
    RP.Theme:ApplyIconBorder(artifactButton, "normal")

    local artifactName = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    artifactName:SetPoint("TOPLEFT", artifactButton, "TOPRIGHT", 8, -1)
    artifactName:SetSize(104, 27)
    artifactName:SetJustifyH("LEFT")
    artifactName:SetJustifyV("TOP")
    artifactName:SetWordWrap(true)
    artifactName:SetMaxLines(2)
    artifactName:Hide()
    local artifactProgress = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    artifactProgress:SetPoint("TOP", 0, -89)
    artifactProgress:SetWidth(108)
    artifactProgress:SetJustifyH("CENTER")

    local keystone = CreateFrame("Button", nil, frame)
    keystone:SetSize(32, 32)
    keystone:SetPoint("BOTTOMLEFT", 62, 14)
    keystone:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    keystone.icon = keystone:CreateTexture(nil, "ARTWORK")
    keystone.icon:SetPoint("TOPLEFT", 5, -5)
    keystone.icon:SetPoint("BOTTOMRIGHT", -5, 5)
    CropIcon(keystone.icon)
    keystone.empty = keystone:CreateFontString(nil, "OVERLAY", "GameFontDisableLarge")
    keystone.empty:SetPoint("CENTER", 0, 1)
    keystone.empty:SetText("+")
    keystone.count = keystone:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    keystone.count:SetPoint("BOTTOMRIGHT", -2, 2)
    RP.Theme:ApplyIconBorder(keystone, "normal")

    survey:SetScript("OnEnter", function(button)
        button:SetRelicState("hover")
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        if GameTooltip.SetSpellByID then GameTooltip:SetSpellByID(SURVEY_SPELL_ID)
        else GameTooltip:AddLine(RP.L.SURVEY_ACTION) end
        GameTooltip:AddLine(RP.L.SURVEY_HINT, 0.35, 0.95, 0.45, true)
        GameTooltip:Show()
    end)
    survey:SetScript("OnLeave", function(button)
        button:SetRelicState("normal")
        GameTooltip_Hide()
    end)
    info:SetScript("OnEnter", function()
        GameTooltip:SetOwner(info, "ANCHOR_RIGHT")
        GameTooltip:AddLine(RP.L.MOVE_WINDOW)
        GameTooltip:Show()
    end)
    info:SetScript("OnLeave", GameTooltip_Hide)
    artifactButton:SetScript("OnEnter", function(button)
        local state = HUD.projectState
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        GameTooltip:AddLine(state and state.artifact and RP.Localization:DisplayName(state.artifact.name) or RP.L.CURRENT_ARTIFACT)
        if state and state.race then GameTooltip:AddLine(RP.Localization:DisplayName(state.race.name), 0.82, 0.68, 0.36) end
        if state then
            GameTooltip:AddLine(RP.L.ARTIFACT_PROGRESS:format(state.base or 0, state.adjusted or 0, state.required or 0), 1, 0.82, 0.35)
            if state.canSolve then GameTooltip:AddLine(RP.L.SOLVE_HINT, 0.40, 0.95, 0.45) end
        end
        GameTooltip:Show()
    end)
    artifactButton:SetScript("OnLeave", GameTooltip_Hide)
    artifactButton:SetScript("OnClick", function()
        local state = HUD.projectState
        if not state or not state.canSolve or not frame.raceIndex then return end
        if RP.Archaeology:Solve(frame.raceIndex) then
            C_Timer.After(0.25, function()
                RP.Archaeology:Refresh()
                HUD.projectState = nil
                HUD:Refresh(nil, true)
            end)
        end
    end)
    keystone:SetScript("OnEnter", function(button)
        local state = HUD.projectState
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        if state and state.race and state.race.keystoneItemID and GameTooltip.SetItemByID then
            GameTooltip:SetItemByID(state.race.keystoneItemID)
        else
            GameTooltip:AddLine(RP.L.KEYSTONES)
        end
        if state then
            GameTooltip:AddLine(RP.L.KEYSTONE_STATUS:format(state.socketed or 0, state.sockets or 0, state.race.keystones or 0), 1, 0.82, 0.35)
            GameTooltip:AddLine(RP.L.KEYSTONE_ADD, 0.40, 0.90, 0.45)
            GameTooltip:AddLine(RP.L.KEYSTONE_REMOVE, 0.72, 0.72, 0.72)
        end
        GameTooltip:Show()
    end)
    keystone:SetScript("OnLeave", GameTooltip_Hide)
    keystone:SetScript("OnClick", function(control, button)
        if not frame.raceIndex then return end
        if RP.Archaeology:ToggleKeystone(frame.raceIndex, button == "RightButton") then
            RP.Archaeology:Refresh()
            HUD.projectState = RP.Archaeology:GetProjectState(frame.raceIndex)
            HUD:Refresh()
            if control:IsMouseOver() then control:GetScript("OnEnter")(control) end
        end
    end)

    frame.scaleGrip = RP.Widgets:CreateScaleGrip(frame, 0.40, 1.60,
        function() return RP.db.settings.hudScale or 1 end,
        function(value)
            if InCombatLockdown() then return end
            RP.db.settings.hudScale = value
            self:ApplySettings()
            if RP.Settings then RP.Settings:RefreshPanel() end
        end)

    frame.surveyButton, frame.badge, frame.info = survey, badge, info
    frame.artifactButton, frame.artifactName, frame.artifactProgress = artifactButton, artifactName, artifactProgress
    frame.keystoneButton = keystone
    self.frame = frame
    self:RestorePosition()
    self:ApplySettings()
    frame:SetScript("OnUpdate", function(_, elapsed) self:OnUpdate(elapsed) end)
    frame:Hide()

    RP:On("TARGET_CHANGED", self, self.OnTargetChanged)
    RP:On("ARCHAEOLOGY_PROGRESS", self, self.OnProgress)
    RP:On("ARCHAEOLOGY_UPDATED", self, self.OnArchaeologyUpdated)
end

function HUD:ApplySettings()
    if not self.frame then return end
    local wanted = (RP.db.settings.hudScale or 1) * (RP.db.settings.uiScale or 1)
    self.frame:SetScale(RP.Widgets:GetPixelPerfectScale(wanted))
    self.frame:SetAlpha((RP.db.settings.hudOpacity or 1) * (RP.db.settings.uiOpacity or 1))
end

function HUD:RestorePosition()
    if self.frame then RP.Widgets:RestorePosition(self.frame, "hud") end
end

function HUD:Show()
    self.shownByUser = true
    self:Refresh(nil, true)
end

function HUD:Hide()
    self.openedFromWindow = nil
    self.shownByUser = false
    self.wantsVisible = false
    if not InCombatLockdown() then self.frame:Hide() end
end

function HUD:Toggle()
    if self.frame:IsShown() then self:Hide() else self:Show() end
end

function HUD:OnTargetChanged(site, reason)
    self.projectState = nil
    self.projectRaceIndex = nil
    self:Refresh(site, true)
    if site and RP.db.expedition.active then RP.Notifications:NewTarget(site, reason) end
end

function HUD:OnProgress(completed, total, branchID)
    self.surveyCompleted = tonumber(completed) or 0
    self.surveyTotal = tonumber(total) or 0
    self.surveyBranchID = branchID
    local site = RP.DigSites:GetCurrentSite()
    self.surveySiteID = site and site.researchSiteID
    self:Refresh(nil, true)
end

function HUD:OnArchaeologyUpdated()
    self.projectState = nil
    self:Refresh(nil, true)
end

function HUD:UpdateProject(race, force)
    if not race then
        self.projectState, self.projectRaceIndex = nil, nil
        return
    end
    if force or self.projectRaceIndex ~= race.index or not self.projectState then
        self.projectState = RP.Archaeology:GetProjectState(race.index)
        self.projectRaceIndex = race.index
    end
end

function HUD:Refresh(_, forceProject)
    if not self.frame or not RP.db then return end
    local scanOK, canScan = false, false
    if type(CanScanResearchSite) == "function" then scanOK, canScan = pcall(CanScanResearchSite) end
    local currentSite = RP.DigSites:GetCurrentSite()
    local shouldShow = self.openedFromWindow or (RP.db.expedition.active and RP.Expedition:IsDigging(currentSite) and self.shownByUser and scanOK and canScan)
    self.wantsVisible = shouldShow and true or false
    if self.layoutSuppressed then shouldShow = false end
    if not shouldShow then
        if not InCombatLockdown() then self.frame:Hide() end
        return
    end
    if not InCombatLockdown() then self.frame:Show() end

    local site = currentSite or RP.RoutePlanner.currentTarget
    local race = site and site.raceIndex and RP.Archaeology:GetRace(site.raceIndex)
    if scanOK and canScan and self.surveyBranchID and self.surveyTotal > self.surveyCompleted
        and (not self.surveySiteID or (currentSite and currentSite.researchSiteID == self.surveySiteID)) then
        local observed = RP.Archaeology:GetRaceByBranchID(self.surveyBranchID)
        if observed and observed.index then race = observed end
    elseif not canScan then
        self.surveyBranchID, self.surveySiteID = nil, nil
    end
    self.frame.raceIndex = race and race.index
    self:UpdateProject(race, forceProject)

    local completed, total = self.surveyCompleted or 0, self.surveyTotal or 0
    if total > 0 then
        local remaining = math.max(0, total - completed)
        self.frame.badge.text:SetText(remaining)
        self.frame.info.title:SetText(RP.L.FINDS_SHORT:format(remaining))
        self.frame.info.title:Show()
        self.frame.badge:Show()
    else
        self.frame.badge.text:SetText("")
        self.frame.badge:Hide()
        self.frame.info.title:SetText("")
        self.frame.info.title:Hide()
    end

    local state = self.projectState
    local required = state and state.required or 0
    local showFragments = total <= 0 and required > 0
    self.frame.fragmentBar:SetShown(showFragments)
    if showFragments then
        self.frame.fragmentBar:SetValue(math.max(0, math.min(1, ((state.base or 0) + (state.adjusted or 0)) / required)))
    end
    local artifact = state and state.artifact
    self.frame.artifactButton:SetShown(artifact ~= nil)
    self.frame.artifactButton.icon:SetTexture(artifact and artifact.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    self.frame.artifactName:SetText(artifact and RP.Localization:DisplayName(artifact.name) or RP.L.CURRENT_ARTIFACT)
    self.frame.artifactProgress:SetText(required > 0 and RP.L.ARTIFACT_PROGRESS_SHORT:format((state.base or 0) + (state.adjusted or 0), required) or "—")

    local keyIcon
    if race and race.keystoneItemID then
        if C_Item and C_Item.GetItemIconByID then keyIcon = C_Item.GetItemIconByID(race.keystoneItemID) end
        if not keyIcon and C_Item and C_Item.GetItemInfo then keyIcon = select(10, C_Item.GetItemInfo(race.keystoneItemID)) end
        if not keyIcon and GetItemInfo then keyIcon = select(10, GetItemInfo(race.keystoneItemID)) end
        if not keyIcon and C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(race.keystoneItemID) end
    end
    local hasSockets = state and state.sockets and state.sockets > 0 and race and race.keystoneItemID
    self.frame.keystoneButton:SetShown(hasSockets and true or false)
    if hasSockets then
        self.frame.keystoneButton.icon:SetTexture(keyIcon or "Interface\\Icons\\INV_Misc_QuestionMark")
        self.frame.keystoneButton.icon:SetShown((state.socketed or 0) > 0)
        self.frame.keystoneButton.empty:SetShown((state.socketed or 0) == 0)
        self.frame.keystoneButton.count:SetText((state.socketed or 0) .. "/" .. state.sockets)
        self.frame.keystoneButton:SetRelicState((state.socketed or 0) > 0 and "progress" or "normal", true)
    end

    self.frame.artifactButton:SetRelicState(state and state.canSolve and "selected" or "normal", true)
end

function HUD:OnUpdate(elapsed)
    self.elapsed = self.elapsed + elapsed
    if self.elapsed < 0.25 then return end
    self.elapsed = 0
    self:Refresh()
end
