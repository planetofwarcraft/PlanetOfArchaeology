local _, RP = ...

local MinimapButton = { elapsed = 0, layoutElapsed = 0, nearby = false }
RP:RegisterModule("MinimapButton", MinimapButton)

local minimapShapes = {
    ROUND = { true, true, true, true },
    SQUARE = { false, false, false, false },
    ["CORNER-TOPLEFT"] = { false, false, false, true },
    ["CORNER-TOPRIGHT"] = { false, false, true, false },
    ["CORNER-BOTTOMLEFT"] = { false, true, false, false },
    ["CORNER-BOTTOMRIGHT"] = { true, false, false, false },
    ["SIDE-LEFT"] = { false, true, false, true },
    ["SIDE-RIGHT"] = { true, false, true, false },
    ["SIDE-TOP"] = { false, false, true, true },
    ["SIDE-BOTTOM"] = { true, true, false, false },
    ["TRICORNER-TOPLEFT"] = { false, true, true, true },
    ["TRICORNER-TOPRIGHT"] = { true, false, true, true },
    ["TRICORNER-BOTTOMLEFT"] = { true, true, false, true },
    ["TRICORNER-BOTTOMRIGHT"] = { true, true, true, false },
}

local function Atan2(y, x)
    if math.atan2 then return math.atan2(y, x) end
    if x > 0 then return math.atan(y / x) end
    if x < 0 and y >= 0 then return math.atan(y / x) + math.pi end
    if x < 0 then return math.atan(y / x) - math.pi end
    return y >= 0 and math.pi / 2 or -math.pi / 2
end

local function CreateMenuRow(parent, index, icon)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    row:SetPoint("TOPLEFT", 10, -68 - (index - 1) * 47)
    row:SetPoint("TOPRIGHT", -10, -68 - (index - 1) * 47)
    row:SetHeight(42)
    RP.Widgets:ApplyRelicCard(row, 0.96, 0.72)
    row.iconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
    row.iconFrame:SetSize(32, 32)
    row.iconFrame:SetPoint("LEFT", 5, 0)
    RP.Theme:ApplyIconBorder(row.iconFrame, "normal")
    row.icon = row.iconFrame:CreateTexture(nil, "ARTWORK")
    row.icon:SetPoint("TOPLEFT", 3, -3)
    row.icon:SetPoint("BOTTOMRIGHT", -3, 3)
    row.icon:SetTexture(icon)
    row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    row.title = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.title:SetPoint("TOPLEFT", 45, -7)
    row.title:SetPoint("RIGHT", -8, 0)
    row.title:SetJustifyH("LEFT")
    row.subtitle = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.subtitle:SetPoint("BOTTOMLEFT", 45, 7)
    row.subtitle:SetPoint("RIGHT", -8, 0)
    row.subtitle:SetJustifyH("LEFT")
    row:SetScript("OnEnter", function(self)
        self.title:SetTextColor(1, 0.84, 0.39)
    end)
    row:SetScript("OnLeave", function(self)
        self.title:SetTextColor(1, 0.82, 0)
    end)
    row:SetScript("OnClick", function(self)
        if self.action then self.action() end
        parent:Hide()
    end)
    return row
end

function MinimapButton:OwnsPosition()
    local button = self.button
    if not button or button:GetParent() ~= Minimap then return false end
    local count = button:GetNumPoints()
    if not self.ownAnchor then return count == 0 end
    if count ~= 1 then return false end
    local point, relative, relativePoint, x, y = button:GetPoint(1)
    local anchor = self.ownAnchor
    -- Collectors can keep Minimap as parent while assigning a different anchor.
    -- Respect both styles, without depending on any collector's private flags.
    return point == "CENTER" and relative == Minimap and relativePoint == "CENTER"
        and math.abs((x or 0) - anchor.x) < 0.01
        and math.abs((y or 0) - anchor.y) < 0.01
end

function MinimapButton:SyncCollectorScale()
    local button = self.button
    if not button or not self.nativeScale then return end
    if not self:OwnsPosition() then
        -- Ellesmere lays out a grid in panel units without resetting child scale.
        -- Remove only our own scale, once; never overwrite a collector's scale.
        if not self.collectorScaled and math.abs(button:GetScale() - self.nativeScale) < 0.001 then
            self.collectorScaled = true
            button:SetScale(1)
        end
    elseif self.collectorScaled then
        self.collectorScaled = nil
        if math.abs(button:GetScale() - 1) < 0.001 then button:SetScale(self.nativeScale) end
    end
end

function MinimapButton:UpdatePosition()
    if not self:OwnsPosition() then return end
    local angle = math.rad(RP.db.positions.minimapAngle or 220)
    local x, y = math.cos(angle), math.sin(angle)
    local quadrant = 1
    if x < 0 then quadrant = quadrant + 1 end
    if y > 0 then quadrant = quadrant + 2 end
    local shape = type(GetMinimapShape) == "function" and GetMinimapShape() or "ROUND"
    local quadrants = minimapShapes[shape] or minimapShapes.ROUND
    -- Keep the button snug against the minimap. Its own scale must not push
    -- its anchor farther away from square or custom minimap masks.
    local edgeOffset = 12
    local width = (Minimap:GetWidth() / 2) + edgeOffset
    local height = (Minimap:GetHeight() / 2) + edgeOffset
    if quadrants[quadrant] then
        x, y = x * width, y * height
    else
        local diagonalWidth = math.sqrt(2 * width * width) - edgeOffset
        local diagonalHeight = math.sqrt(2 * height * height) - edgeOffset
        x = math.max(-width, math.min(x * diagonalWidth, width))
        y = math.max(-height, math.min(y * diagonalHeight, height))
    end
    self.ownAnchor = { x = x, y = y }
    self.button:ClearAllPoints()
    self.button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

function MinimapButton:UpdateDrag()
    if not self:OwnsPosition() then self.dragging = false; return end
    local cursorX, cursorY = GetCursorPosition()
    local scale = Minimap:GetEffectiveScale()
    cursorX, cursorY = cursorX / scale, cursorY / scale
    local centerX, centerY = Minimap:GetCenter()
    if not centerX or not centerY then return end
    RP.db.positions.minimapAngle = math.deg(Atan2(cursorY - centerY, cursorX - centerX))
    self:UpdatePosition()
end

function MinimapButton:ApplySettings()
    if not self.button then return end
    local wanted = (RP.db.settings.minimapScale or 1) * (RP.db.settings.uiScale or 1)
    if self:OwnsPosition() then
        self.nativeScale = RP.Widgets:GetPixelPerfectScale(wanted, true)
        self.button:SetScale(self.nativeScale)
        self:UpdatePosition()
    end
    if self.menu then self.menu:SetScale(RP.Widgets:GetPixelPerfectScale(RP.db.settings.uiScale or 1)) end
end

function MinimapButton:SetNearby(nearby)
    self.nearby = nearby and true or false
end

function MinimapButton:ShowTooltip()
    GameTooltip:SetOwner(self.button, "ANCHOR_LEFT")
    GameTooltip:AddLine(RP.L.ADDON_NAME, unpack(RP.colors.gold))
    local mapID = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local mapInfo = mapID and C_Map.GetMapInfo(mapID)
    if mapInfo then GameTooltip:AddLine(RP.L.CURRENT_AREA .. ": " .. mapInfo.name, 0.86, 0.82, 0.72) end
    RP.DigSites:UpdateDistances()
    local site, distance = RP.DigSites:GetNearestSite()
    if site then
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine(site.name or RP.L.UNKNOWN, RP:FormatDistance(distance), 1, 0.84, 0.45, 0.8, 0.8, 0.8)
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(RP.L.LEFT_OPEN, 0.72, 0.72, 0.72)
    GameTooltip:AddLine(RP.L.RIGHT_START, 0.72, 0.72, 0.72)
    GameTooltip:AddLine(RP.L.MIDDLE_NEXT, 0.72, 0.72, 0.72)
    GameTooltip:Show()
end

function MinimapButton:CreateMenu()
    local menu = CreateFrame("Frame", "PlanetOfArchaeologyMinimapMenu", UIParent, "BackdropTemplate")
    menu:SetSize(294, 186)
    menu:SetFrameStrata("LOW")
    menu:SetFrameLevel(150)
    menu:SetFrameLevel(200)
    menu:SetClampedToScreen(true)
    menu:SetToplevel(true)
    -- Chamfered bronze shell without the opaque rectangular outer shadow.
    RP.Theme:ApplyNineSlice(menu, { cut = 11, fillAlpha = 0.82, borderAlpha = 0.72, grainAlpha = 0.035 })
    menu.headerIcon = menu:CreateTexture(nil, "ARTWORK")
    menu.headerIcon:SetSize(40, 40)
    menu.headerIcon:SetPoint("TOPLEFT", 13, -13)
    menu.headerIcon:SetTexture("Interface\\Icons\\Trade_Archaeology")
    menu.headerIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    RP.Widgets:AddIconRing(menu.headerIcon, 40)
    menu.title = menu:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    menu.title:SetPoint("TOPLEFT", 62, -15)
    menu.title:SetText(RP.L.EXPEDITION_MENU)
    menu.status = menu:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    menu.status:SetPoint("TOPLEFT", 62, -37)
    menu.status:SetPoint("RIGHT", -28, 0)
    menu.status:SetJustifyH("LEFT")
    local close = CreateFrame("Button", nil, menu, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 3, 3)
    close:SetScript("OnClick", function() menu:Hide() end)
    local rule = RP.Widgets:CreateRule(menu)
    rule:SetPoint("TOPLEFT", 12, -59)
    rule:SetPoint("TOPRIGHT", -12, -59)
    menu.rows = {
        CreateMenuRow(menu, 1, "Interface\\Icons\\INV_Misc_Map_01"),
        CreateMenuRow(menu, 2, "Interface\\Icons\\INV_Misc_Gear_01"),
    }
    menu.target = menu:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    menu.target:SetPoint("BOTTOMLEFT", 14, 13)
    menu.target:SetPoint("BOTTOMRIGHT", -14, 13)
    menu.target:SetJustifyH("LEFT")
    menu.target:SetWordWrap(false)
    menu:Hide()
    self.menu = menu
    if UISpecialFrames then table.insert(UISpecialFrames, "PlanetOfArchaeologyMinimapMenu") end
end

function MinimapButton:RefreshMenu()
    local menu, rows = self.menu, self.menu.rows
    local active = RP.db.expedition.active
    menu.status:SetText(active and ("|cFF69CC7F" .. RP.L.EXPEDITION_ACTIVE .. "|r") or ("|cFF9B8D78" .. RP.L.EXPEDITION_INACTIVE .. "|r"))

    rows[1].title:SetText(active and RP.L.ROUTE_WINDOW or RP.L.START_EXPEDITION)
    rows[1].subtitle:SetText(RP.L.MENU_START_HINT)
    rows[1].action = function()
        if RP.db.expedition.active then
            RP.MainFrame.frame:Hide()
            RP.SiteTracker:SetShownByUser(true)
        else RP.db.settings.showTracker = true; RP.Expedition:Start() end
    end
    rows[2].title:SetText(RP.L.SETTINGS)
    rows[2].subtitle:SetText(RP.L.MENU_SETTINGS_HINT)
    rows[2].action = function()
        if Settings and Settings.OpenToCategory and RP.Settings and RP.Settings.categoryID then
            Settings.OpenToCategory(RP.Settings.categoryID)
        end
    end

    RP.DigSites:UpdateDistances()
    local site, distance = RP.DigSites:GetNearestSite()
    menu.target:SetText(site and ("|cFFD5B768" .. (site.name or RP.L.UNKNOWN) .. "|r  •  " .. RP:FormatDistance(distance)) or RP.L.NO_MATCHING)
end

function MinimapButton:OpenMenu()
    if self.menu:IsShown() then self.menu:Hide(); return end
    self:RefreshMenu()
    self.menu:ClearAllPoints()
    local buttonX, parentX = self.button:GetCenter(), UIParent:GetCenter()
    if buttonX and parentX and buttonX < parentX then
        self.menu:SetPoint("TOPLEFT", self.button, "TOPRIGHT", 9, 12)
    else
        self.menu:SetPoint("TOPRIGHT", self.button, "TOPLEFT", -9, 12)
    end
    self.menu:Show()
end

function MinimapButton:OnClick(button)
    if button == "RightButton" then
        self:OpenMenu()
    elseif button == "MiddleButton" then
        RP.DigSites:Refresh("minimap-next")
        RP.RoutePlanner:CycleTarget()
    else
        RP.MainFrame:Toggle()
    end
end

function MinimapButton:OnInitialize()
    local button = CreateFrame("Button", "PlanetOfArchaeologyMinimapButton", Minimap)
    button:SetSize(33, 33)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(Minimap:GetFrameLevel() + 8)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
    button:RegisterForDrag("LeftButton")

    button.background = button:CreateTexture(nil, "BACKGROUND")
    button.background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    button.background:SetAllPoints()
    button.icon = button:CreateTexture(nil, "ARTWORK")
    button.icon:SetTexture("Interface\\Icons\\Trade_Archaeology")
    button.icon:SetPoint("TOPLEFT", 7, -7)
    button.icon:SetPoint("BOTTOMRIGHT", -7, 7)
    button.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    button.border = button:CreateTexture(nil, "OVERLAY", nil, 2)
    button.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    button.border:SetPoint("TOPLEFT")
    button.border:SetSize(54, 54)
    button:SetScript("OnClick", function(_, clicked) self:OnClick(clicked) end)
    button:SetScript("OnEnter", function() self:ShowTooltip() end)
    button:SetScript("OnLeave", GameTooltip_Hide)
    button:SetScript("OnDragStart", function()
        if not self:OwnsPosition() then return end
        if self.menu then self.menu:Hide() end
        self.dragging = true
    end)
    button:SetScript("OnDragStop", function()
        self.dragging = false
        self:UpdatePosition()
    end)

    self.button = button
    self:CreateMenu()
    self:ApplySettings()
    hooksecurefunc(button, "SetParent", function() self:SyncCollectorScale() end)
    hooksecurefunc(button, "SetPoint", function() self:SyncCollectorScale() end)
    C_Timer.After(1, function() if self.button then self:UpdatePosition() end end)
    C_Timer.After(3, function() if self.button then self:UpdatePosition() end end)

    self.pulse = CreateFrame("Frame")
    self.pulse:SetScript("OnUpdate", function(_, elapsed)
        -- Do not replace a collector's button OnUpdate handler while dragging.
        if self.dragging then self:UpdateDrag() end
        self.layoutElapsed = self.layoutElapsed + elapsed
        if self.layoutElapsed >= 1 then
            self.layoutElapsed = 0
            local shape = type(GetMinimapShape) == "function" and GetMinimapShape() or "ROUND"
            local width, height = Minimap:GetWidth(), Minimap:GetHeight()
            if shape ~= self.lastShape or width ~= self.lastWidth or height ~= self.lastHeight then
                self.lastShape, self.lastWidth, self.lastHeight = shape, width, height
                self:UpdatePosition()
            end
        end
    end)
end
