local _, RP = ...

local Notifications = { lastTargetAt = 0, baseY = -118 }
RP:RegisterModule("Notifications", Notifications)

local function EaseOutCubic(value)
    return 1 - ((1 - value) ^ 3)
end

function Notifications:OnInitialize()
    local frame = CreateFrame("Frame", "PlanetOfArchaeologyNotification", UIParent, "BackdropTemplate")
    frame:SetSize(360, 88)
    frame:SetPoint("TOP", UIParent, "TOP", 0, self.baseY)
    frame:SetFrameStrata("LOW")
    frame:SetFrameLevel(200)
    frame:EnableMouse(false)
    frame:SetClampedToScreen(true)
    -- Fade only the panel materials, keeping the icon and text readable.
    RP.Theme:ApplyNineSlice(frame, { cut = 10, fillAlpha = 0.94, borderAlpha = 0.70, grainAlpha = 0.025 })
    frame.icon = frame:CreateTexture(nil, "ARTWORK")
    frame.icon:SetTexture("Interface\\Icons\\Trade_Archaeology")
    frame.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    frame.icon:SetSize(68, 68)
    frame.icon:SetPoint("LEFT", 12, 0)
    frame.divider = frame:CreateTexture(nil, "ARTWORK")
    frame.divider:SetTexture("Interface\\Buttons\\WHITE8X8")
    frame.divider:SetGradient("VERTICAL", CreateColor(0.58, 0.38, 0.15, 0), CreateColor(0.82, 0.57, 0.22, 0.38))
    frame.divider:SetPoint("TOPLEFT", 94, -18)
    frame.divider:SetPoint("BOTTOMLEFT", 94, 18)
    frame.divider:SetWidth(1)
    frame.title = RP.Widgets:CreateTitle(frame, "", "GameFontNormalLarge")
    frame.title:SetPoint("TOPLEFT", 108, -21)
    frame.title:SetPoint("TOPRIGHT", -44, -21)
    frame.title:SetJustifyH("LEFT")
    frame.title:SetWordWrap(false)
    frame.title:SetShadowColor(0, 0, 0, 0.9)
    frame.title:SetShadowOffset(1, -1)
    frame.body = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.body:SetPoint("TOPLEFT", frame.title, "BOTTOMLEFT", 0, -6)
    frame.body:SetPoint("TOPRIGHT", frame.title, "BOTTOMRIGHT", 0, -6)
    frame.body:SetJustifyH("LEFT")
    frame.body:SetWordWrap(true)
    frame.body:SetNonSpaceWrap(false)
    frame.body:SetTextColor(0.88, 0.84, 0.74)
    frame.body:SetShadowColor(0, 0, 0, 0.9)
    frame.body:SetShadowOffset(1, -1)
    frame.statusMarker = RP.Widgets:CreateStatusMarker(frame, "progress")
    frame.statusMarker:SetScale(0.8)
    frame.statusMarker:SetPoint("RIGHT", -14, 0)
    frame:Hide()
    self.frame = frame
    frame:SetScript("OnUpdate", function(_, elapsed) self:OnUpdate(elapsed) end)
    self:ApplySettings()
end

function Notifications:ApplySettings()
    if not self.frame then return end
    self.frame:SetScale(RP.Widgets:GetPixelPerfectScale(RP.db.settings.uiScale or 1))
    if not self.state then self.frame:SetAlpha((RP.db.settings.uiOpacity or 1) * 0.98) end
end

function Notifications:SetVisual(alpha, offset)
    local frame = self.frame
    frame:SetAlpha(alpha)
    frame:ClearAllPoints()
    frame:SetPoint("TOP", UIParent, "TOP", 0, self.baseY + (offset or 0))
end

function Notifications:OnUpdate()
    if not self.state or not self.frame:IsShown() then return end
    local now = GetTime()
    local maximumAlpha = (RP.db.settings.uiOpacity or 1) * 0.98
    if self.state == "enter" then
        local progress = math.min(1, (now - self.animationStarted) / 0.32)
        local eased = EaseOutCubic(progress)
        self:SetVisual(maximumAlpha * math.min(1, progress / 0.58), 18 * (1 - eased))
        if progress >= 1 then self.state = "hold" end
    elseif self.state == "hold" then
        self:SetVisual(maximumAlpha, 0)
        if now >= self.holdUntil then
            self.state = "exit"
            self.animationStarted = now
        end
    elseif self.state == "exit" then
        local progress = math.min(1, (now - self.animationStarted) / 0.42)
        local eased = EaseOutCubic(progress)
        self:SetVisual(maximumAlpha * (1 - eased), 8 * eased)
        if progress >= 1 then
            self.state = nil
            self.frame:Hide()
            self:SetVisual(maximumAlpha, 0)
            if self.queue and #self.queue > 0 then
                local nextToast = table.remove(self.queue, 1)
                self:Show(unpack(nextToast, 1, 6))
            end
        end
    end
end

function Notifications:Show(title, body, soundKit, iconAsset, visualState, isRaceIcon)
    if not RP.db.settings.notifications or not self.frame then return end
    if self.state then
        self.queue = self.queue or {}
        self.queue[#self.queue + 1] = { title, body, soundKit, iconAsset, visualState, isRaceIcon }
        return
    end
    local frame = self.frame
    frame.title:SetText(title or "")
    frame.body:SetText(RP.Localization:DisplayName(body) or "")
    iconAsset = iconAsset or "Interface\\Icons\\Trade_Archaeology"
    if type(iconAsset) == "number" or (type(iconAsset) == "string" and iconAsset:find("\\", 1, true)) then
        frame.icon:SetTexture(iconAsset)
        frame.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    else
        frame.icon:SetTexCoord(0, 1, 0, 1)
        frame.icon:SetAtlas(iconAsset, false)
    end
    if isRaceIcon then
        -- Use the populated area of Blizzard's archaeology race texture sheet.
        frame.icon:SetTexCoord(0, 0.5703, 0, 0.6484)
        frame.icon:SetSize(60, 68)
    else
        frame.icon:SetSize(68, 68)
    end
    visualState = visualState or "progress"
    frame:SetRelicState(visualState, true)
    frame.statusMarker:SetStatus(visualState == "completed" and "completed" or (visualState == "selected" and "selected" or "progress"))
    local titleWidth = frame.title.GetUnboundedStringWidth and frame.title:GetUnboundedStringWidth() or frame.title:GetStringWidth()
    local bodyWidth = frame.body.GetUnboundedStringWidth and frame.body:GetUnboundedStringWidth() or frame.body:GetStringWidth()
    local contentWidth = math.max(titleWidth or 0, bodyWidth or 0)
    frame:SetWidth(math.max(360, math.min(480, contentWidth + 158)))
    frame:SetHeight(math.max(88, 21 + frame.title:GetStringHeight() + 6 + frame.body:GetStringHeight() + 20))
    self.animationStarted = GetTime()
    self.holdUntil = self.animationStarted + 4.25
    self.state = "enter"
    self:SetVisual(0, 18)
    frame:Show()
    if RP.db.settings.sounds and soundKit and type(PlaySound) == "function" then pcall(PlaySound, soundKit) end
end

function Notifications:NewTarget(site)
    if not site or not RP.db.settings.targetAlerts then return end
    local now = GetTime()
    -- Route refreshes never alert, and genuine target changes are globally
    -- throttled so the toast cannot repeatedly interrupt play.
    if self.lastTargetAt > 0 and now - self.lastTargetAt < 90 then return end
    self.lastTargetAt = now
    local race = site.raceName or RP.L.UNKNOWN_RACE
    local sound = SOUNDKIT and SOUNDKIT.IG_QUEST_LOG_OPEN
    self:Show(RP.L.NEW_TARGET, (site.name or RP.L.UNKNOWN) .. "  •  " .. race .. "  •  " .. RP:FormatDistance(site.distance), sound, site.raceTexture or "Interface\\Icons\\Trade_Archaeology", "selected", site.raceTexture ~= nil)
end
