local _, RP = ...
local Content = {}
RP:RegisterModule("ContentLocalization", Content)

-- Translations of the original in-panel text supplied in the user's captures.
local artifacts = {
    [95375] = "Хоча богомоли використовують вітротканину й імператорський шовк, найбільше вони цінують своєрідну «тканину», виготовлену з крил різних комахоподібних істот — зокрема й самих богомолів. Цей прапор є одним із таких виробів.",
    [95376] = "Перш ніж споживати сік кипарі, богомоли воліють дати йому вистоятися. Для цього вони використовують такі пристрої. Поглянувши на цей стародавній сокоживильник, можна помітити, що його конструкція з плином часу майже не змінилася.",
    [95377] = "Ця статуя клакксі'ва походить із часів, близьких до прибуття титанів. Навколо її основи викарбувано молитву до «семиголового». Давньою мовою слово «клакксі» означало «жрець».",
    [95378] = "Технологія звукових маяків богомолів незбагненна для інших рас. Схоже, їхня робота залежить від фізіології богомолів. Цей стародавній маяк зберігся неушкодженим, але без богомола, який міг би ним скористатися, він цілковито бездіяльний.",
    [95379] = "Вочевидь, збереження в бурштині не позбавлене ризику. Від цього Ідеала залишилася лише голова. Схоже, він жив ще до пандаренської революції, хоча точно визначити епоху неможливо.",
    [95380] = "Світло цієї лампи походить не від вогню й не від магії. Усередині видно безліч світних комах, збережених у бурштині.",
    [95381] = "Важко визначити призначення цього предмета, але, схоже, це якийсь пристрій для збирання пилку.",
    [95382] = "Хоча цей резервуар має колір бурштину, насправді його виготовлено з виділень куньчунів. Те саме можна сказати й про чимало звичайних предметів умеблювання богомолів.",
    [95391] = "Цей стародавній меч, «небесний розсікач», призначений для крилатих богомолів: він надзвичайно легкий і чудово збалансований, щоб завдавати широких кругових ударів під час стрімкої атаки з неба. Більшість богомолів скидає крила під час обряду переходу, коли стає досить сильною для важких обладунків і зброї. Тому настільки майстерно виготовлений легкий клинок богомолів — рідкість. Імовірно, колись ним володів Ідеал.",
    [95392] = "Богомоли здатні видавати й чути звуки в значно ширшому діапазоні, ніж інші смертні раси. Природне розуміння надзвичайно високих і низьких частот дає їм змогу створювати таку зброю. Звукові імпульси цього пристрою можуть розривати м'язи й органи на клітинному рівні; пряме влучання здатне перетворити нутрощі на рідину.",
    [114191] = "Більшість огрів народжується з двома очима, проте в кожному поколінні можна знайти кількох однооких. Майже в усіх кланах однооких огрів поважають і вважають, що їм судилися великі звершення. Один нещасливий одноокий огр-маг утратив око в поєдинку й замінив його цим каменем завбільшки з кулак — а згодом із подивом виявив, що камінь має чарівні властивості.",
}
local rewards = {
    [131717] = "Ви створюєте купальню зоряного сяйва. Гравці, які перебувають у цій купальні, можуть літати.\n\nМожна використовувати лише на Розколотих островах.",
    [131724] = "Зазирніть в око, щоб побачити світ, у якому демони перемогли у Війні Древніх. (Відновлення: 5 хв.)",
    [131734] = "Використання: навчає прикликати цю їздову тварину.",
    [131735] = "Коли споряджено: ваші шкідливі й цілющі заклинання можуть відкрити портал до Мардума, з якого на вашу ціль або її супротивника рине потік бісів.",
    [131744] = "Використання: відвідати загублену в часі версію академії Нар'талас.\n\nЩоб повернутися, скористайтеся ключами ще раз. (Відновлення: 5 с.)",
    [131745] = "Використання: відкриває доступ до потаємної бічної кімнати у фортеці Чорного Тура.",
    [136922] = "Використання: навчає прикликати цього супутника.",
}
local achievementDescriptions = {
    ["Вечный принц"] = "Знайдіть перелічені нижче артефакти тол'вірів, що розповідають історію розквіту й падіння імператора Нінжтера.",
}
Content.names = { ["Вечный принц"] = "Вічний принц" }

-- Retail archaeology race indices, matching ArchaeologyData.lua. These are
-- race histories, not artifact lore. Later cultures have no native race history.
-- Ukrainian adaptations of the in-game histories; see THIRD_PARTY_NOTICES.md.
local raceHistories = {
    [9] = "Живодайні води долини наділили плем'я грубих істот величезними розмірами, силою та розумом. Цих істот назвали могу. Їхня культура спиралася на силу: войовничі деспоти правили залізною рукою. Їхні кам'яні пам'ятники, зведені на віки, стоять і досі.",
    [10] = "Пандарени — загадковий народ із Пандарії, континенту, що довго залишався прихованим від світу. Шляхетні, закохані в добру компанію та смачну їжу, пандарени залюбки жили усамітнено, дозволяючи своїй культурі розквітати далеко від впливу зовнішнього світу. Хоча пандарени переважно миролюбні, їхня історія сповнена потрясінь і боротьби.",
    [11] = "Імперія богомолів існувала ще до прибуття титанів. Цією стародавньою цивілізацією високорозвинених комахоподібних істот править імператриця, а її суспільство поділене на касти. Життя богомолів зосереджене навколо дерев кипарі та бурштину, що утворюється з їхнього соку.",
    [12] = "Врайкули — народ велетенських воїнів із Ревучого фіорду в Нордсколі. Вони тісно пов'язані з морем і місцевими протодраконами. Чимало врайкулів поповнили величезні армії Короля-ліча.",
    [13] = "Найдавніші відомі тролі належали до племені Зандалар, від якого походять усі інші тролі. Зандаларів вважали спільною жрецькою кастою всіх тролів; вони невтомно записували й берегли історію їхнього суспільства та його традиції. Серед численних племен, що відокремилися від зандаларів, наймогутнішими стали Гурубаші й Амані.",
    [14] = "Спочатку тол'віри були кам'яними створіннями, яких титани створили для охорони таємниць Ульдуму. Вони мають котячі голови й нижню частину тіла та людські торси. Як і багато інших творінь титанів, тол'віри піддалися прокляттю плоті. Нині існують три племені: Рамкахен, майже винищене Орсіс і Неферсет. Останнє уклало союз зі Смертекрилом, щоб повернути тол'вірам кам'яну подобу.",
    [15] = "Орки Азероту походять із Дренору, де й було знайдено більшість цих стародавніх орчих артефактів. Спочатку орки були переважно мирним народом, але під впливом Палаючого Легіону стали відверто жорстокими. Вони прибули до Азероту крізь Темний портал і воювали проти Альянсу у двох війнах. Можливо, на обрії вже наступна.",
    [16] = "Неруби походять від стародавнього народу акірів, приблизно половина якого після безперервних війн із тролями переселилася далеко на північ. Там, під Нордсколом, вони заснували велетенське місто-державу — легендарний Азжол-Неруб. Прихід Короля-ліча став жорстоким ударом для лиховісного народу нерубів: багатьох із цих павукоподібних істот перетворили на воїнів Скари, а решту змусили ховатися глибоко під землею.",
    [17] = "Калдореї — один із найдавніших народів Азероту. Одна з найтемніших сторінок їхньої історії пов'язана з квел'дореями, або високородними — найвищою кастою ельфійської знаті. Вони вивільнили небезпечну магію, що привела у світ Палаючий Легіон і спричинила незліченні смерті.",
    [18] = "Скам'янілості — це збережені рештки тварин або рослин із далекого минулого. Зазвичай живі тканини заміщуються мінералами, які зберігають форму початкового організму.",
    [19] = "Дренеї — це ередари, які втекли від Палаючого Легіону й оселилися на Дренорі, де вперше зустрілися з орками. З прибуттям ельфів крові чимало дренеїв знову вирішили тікати — цього разу до Азероту. Там вони приєдналися до Альянсу.",
    [20] = "Дворфи Стальгорна спочатку поділялися на три клани: Бронзобороді, Дикого Молота й Темного Заліза. Після громадянської війни Бронзобороді зберегли владу над Стальгорном, а клан Дикого Молота зрештою відступив до Внутрішніх земель і Сутінкового нагір'я. Дворфи Темного Заліза оселилися між Красногір'ям і Палаючими степами, у затінку Чорної гори.",
}

function Content:RaceHistory(raceIndex, native)
    if RP.Localization.locale == "ukUA" and raceHistories[raceIndex] then
        return raceHistories[raceIndex]
    end
    return native
end

function Content:Get(kind, id, native, spellText)
    if RP.Localization.locale ~= "ukUA" then return native end
    if kind == "artifact" and artifacts[id] then return artifacts[id] end
    if kind == "artifact" and RP.UkrainianDescriptions[id] then
        local knownEffect = spellText and native and RP.UkrainianEffectSource[id]
            and native:gsub("\r\n", "\n") == RP.UkrainianEffectSource[id]:gsub("\r\n", "\n")
        if RP.UkrainianLoreAvailable[id] or knownEffect then return RP.UkrainianDescriptions[id] end
    end
    if kind == "achievement" and RP.UkrainianAchievements[id] then return RP.UkrainianAchievements[id].description end
    local values = kind == "artifact" and artifacts or kind == "reward" and rewards or achievementDescriptions
    return values[id] or native
end

function Content:AchievementName(id, native)
    local entry = RP.Localization.locale == "ukUA" and RP.UkrainianAchievements[id]
    return entry and entry.name or native
end

function Content:AchievementReward(id, native)
    local entry = RP.Localization.locale == "ukUA" and RP.UkrainianAchievements[id]
    return entry and entry.reward or native
end

function Content:Criterion(id, index, native)
    local entries = RP.Localization.locale == "ukUA" and RP.UkrainianCriteria[id]
    return entries and entries[index] or RP.Localization:DisplayName(native)
end

-- Export source text only, never character/account names or completion data.
-- Run explicitly: /rp exporttexts, wait for completion, then /reload to save.
function Content:Capture()
    PlanetOfArchaeologyTranslationSource = PlanetOfArchaeologyTranslationSource or {}
    local source = PlanetOfArchaeologyTranslationSource
    local locale = GetLocale()
    source[locale] = source[locale] or { artifacts = {}, achievements = {}, rewards = {} }
    local data = source[locale]
    for _, artifact in ipairs(RP.Archaeology:RefreshArchive()) do
        if artifact.itemID then
            local entry = data.artifacts[artifact.itemID] or {}
            data.artifacts[artifact.itemID] = entry
            entry.name = artifact.name
            if artifact.description and artifact.description ~= "" then entry.description = artifact.description end
            local spellID = artifact.spellID
            if not spellID and C_Item and C_Item.GetItemSpell then spellID = select(2, C_Item.GetItemSpell(artifact.itemID)) end
            if spellID and C_Spell then
                local description = C_Spell.GetSpellDescription and C_Spell.GetSpellDescription(spellID)
                if description and description ~= "" then entry.spellDescription = description
                elseif C_Spell.RequestLoadSpellData then C_Spell.RequestLoadSpellData(spellID) end
            end
        end
    end
    for _, achievement in ipairs(RP.Achievements:GetEntries()) do
        local criteria = {}
        for i = 1, GetAchievementNumCriteria(achievement.id) do
            criteria[i] = GetAchievementCriteriaInfo(achievement.id, i)
        end
        data.achievements[achievement.id] = { name = achievement.name, description = achievement.description,
            reward = achievement.reward, criteria = criteria }
    end
    for _, reward in ipairs(RP.SpecialExpeditionData.legion.entries) do
        local text = RP.LegionExpeditions:GetRewardDescription(reward, true)
        if text and text ~= RP.L.ARCHIVE_NO_DESCRIPTION then
            data.rewards[reward.itemID] = { name = reward.name, description = text }
        end
    end
    local artifactsWithText, achievementCount, rewardCount = 0, 0, 0
    for _, entry in pairs(data.artifacts) do
        if entry.description or entry.spellDescription then artifactsWithText = artifactsWithText + 1 end
    end
    for _ in pairs(data.achievements) do achievementCount = achievementCount + 1 end
    for _ in pairs(data.rewards) do rewardCount = rewardCount + 1 end
    self.captureCounts = { artifactsWithText, achievementCount, rewardCount }
end

function Content:Export()
    if self.exporting then return end
    self.exporting = true
    RP:Print("Збір текстів для перекладу: зачекайте 10 секунд.")
    for _, delay in ipairs({0, 3, 6, 10}) do
        C_Timer.After(delay, function()
            local ok, err = pcall(self.Capture, self)
            if not ok then RP:Debug("Translation export: %s", tostring(err)) end
            if delay == 10 then
                self.exporting = nil
                if ok then RP:Print(string.format("Описів артефактів: %d; досягнень: %d; нагород: %d.", unpack(self.captureCounts))) end
                RP:Print(ok and "Тексти зібрано. Виконайте /reload, щоб зберегти тексти в даних PlanetOfArchaeology."
                    or "Не вдалося зібрати всі тексти. Увімкніть /rp debug і повторіть /rp exporttexts.")
            end
        end)
    end
end
