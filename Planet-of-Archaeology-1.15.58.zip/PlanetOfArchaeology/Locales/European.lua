local _, RP = ...
local fr, es = {}, {}
RP.locales.frFR, RP.locales.esES = fr, es
-- One row per message: key | French | Spanish. Item names come from WoW.
local messages = [[
DOCK_WINDOWS|Garder les fenêtres liées en déplacement|Mantener las ventanas vinculadas al moverlas
FIRST_ARTIFACT|NOUVEL ARTÉFACT DÉCOUVERT|NUEVO ARTEFACTO DESCUBIERTO
LANGUAGE|Langue|Idioma
ACHIEVEMENTS|HAUTS FAITS|LOGROS
ACH_WISH_ADD|AJOUTER AUX SOUHAITS|AÑADIR A DESEADOS
ACH_WISH_REMOVE|RETIRER DES SOUHAITS|QUITAR DE DESEADOS
ACH_TRACK|SUIVRE|SEGUIR
ACH_UNTRACK|NE PLUS SUIVRE|DEJAR DE SEGUIR
ACH_TRACK_ERROR|Impossible de modifier le suivi. Vérifiez la limite de hauts faits suivis.|No se pudo cambiar el seguimiento. Comprueba el límite de logros seguidos.
ACH_PROGRESS|Conditions remplies : %d / %d|Requisitos cumplidos: %d / %d
ACH_DONE|Validé|Completado
ACH_EXP_ALL|Toutes les extensions|Todas las expansiones
ACH_EXP_GENERAL|Général / Autres|General / Otros
ACH_EXP_CATA|Cataclysm|Cataclysm
ACH_EXP_MOP|Mists of Pandaria|Mists of Pandaria
ACH_EXP_WOD|Warlords of Draenor|Warlords of Draenor
ACH_EXP_LEGION|Legion|Legion
ACH_EXP_BFA|Battle for Azeroth|Battle for Azeroth
ACH_EARNED|Obtenus|Obtenidos
ACH_MISSING|Non obtenus|Sin obtener
ACH_POINTS|%d points|%d puntos
ACH_COUNTER|%d / %d obtenus|%d / %d obtenidos
ACH_REWARD|Récompense|Recompensa
ACH_CRITERIA|Conditions|Requisitos
ACH_UNAVAILABLE|Les hauts faits d’archéologie ne sont pas encore disponibles. Rouvrez cet onglet après le chargement du jeu.|Los logros de arqueología aún no están disponibles. Vuelve a abrir esta pestaña cuando termine de cargar el juego.
ACH_EMPTY|Aucun haut fait ne correspond à ce filtre.|No hay logros para este filtro.
LANGUAGE_AUTO|Automatique|Automático
SERVER_TIME|heure du serveur|hora del servidor
LEGION_BEGINS|Début : |Inicio: 
WISH_ADD|AJOUTER AUX SOUHAITS|AÑADIR A DESEADOS
WISH_REMOVE|RETIRER DES SOUHAITS|QUITAR DE DESEADOS
WISH_TAB|Souhaits|Deseados
WISH_EMPTY|Aucun souhait. Choisissez une récompense dans la liste complète.|No hay deseos. Elige una recompensa en la lista completa.
WISH_AVAILABLE|RÉCOMPENSE SOUHAITÉE DISPONIBLE|RECOMPENSA DESEADA DISPONIBLE
LEGION_ALL|Toutes les récompenses|Todas las recompensas
CALENDAR_ADD|AJOUTER AU CALENDRIER|AÑADIR AL CALENDARIO
CALENDAR_DESCRIPTION|Récompense d’archéologie de Legion disponible pendant 14 jours.|Recompensa de arqueología de Legion disponible durante 14 días.
CALENDAR_CONFIRM|Événement préparé. Cliquez sur Créer dans le calendrier pour l’enregistrer.|Evento preparado. Pulsa Crear en el calendario para guardarlo.
CALENDAR_BUSY|Enregistrez ou fermez d’abord l’événement déjà ouvert.|Guarda o cierra primero el evento abierto.
CALENDAR_UNAVAILABLE|Impossible de créer un événement à cette date pour le moment.|No se puede crear un evento en esta fecha ahora mismo.
TRACKER_COLLAPSE|Mode minimal — destination actuelle uniquement|Modo mínimo: solo el destino actual
TRACKER_EXPAND|Développer l’itinéraire|Ampliar la ruta
MAIN_COLLAPSE|Journal compact — masquer les races|Diario compacto: ocultar las razas
MAIN_EXPAND|Développer le journal et les races|Ampliar el diario y las razas
DIRECTION|FOUILLES|EXCAVACIONES
LEGION_MAP_FALLBACK|Point refusé par Blizzard. Carte ouverte : %.1f, %.1f.|Blizzard ha rechazado el punto. Mapa abierto: %.1f, %.1f.
SPECIAL_EXPEDITIONS|EXPÉDITIONS|EXPEDICIONES
LEGION_TITLE|EXPÉDITIONS DE LEGION|EXPEDICIONES DE LEGION
LEGION_SUBTITLE|Découvertes archéologiques rares des îles Brisées|Hallazgos arqueológicos raros de las Islas Abruptas
LEGION_CURRENT|EXPÉDITION ACTIVE|EXPEDICIÓN ACTIVA
LEGION_NEXT|Ensuite|Siguiente
LEGION_NOW|MAINTENANT|AHORA
LEGION_DONE|Terminée|Completada
LEGION_NOT_DONE|Pas encore terminée|Sin completar
LEGION_UNKNOWN|Les données des quêtes ne sont pas encore disponibles|Los datos de las misiones aún no están disponibles
LEGION_UNSUPPORTED|Aucune référence de rotation vérifiée pour cette région|No hay una referencia de rotación verificada para esta región
LEGION_REMAINING|Disponible pendant : |Disponible durante: 
LEGION_ENDS|Fin : |Fin: 
LEGION_RETURNS|Retour : |Regresa: 
LEGION_CONTACT|Voir Dariness|Ir a Dariness
LEGION_CONTINUE|Continuer l’expédition|Continuar la expedición
LEGION_NO_COORDS|Point exact indisponible. Consultez le suivi des quêtes sur la carte.|Punto exacto no disponible. Consulta el seguimiento de misiones en el mapa.
LEGION_DAYS|%d j %02d h|%d d %02d h
LEGION_HOURS|%d h %02d min|%d h %02d min
LEGION_MINUTES|%d min|%d min
LEGION_KIND_mount|Monture|Montura
LEGION_KIND_pet|Mascotte|Mascota
LEGION_KIND_toy|Jouet|Juguete
LEGION_KIND_item|Objet|Objeto
PROJECT_READY|PRÊT À RECONSTITUER|LISTO PARA RESTAURAR
PROJECT_READY_SHORT|PRÊT|LISTO
LEGION_ESTIMATED|Heure de réinitialisation indisponible ; date approximative|Hora de reinicio no disponible; fecha aproximada
PROJECT_MISSING|Il manque %d fragments. Continuez les fouilles pour cette race.|Faltan %d fragmentos. Sigue excavando para esta raza.
PROJECT_ROUTE|TRACER UN ITINÉRAIRE|TRAZAR RUTA
PROJECT_SOLVE|RECONSTITUER L’ARTÉFACT|RESTAURAR ARTEFACTO
ROUTE_COMPACT_HINT|Les races choisies passent en premier, puis la distance. Le mode Proche efface les choix de cette région.|Las razas elegidas van primero, luego la distancia. Más cercano borra las preferencias de esta región.
ROUTE_START_SHORT|DÉMARRER|INICIAR
ROUTE_STOP_SHORT|TERMINER|FINALIZAR
ROUTE_RACE_HINT|Clic gauche : sélectionner. Clic droit ou Maj-clic : priorité maximale. À priorité égale, la distance décide.|Clic izquierdo: seleccionar. Clic derecho o Mayús-clic: máxima prioridad. A igual prioridad se usa la distancia.
KEYSTONE_NOT_ADDED|La pierre n’a pas été ajoutée. Vérifiez les objets et les emplacements ; /rp debug active le diagnostic.|No se ha añadido la piedra. Comprueba objetos y ranuras; /rp debug activa el diagnóstico.
RESTORE_CAST|Reconstitution… %.1f s|Restaurando… %.1f s
RESTORE_COMPLETE|Artéfact reconstitué|Artefacto restaurado
RESTORE_CANCELLED|Reconstitution annulée|Restauración cancelada
ADDON_NAME|PlanetOfArchaeology|PlanetOfArchaeology
SUBTITLE|Compagnon d’archéologie immersif|Compañero de arqueología inmersivo
START_EXPEDITION|DÉMARRER L’EXPÉDITION|INICIAR EXPEDICIÓN
STOP_EXPEDITION|TERMINER L’EXPÉDITION|FINALIZAR EXPEDICIÓN
EXPEDITION|EXPÉDITION|EXPEDICIÓN
DIG_SITES|FOUILLES|EXCAVACIONES
RACES|RACES|RAZAS
RESEARCH|RECHERCHES|INVESTIGACIÓN
ARCHIVE|ARCHIVES|ARCHIVO
JOURNAL|JOURNAL|DIARIO
SETTINGS|PARAMÈTRES|AJUSTES
NAVIGATION|Navigation|Navegación
HUD|Affichage de terrain|Panel de campo
MAP|Carte|Mapa
ADVANCED|Avancé|Avanzado
INTERFACE|Interface|Interfaz
NEXT_TARGET|PROCHAINE DESTINATION|SIGUIENTE DESTINO
NEW_TARGET|Nouvelle destination d’expédition|Nuevo destino de expedición
DIG_SITE_COMPLETE|FOUILLES TERMINÉES|EXCAVACIÓN COMPLETADA
DIG_SITE|SITE DE FOUILLES|YACIMIENTO
ON_DIG_SITE|SUR LE SITE|EN EL YACIMIENTO
SURVEY|Levée|Topografía
UNKNOWN_RACE|Race inconnue|Raza desconocida
UNKNOWN|Inconnu|Desconocido
NO_SITES|Aucun site actif sur la carte disponible|No hay yacimientos activos en el mapa disponible
NO_MATCHING|Aucun site correspondant|No hay yacimientos coincidentes
SHOW_ALL|Afficher tous les sites|Mostrar todos los yacimientos
CLICK_DESTINATION|Cliquez pour choisir la destination|Pulsa para elegir el destino
RIGHT_CLICK|Clic droit : options|Clic derecho: opciones
SET_DESTINATION|Choisir la destination|Elegir destino
IGNORE_SITE|Ignorer le site|Ignorar yacimiento
UNIGNORE_SITE|Rétablir le site|Restablecer yacimiento
IGNORE_RACE|Clic droit : ignorer/rétablir cette race|Clic derecho: ignorar/restablecer esta raza
PRIORITIZE_RACE|Donner la priorité à cette race|Priorizar raza
FRAGMENTS|Fragments|Fragmentos
KEYSTONES|Pierres angulaires|Piedras angulares
READY_TO_SOLVE|PRÊT À RECONSTITUER|LISTO PARA RESTAURAR
SOLVE|RECONSTITUER|RESTAURAR
PROJECTS|RECONSTITUTION|RESTAURACIÓN
PROJECTS_HINT|Projets actuels, fragments, pierres angulaires et reconstitution.|Proyectos actuales, fragmentos, piedras angulares y restauración.
PROJECTS_COUNTER|Projets : %d • Prêts : %d|Proyectos: %d • Listos: %d
NO_PROJECTS|Aucun projet d’archéologie disponible.|No hay proyectos de arqueología disponibles.
KEYSTONE_SHORT|PIERRES %d/%d|PIEDRAS %d/%d
NO_KEYSTONE_SOCKETS|AUCUN EMPLACEMENT|SIN RANURAS
NORMAL|Commun|Común
RARE|Rare|Raro
SELECTED|Sélectionné pour l’itinéraire|Seleccionado para la ruta
NOT_SELECTED|Non sélectionné|No seleccionado
SHIFT_PRIORITY|Maj-clic : priorité maximale|Mayús-clic: máxima prioridad
ROUTE_NEAREST|Proche|Más cercano
ROUTE_PRIORITY|Priorité des races|Prioridad de razas
FILTER_PREFER|Préférer|Preferir
FILTER_STRICT|Strict|Estricto
ROUTE_MODE|Mode d’itinéraire|Modo de ruta
RACE_FILTER|Filtre des races|Filtro de razas
DISTANCE_UNITS|Distance|Distancia
DISTANCE_AUTO|auto : m / km|auto: m / km
DISTANCE_METERS|mètres uniquement|solo metros
DISTANCE_KILOMETERS|kilomètres uniquement|solo kilómetros
AUTO_NEXT|Choisir automatiquement le site suivant|Elegir automáticamente el siguiente yacimiento
BLIZZARD_WAYPOINT|Point de navigation Blizzard|Punto de ruta de Blizzard
SHOW_ARROW|Afficher la flèche|Mostrar flecha
LOCK_HUD|Verrouiller l’affichage de terrain|Bloquear panel de campo
SOUNDS|Sons|Sonidos
NOTIFICATIONS|Notifications d’expédition|Avisos de expedición
TARGET_ALERTS|Alerte occasionnelle de destination|Aviso ocasional de destino
SHOW_MAP_PINS|Afficher les sites sur la carte|Mostrar yacimientos en el mapa
DEBUG|Mode de diagnostic|Modo de diagnóstico
RESET_POSITION|Réinitialiser les positions|Restablecer posiciones
RESET_DATABASE|Réinitialiser les données|Restablecer datos
HUD_SCALE|Échelle du panneau de terrain|Escala del panel de campo
HUD_OPACITY|Opacité du panneau de terrain|Opacidad del panel de campo
INTERFACE_SCALE|Échelle de l’interface|Escala de interfaz
INTERFACE_OPACITY|Opacité de l’interface|Opacidad de interfaz
ARROW_SCALE|Échelle de la flèche|Escala de flecha
TODAYS_EXPEDITION|EXPÉDITION DU JOUR|EXPEDICIÓN DE HOY
DIGS_COMPLETED|Sites de fouilles|Yacimientos
SURVEYS|Levées|Prospecciones
ARTIFACTS|Artéfacts reconstitués|Artefactos restaurados
RARE_ARTIFACTS|Artéfacts rares|Artefactos raros
RARE_ALERT|Alerte d’artéfact rare|Aviso de artefacto raro
ARTIFACT_RESTORED|Artéfact rare reconstitué|Artefacto raro restaurado
EXPEDITION_TIME|Durée de l’expédition|Duración de expedición
TOTAL_TIME|Toutes les expéditions|Todas las expediciones
RECENT_ARTIFACTS|Artéfacts récents|Artefactos recientes
ARCHAEOLOGY_UNAVAILABLE|Données d’archéologie indisponibles pour ce personnage.|Datos de arqueología no disponibles para este personaje.
RACE_DISCOVERY_NOTE|Les races connues sont identifiées immédiatement ; les autres après une levée.|Las razas conocidas se identifican al instante; las nuevas, tras usar Topografía.
STRICT_NOTE|Le mode strict ne suit que les sites d’une race connue sélectionnée.|El modo estricto solo sigue yacimientos de razas conocidas seleccionadas.
WAYPOINT_FAILED|Blizzard ne peut pas placer de point ici. La flèche PlanetOfArchaeology reste disponible.|Blizzard no puede colocar un punto aquí. La flecha de PlanetOfArchaeology sigue disponible.
TARGET_REACHED|SITE ATTEINT|YACIMIENTO ALCANZADO
START_HERE|Démarrer l’expédition ici|Iniciar expedición aquí
START_DIGGING|COMMENCER LES FOUILLES|EMPEZAR A EXCAVAR
NEARBY_SITE|Site de fouilles à proximité|Yacimiento cercano
TRACK_SITE|SUIVRE|SEGUIR
NOT_NOW|PAS MAINTENANT|AHORA NO
AUTO_PROMPT|Proposer une expédition près des sites|Sugerir expedición cerca de yacimientos
LEFT_OPEN|Clic gauche : ouvrir le journal|Clic izquierdo: abrir diario
RIGHT_START|Clic droit : menu d’expédition|Clic derecho: menú de expedición
MIDDLE_NEXT|Clic central : destination suivante|Clic central: siguiente destino
CURRENT_AREA|Zone actuelle|Zona actual
FINDS_REMAINING|%d découvertes restantes|Quedan %d hallazgos
FINDS_SHORT|Découvertes : %d|Hallazgos: %d
SURVEY_READY_SHORT|PRÊT|LISTO
FRAGMENTS_NEEDED|%d fragments nécessaires|Se necesitan %d fragmentos
SURVEY_ACTION|LEVÉE|TOPOGRAFÍA
SURVEY_HINT|Cliquez pour utiliser Levée|Pulsa para usar Topografía
EXPEDITION_MENU|Menu d’expédition|Menú de expedición
OPEN_JOURNAL|Ouvrir le journal de terrain|Abrir diario de campo
SHOW_TRACKER|Afficher l’itinéraire|Mostrar ruta
HIDE_TRACKER|Masquer l’itinéraire|Ocultar ruta
CONTINENT_SITES|SITES ACTIFS|YACIMIENTOS ACTIVOS
CLICK_TO_TRACK|Cliquez sur un site pour vous y rendre|Pulsa un yacimiento para ir allí
TRACKING|SUIVI|SEGUIMIENTO
ROUTE_WINDOW|Itinéraire d’expédition|Ruta de expedición
SURVEY_READY|Prêt pour une levée|Listo para Topografía
CURRENT_RESOURCES|Fragments actuels : %d / %d|Fragmentos actuales: %d / %d
ARTIFACT_PROGRESS|%d + %d / %d|%d + %d / %d
ARTIFACT_PROGRESS_SHORT|%d / %d|%d / %d
CURRENT_ARTIFACT|Artéfact actuel|Artefacto actual
SOLVE_HINT|Clic gauche : reconstituer l’artéfact|Clic izquierdo: restaurar el artefacto
KEYSTONE_ADD|Clic gauche : ajouter une pierre|Clic izquierdo: añadir una piedra
KEYSTONE_REMOVE|Clic droit : retirer la dernière pierre|Clic derecho: quitar la última piedra
KEYSTONE_STATUS|Insérées : %d / %d • Dans les sacs : %d|Insertadas: %d / %d • En las bolsas: %d
MOVE_WINDOW|Faites glisser pour déplacer|Arrastra para mover
POSSIBLE_RACES|Races possibles|Razas posibles
TRACKER_SCALE|Échelle de l’itinéraire|Escala de ruta
DEBUG_ENABLED|Diagnostic activé|Diagnóstico activado
DEBUG_DISABLED|Diagnostic désactivé|Diagnóstico desactivado
HUD_LOCKED|Affichage verrouillé|Panel bloqueado
HUD_UNLOCKED|Affichage déverrouillé|Panel desbloqueado
POSITIONS_RESET|Positions réinitialisées|Posiciones restablecidas
DATABASE_RESET|Données réinitialisées. Rechargement de l’interface.|Datos restablecidos. Recargando interfaz.
NO_TARGET|Aucune destination d’expédition|Sin destino de expedición
SITES_FOUND|%d sites actifs|%d yacimientos activos
MANUAL_TARGET|Destination manuelle|Destino manual
SELECTED_REASON|Choisi par le planificateur|Elegido por el planificador
PRIORITY|Priorité n° %d|Prioridad n.º %d
UNMAPPED|Race non observée|Raza no observada
YARDS|%d yd|%d yd
METERS|%d m|%d m
KILOMETERS|%.2f km|%.2f km
MINUTES|%d min %02d s|%d min %02d s
HOURS|%d h %02d min|%d h %02d min
OPTIONS_HINT|Plus d’options dans Options > Add-ons > PlanetOfArchaeology.|Más opciones en Opciones > AddOns > PlanetOfArchaeology.
ARCHIVE_HINT|Catalogue complet des artéfacts et historique des découvertes du personnage.|Catálogo completo de artefactos e historial de hallazgos del personaje.
ARCHIVE_ALL|TOUS|TODOS
ARCHIVE_OBTAINED|OBTENUS|OBTENIDOS
ARCHIVE_MISSING|MANQUANTS|PENDIENTES
ARCHIVE_COUNTER|Obtenus : %d / %d • Manquants : %d|Obtenidos: %d / %d • Pendientes: %d
ARCHIVE_ALL_RACES|Toutes les races|Todas las razas
ARCHIVE_RACE_COUNT|%d / %d obtenus|%d / %d obtenidos
ARCHIVE_OBTAINED_STATUS|Obtenu|Obtenido
ARCHIVE_MISSING_STATUS|Pas encore obtenu|Aún no obtenido
ARCHIVE_COMPLETIONS|Reconstitué : %d|Restaurado: %d
ARCHIVE_FIRST_COMPLETION|Première reconstitution : %s|Primera restauración: %s
ARCHIVE_NOT_YET|Cet artéfact n’a pas encore été reconstitué.|Este artefacto aún no se ha restaurado.
ARCHIVE_NO_DESCRIPTION|Aucune description disponible pour cet artéfact.|No hay descripción disponible para este artefacto.
ARCHIVE_SELL_PRICE|Prix de vente|Precio de venta
ARCHIVE_EMPTY|Aucun artéfact|Sin artefactos
ARCHIVE_EMPTY_HINT|Aucun artéfact ne correspond au filtre, ou l’historique Blizzard est indisponible.|No hay artefactos que coincidan con el filtro o el historial de Blizzard no está disponible.
RESIZE_WINDOW|Faites glisser le coin pour redimensionner|Arrastra la esquina para cambiar el tamaño
MAIN_WINDOW_SCALE|Échelle de la fenêtre principale|Escala de ventana principal
MINIMAP_BUTTON_SCALE|Taille du bouton de minicarte|Tamaño del botón del minimapa
EXPEDITION_ACTIVE|Expédition active|Expedición activa
EXPEDITION_INACTIVE|Expédition non démarrée|Expedición sin iniciar
MENU_START_HINT|Tracer un itinéraire parmi les sites du continent|Trazar una ruta por los yacimientos del continente
MENU_STOP_HINT|Terminer l’itinéraire et masquer les outils|Finalizar la ruta y ocultar las herramientas
MENU_NEXT_HINT|Choisir le prochain site correspondant|Elegir el siguiente yacimiento coincidente
MENU_TRACKER_HINT|Liste des sites et flèches de direction|Lista de yacimientos y flechas de dirección
MENU_RESEARCH_HINT|Toutes les races et tous les artéfacts|Todas las razas y artefactos
MENU_SETTINGS_HINT|Échelle, opacité et navigation|Escala, opacidad y navegación
]]
for line in messages:gmatch("[^\r\n]+") do
    local key, french, spanish = line:match("^([^|]+)|([^|]+)|(.+)$")
    if key then fr[key], es[key] = french, spanish end
end
