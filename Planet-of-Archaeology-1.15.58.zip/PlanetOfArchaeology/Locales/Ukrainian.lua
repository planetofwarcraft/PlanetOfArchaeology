local _, RP = ...
-- Addon-owned Ukrainian translation; ukUA is not a Blizzard client locale.
local L = {}
RP.locales.ukUA = L
local text = [[
LANGUAGE|Мова
LANGUAGE_AUTO|Автоматично
SERVER_TIME|час сервера
LEGION_BEGINS|Початок: 
WISH_ADD|ДОДАТИ ДО БАЖАНОГО
WISH_TAB|Бажане
LEGION_ALL|Усі нагороди
WISH_EMPTY|Бажаних нагород ще немає. Виберіть нагороду в повному списку.
CALENDAR_ADD|ДОДАТИ ДО КАЛЕНДАРЯ
CALENDAR_DESCRIPTION|Археологічна нагорода Legion доступна протягом 14 днів.
CALENDAR_CONFIRM|Подію підготовлено. Натисніть «Створити» в календарі, щоб зберегти її.
CALENDAR_BUSY|Спершу збережіть або закрийте поточну подію календаря.
CALENDAR_UNAVAILABLE|Зараз неможливо створити подію календаря на цю дату.
WISH_REMOVE|ВИЛУЧИТИ З БАЖАНОГО
WISH_AVAILABLE|БАЖАНА НАГОРОДА ДОСТУПНА
TRACKER_COLLAPSE|Мінімальний режим — лише поточна ціль
TRACKER_EXPAND|Розгорнути повний маршрут
MAIN_COLLAPSE|Компактний журнал — приховати панель рас
MAIN_EXPAND|Розгорнути журнал і панель рас
DIRECTION|РОЗКОПКИ
LEGION_MAP_FALLBACK|Blizzard відхилив позначку. Відкрито карту місця призначення: %.1f, %.1f.
SPECIAL_EXPEDITIONS|ЕКСПЕДИЦІЇ
LEGION_TITLE|ЕКСПЕДИЦІЇ LEGION
LEGION_SUBTITLE|Рідкісні археологічні знахідки Розколотих островів
LEGION_CURRENT|ПОТОЧНА ЕКСПЕДИЦІЯ
LEGION_NEXT|Далі
LEGION_NOW|ЗАРАЗ
LEGION_DONE|Завершено
LEGION_NOT_DONE|Ще не завершено
LEGION_UNKNOWN|Дані ланцюжка завдань поки недоступні
LEGION_UNSUPPORTED|Для цього регіону немає перевірених даних ротації
LEGION_REMAINING|Доступно ще: 
LEGION_ENDS|Зміна: 
LEGION_RETURNS|Повернення: 
LEGION_CONTACT|До Дарінесс
LEGION_CONTINUE|Продовжити експедицію
LEGION_NO_COORDS|Точна позначка недоступна. Перевірте відстеження завдань на карті та параметр позначки Blizzard.
LEGION_DAYS|%d д. %02d год.
LEGION_HOURS|%d год. %02d хв.
LEGION_MINUTES|%d хв.
LEGION_KIND_mount|Їздова тварина
LEGION_KIND_pet|Улюбленець
LEGION_KIND_toy|Іграшка
LEGION_KIND_item|Предмет
PROJECT_READY|ГОТОВО ДО ВІДНОВЛЕННЯ
PROJECT_READY_SHORT|ГОТОВО
LEGION_ESTIMATED|Час оновлення недоступний; дата приблизна
PROJECT_MISSING|Бракує: %d\nПродовжуйте розкопки цієї археологічної раси.
PROJECT_ROUTE|ПРОКЛАСТИ МАРШРУТ
PROJECT_SOLVE|ВІДНОВИТИ АРТЕФАКТ
ROUTE_COMPACT_HINT|Натисніть, щоб перемкнути. Вибрані раси йдуть першими за відстанню. «Найближча» скидає вибір рас цього регіону.
ROUTE_START_SHORT|ПОЧАТИ
ROUTE_STOP_SHORT|ЗАВЕРШИТИ
ROUTE_RACE_HINT|Ліва кнопка — вибрати. Права кнопка або Shift і клацання — найвищий пріоритет. Місця однакового пріоритету впорядковано за відстанню.
KEYSTONE_NOT_ADDED|Гра не змінила вставлені камені. Перевірте предмет і вільні гнізда; /rp debug вмикає діагностику.
RESTORE_CAST|Відновлення… %.1f с
RESTORE_COMPLETE|Артефакт відновлено
RESTORE_CANCELLED|Відновлення скасовано
ADDON_NAME|PlanetOfArchaeology
SUBTITLE|Супутник археологічної експедиції
START_EXPEDITION|ПОЧАТИ ЕКСПЕДИЦІЮ
STOP_EXPEDITION|ЗАВЕРШИТИ ЕКСПЕДИЦІЮ
EXPEDITION|ЕКСПЕДИЦІЯ
DIG_SITES|РОЗКОПКИ
RACES|РАСИ
RESEARCH|ДОСЛІДЖЕННЯ
ARCHIVE|АРХІВ
JOURNAL|ЖУРНАЛ
SETTINGS|НАЛАШТУВАННЯ
NAVIGATION|Навігація
HUD|Вікно знахідок
MAP|Карта
ADVANCED|Додатково
INTERFACE|Інтерфейс
NEXT_TARGET|НАСТУПНА ЦІЛЬ
NEW_TARGET|Нова ціль експедиції
DIG_SITE_COMPLETE|РОЗКОПКИ ЗАВЕРШЕНО
DIG_SITE|РОЗКОПКИ
ON_DIG_SITE|НА РОЗКОПКАХ
SURVEY|Дослідження місцевості
UNKNOWN_RACE|Раса невідома
UNKNOWN|Невідомо
NO_SITES|На доступній карті немає активних розкопок
NO_MATCHING|Відповідних розкопок немає
SHOW_ALL|Показати всі розкопки
CLICK_DESTINATION|Натисніть, щоб задати місце призначення
RIGHT_CLICK|Права кнопка — параметри
SET_DESTINATION|Задати місце призначення
IGNORE_SITE|Ігнорувати розкопки
UNIGNORE_SITE|Повернути розкопки
IGNORE_RACE|Права кнопка — ігнорувати або повернути цю расу
PRIORITIZE_RACE|Надати расі пріоритет
FRAGMENTS|Уламки
KEYSTONES|Ключові камені
READY_TO_SOLVE|ГОТОВО ДО ВІДНОВЛЕННЯ
SOLVE|ВІДНОВИТИ
PROJECTS|СКЛАДАННЯ
PROJECTS_HINT|Поточні археологічні проєкти: уламки, ключові камені та відновлення артефактів.
PROJECTS_COUNTER|Проєктів: %d  •  Готово: %d
NO_PROJECTS|Зараз немає доступних археологічних проєктів.
KEYSTONE_SHORT|КАМЕНІ %d/%d
NO_KEYSTONE_SOCKETS|НЕМАЄ ГНІЗД ДЛЯ КАМЕНІВ
NORMAL|Звичайний
RARE|Рідкісний
SELECTED|Вибрано для маршруту
NOT_SELECTED|Не вибрано
SHIFT_PRIORITY|Shift і клацання — найвищий пріоритет
ROUTE_NEAREST|Найближча
ROUTE_PRIORITY|Пріоритет рас
FILTER_PREFER|Перевага
FILTER_STRICT|Суворо
ROUTE_MODE|Режим маршруту
RACE_FILTER|Фільтр рас
DISTANCE_UNITS|Відстань
DISTANCE_AUTO|авто: м / км
DISTANCE_METERS|лише метри
DISTANCE_KILOMETERS|лише кілометри
AUTO_NEXT|Автоматично вибирати наступні розкопки
BLIZZARD_WAYPOINT|Використовувати позначку Blizzard
SHOW_ARROW|Показувати стрілку
LOCK_HUD|Заблокувати вікно знахідок
SOUNDS|Звуки
NOTIFICATIONS|Сповіщення експедиції
TARGET_ALERTS|Періодично сповіщати про нову ціль
SHOW_MAP_PINS|Показувати розкопки на карті
DEBUG|Режим налагодження
RESET_POSITION|Скинути розташування вікон
RESET_DATABASE|Скинути базу даних
HUD_SCALE|Масштаб вікна знахідок
HUD_OPACITY|Непрозорість вікна знахідок
INTERFACE_SCALE|Загальний масштаб
INTERFACE_OPACITY|Загальна непрозорість
ARROW_SCALE|Масштаб стрілки
TODAYS_EXPEDITION|СЬОГОДНІШНЯ ЕКСПЕДИЦІЯ
DIGS_COMPLETED|Розкопок
SURVEYS|Досліджень місцевості
ARTIFACTS|Відновлено артефактів
RARE_ARTIFACTS|Рідкісних артефактів
RARE_ALERT|Сповіщення про рідкісний артефакт
ARTIFACT_RESTORED|Рідкісний артефакт відновлено
FIRST_ARTIFACT|ЗНАЙДЕНО НОВИЙ АРТЕФАКТ
DOCK_WINDOWS|Рухати прив'язані вікна разом
EXPEDITION_TIME|Час експедиції
TOTAL_TIME|Усі експедиції
RECENT_ARTIFACTS|Останні артефакти
ARCHAEOLOGY_UNAVAILABLE|Археологічні дані цього персонажа недоступні.
RACE_DISCOVERY_NOTE|Раси відомих розкопок визначаються відразу; нові місця запам'ятовуються після дослідження місцевості.
STRICT_NOTE|Суворий режим прокладає маршрут лише до розкопок відомої відповідної раси.
WAYPOINT_FAILED|Blizzard не зміг поставити позначку на цій карті. Стрілка PlanetOfArchaeology залишається доступною.
TARGET_REACHED|ВИ ДІСТАЛИСЯ РОЗКОПОК
START_HERE|Почати експедицію тут
START_DIGGING|ПОЧАТИ РОЗКОПКИ
NEARBY_SITE|Розкопки поруч
TRACK_SITE|ВІДСТЕЖУВАТИ
NOT_NOW|НЕ ЗАРАЗ
AUTO_PROMPT|Пропонувати експедицію поблизу розкопок
LEFT_OPEN|Ліва кнопка: відкрити журнал
RIGHT_START|Права кнопка: меню експедиції
MIDDLE_NEXT|Середня кнопка: вибрати наступну ціль
CURRENT_AREA|Поточна місцевість
FINDS_REMAINING|Залишилося знахідок: %d
FINDS_SHORT|Знахідок: %d
SURVEY_READY_SHORT|ГОТОВО
FRAGMENTS_NEEDED|Для артефакту потрібно уламків: %d
SURVEY_ACTION|ДОСЛІДИТИ
SURVEY_HINT|Натисніть, щоб дослідити місцевість
EXPEDITION_MENU|Меню експедиції
OPEN_JOURNAL|Відкрити польовий журнал
SHOW_TRACKER|Показувати вікно маршруту
HIDE_TRACKER|Приховати вікно маршруту
CONTINENT_SITES|АКТИВНІ РОЗКОПКИ
CLICK_TO_TRACK|Натисніть на розкопки, щоб прокласти маршрут
TRACKING|ВІДСТЕЖУЄТЬСЯ
ROUTE_WINDOW|Маршрут експедиції
SURVEY_READY|Можна досліджувати
CURRENT_RESOURCES|Поточні уламки: %d / %d
ARTIFACT_PROGRESS|%d + %d / %d
ARTIFACT_PROGRESS_SHORT|%d / %d
CURRENT_ARTIFACT|Поточний артефакт
SOLVE_HINT|Ліва кнопка — відновити зібраний артефакт
KEYSTONE_ADD|Ліва кнопка — додати ключовий камінь
KEYSTONE_REMOVE|Права кнопка — вийняти останній ключовий камінь
KEYSTONE_STATUS|Вставлено: %d / %d  •  У сумках: %d
MOVE_WINDOW|Перетягніть, щоб перемістити
POSSIBLE_RACES|Можливі раси
TRACKER_SCALE|Масштаб вікна маршруту
DEBUG_ENABLED|Налагодження ввімкнено
DEBUG_DISABLED|Налагодження вимкнено
HUD_LOCKED|Вікно знахідок заблоковано
HUD_UNLOCKED|Вікно знахідок розблоковано
POSITIONS_RESET|Розташування вікон скинуто
DATABASE_RESET|Базу даних скинуто. Перезавантаження інтерфейсу.
NO_TARGET|Немає цілі експедиції
SITES_FOUND|Активних розкопок: %d
MANUAL_TARGET|Місце призначення вибрано вручну
SELECTED_REASON|Вибрано планувальником маршруту
PRIORITY|Пріоритет №%d
UNMAPPED|Раса ще не визначена
YARDS|%d ярд.
METERS|%d м
KILOMETERS|%.2f км
MINUTES|%d хв. %02d с
HOURS|%d год. %02d хв.
OPTIONS_HINT|Інші параметри доступні в меню Налаштування > Модифікації > PlanetOfArchaeology.
ARCHIVE_HINT|Повний каталог артефактів та історія знахідок цього персонажа.
ARCHIVE_ALL|УСІ
ARCHIVE_OBTAINED|ЗНАЙДЕНІ
ARCHIVE_MISSING|НЕ ЗНАЙДЕНІ
ARCHIVE_COUNTER|Знайдено: %d / %d  •  Не знайдено: %d
ARCHIVE_ALL_RACES|Усі раси
ARCHIVE_RACE_COUNT|Знайдено: %d / %d
ARCHIVE_OBTAINED_STATUS|Знайдено
ARCHIVE_MISSING_STATUS|Ще не знайдено
ARCHIVE_COMPLETIONS|Відновлено разів: %d
ARCHIVE_FIRST_COMPLETION|Уперше відновлено: %s
ARCHIVE_NOT_YET|Цей артефакт ще не відновлено.
ARCHIVE_NO_DESCRIPTION|Опис цього артефакту недоступний.
ARCHIVE_SELL_PRICE|Ціна продажу
ARCHIVE_EMPTY|Немає артефактів
ARCHIVE_EMPTY_HINT|Жоден артефакт не відповідає фільтру або історія знахідок Blizzard недоступна.
RESIZE_WINDOW|Перетягніть кут, щоб змінити розмір
MAIN_WINDOW_SCALE|Масштаб головного вікна
MINIMAP_BUTTON_SCALE|Розмір кнопки мінікарти
EXPEDITION_ACTIVE|Експедиція триває
EXPEDITION_INACTIVE|Експедицію не розпочато
MENU_START_HINT|Прокласти маршрут розкопками цього континенту
MENU_STOP_HINT|Завершити маршрут і приховати інструменти експедиції
MENU_NEXT_HINT|Вибрати наступні відповідні розкопки
MENU_TRACKER_HINT|Список розкопок зі стрілками напрямку
MENU_RESEARCH_HINT|Усі раси, знайдені та відсутні артефакти
MENU_SETTINGS_HINT|Масштаб, непрозорість і параметри навігації
ACHIEVEMENTS|ДОСЯГНЕННЯ
ACH_WISH_ADD|ДОДАТИ ДО БАЖАНОГО
ACH_WISH_REMOVE|ВИЛУЧИТИ З БАЖАНОГО
ACH_TRACK|ВІДСТЕЖУВАТИ
ACH_UNTRACK|НЕ ВІДСТЕЖУВАТИ
ACH_TRACK_ERROR|Не вдалося змінити відстеження. Перевірте ліміт відстежуваних досягнень.
ACH_PROGRESS|Виконано умов: %d / %d
ACH_DONE|Зараховано
ACH_EXP_ALL|Усі доповнення
ACH_EXP_GENERAL|Загальні / Інше
ACH_EXP_CATA|Катаклізм
ACH_EXP_MOP|Тумани Пандарії
ACH_EXP_WOD|Воєначальники Дренору
ACH_EXP_LEGION|Легіон
ACH_EXP_BFA|Битва за Азерот
ACH_EARNED|Здобуті
ACH_MISSING|Не здобуті
ACH_POINTS|%d очок
ACH_COUNTER|Здобуто: %d / %d
ACH_REWARD|Нагорода
ACH_CRITERIA|Умови
ACH_UNAVAILABLE|Археологічні досягнення поки недоступні. Відкрийте цю вкладку знову після завантаження гри.
ACH_EMPTY|Немає досягнень за цим фільтром.
]]
for key, value in text:gmatch("([^\n|]+)|([^\n]*)") do L[key] = value:gsub("\\n", "\n") end
