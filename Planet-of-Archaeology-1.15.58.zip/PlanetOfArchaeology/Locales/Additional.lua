local _, RP = ...
-- key | German | Italian | Brazilian Portuguese | Korean | Simplified Chinese | Traditional Chinese
local locales = {"deDE", "itIT", "ptBR", "koKR", "zhCN", "zhTW"}
for _, locale in ipairs(locales) do RP.locales[locale] = {} end
local messages = [[
LANGUAGE|Sprache|Lingua|Idioma|언어|语言|語言
LANGUAGE_AUTO|Automatisch|Automatica|Automático|자동|自动|自動
SERVER_TIME|Serverzeit|ora del server|horário do servidor|서버 시간|服务器时间|伺服器時間
LEGION_BEGINS|Beginn: |Inizio: |Início: |시작: |开始：|開始：
WISH_ADD|ZUR WUNSCHLISTE|AGGIUNGI AI DESIDERI|ADICIONAR AOS DESEJOS|위시리스트에 추가|加入心愿单|加入願望清單
WISH_TAB|Wunschliste|Desideri|Lista de desejos|위시리스트|心愿单|願望清單
LEGION_ALL|Alle Belohnungen|Tutte le ricompense|Todas as recompensas|모든 보상|全部奖励|所有獎勵
WISH_EMPTY|Noch keine Wünsche. Wähle eine Belohnung aus der Liste.|Nessun desiderio. Scegli una ricompensa dall'elenco completo.|Nenhum desejo ainda. Selecione uma recompensa na lista completa.|아직 원하는 보상이 없습니다. 전체 목록에서 보상을 선택하세요.|心愿单为空。请从完整列表中选择奖励。|願望清單為空。請從完整清單中選擇獎勵。
CALENDAR_ADD|ZUM KALENDER|AGGIUNGI AL CALENDARIO|ADICIONAR AO CALENDÁRIO|달력에 추가|加入日历|加入行事曆
CALENDAR_DESCRIPTION|Legion-Archäologiebelohnung für 14 Tage verfügbar.|Ricompensa archeologica di Legion disponibile per 14 giorni.|Recompensa de arqueologia de Legion disponível por 14 dias.|군단 고고학 보상을 14일 동안 획득할 수 있습니다.|军团考古奖励将开放14天。|軍臨天下考古獎勵將開放14天。
CALENDAR_CONFIRM|Termin vorbereitet. Klicke im Kalender auf Erstellen.|Evento pronto. Premi Crea nel calendario per salvarlo.|Evento preparado. Clique em Criar no calendário para salvá-lo.|일정이 준비되었습니다. 달력에서 만들기를 눌러 저장하세요.|事件已准备好。请在日历中点击创建以保存。|事件已準備好。請在行事曆中點擊建立以儲存。
CALENDAR_BUSY|Speichere oder schließe zuerst den offenen Termin.|Salva o chiudi prima l'evento aperto.|Salve ou feche o evento atual primeiro.|먼저 열려 있는 일정을 저장하거나 닫으세요.|请先保存或关闭当前日历事件。|請先儲存或關閉目前的行事曆事件。
CALENDAR_UNAVAILABLE|Für dieses Datum kann derzeit kein Termin erstellt werden.|Al momento non è possibile creare un evento per questa data.|Não é possível criar um evento para esta data agora.|지금은 해당 날짜에 일정을 만들 수 없습니다.|目前无法为该日期创建事件。|目前無法為該日期建立事件。
WISH_REMOVE|AUS WUNSCHLISTE ENTFERNEN|RIMUOVI DAI DESIDERI|REMOVER DOS DESEJOS|위시리스트에서 제거|移出心愿单|移出願望清單
WISH_AVAILABLE|WUNSCHBELOHNUNG VERFÜGBAR|RICOMPENSA DESIDERATA DISPONIBILE|RECOMPENSA DESEJADA DISPONÍVEL|원하는 보상 획득 가능|心愿奖励已开放|願望獎勵已開放
TRACKER_COLLAPSE|Minimalansicht — nur aktuelles Ziel|Vista minima — solo obiettivo attuale|Modo mínimo — apenas o alvo atual|최소 모드 — 현재 목표만|精简模式：仅显示当前目标|精簡模式：僅顯示目前目標
TRACKER_EXPAND|Vollständige Route anzeigen|Espandi l'itinerario completo|Expandir rota completa|전체 경로 펼치기|展开完整路线|展開完整路線
MAIN_COLLAPSE|Kompaktes Journal — Völkerleiste ausblenden|Diario compatto — nascondi le razze|Diário compacto — ocultar raças|간소화 일지 — 종족 목록 숨기기|精简日志：隐藏种族侧栏|精簡日誌：隱藏種族側欄
MAIN_EXPAND|Journal und Völkerleiste erweitern|Espandi diario e razze|Expandir diário e raças|일지 및 종족 목록 펼치기|展开日志和种族侧栏|展開日誌和種族側欄
DIRECTION|GRABUNGEN|SCAVI|ESCAVAÇÕES|발굴지|挖掘场|挖掘場
LEGION_MAP_FALLBACK|Wegpunkt abgelehnt. Zielkarte geöffnet: %.1f, %.1f.|Punto rifiutato da Blizzard. Mappa aperta: %.1f, %.1f.|Ponto rejeitado pela Blizzard. Mapa aberto: %.1f, %.1f.|블리자드 경유지 설정 실패. 목적지 지도: %.1f, %.1f.|暴雪拒绝了路径点。已打开目标地图：%.1f，%.1f。|暴雪拒絕了路徑點。已開啟目標地圖：%.1f，%.1f。
SPECIAL_EXPEDITIONS|EXPEDITIONEN|SPEDIZIONI|EXPEDIÇÕES|탐사|探险|探險
LEGION_TITLE|LEGION-EXPEDITIONEN|SPEDIZIONI DI LEGION|EXPEDIÇÕES DE LEGION|군단 탐사|军团探险|軍臨天下探險
LEGION_SUBTITLE|Seltene archäologische Funde der Verheerten Inseln|Rari reperti archeologici delle Isole Disperse|Achados arqueológicos raros das Ilhas Partidas|부서진 섬의 희귀 고고학 유물|破碎群岛的稀有考古发现|破碎群島的稀有考古發現
LEGION_CURRENT|AKTIVE EXPEDITION|SPEDIZIONE ATTIVA|EXPEDIÇÃO ATIVA|진행 중인 탐사|当前探险|目前探險
LEGION_NEXT|Nächste|Prossima|Próxima|다음|下一次|下一次
LEGION_NOW|JETZT|ORA|AGORA|현재|当前|目前
LEGION_DONE|Abgeschlossen|Completata|Concluída|완료|已完成|已完成
LEGION_NOT_DONE|Noch nicht abgeschlossen|Non ancora completata|Ainda não concluída|아직 미완료|尚未完成|尚未完成
LEGION_UNKNOWN|Daten zur Questreihe noch nicht verfügbar|Dati della serie di missioni non ancora disponibili|Dados da sequência de missões ainda indisponíveis|연속 퀘스트 정보를 아직 불러오지 못했습니다|任务线数据暂不可用|任務線資料暫不可用
LEGION_UNSUPPORTED|Kein bestätigter Rotationsplan für diese Region|Nessun calendario verificato per questa regione|Sem referência de rotação verificada para esta região|이 지역의 검증된 순환 일정이 없습니다|此地区没有已验证的轮换参考|此地區沒有已驗證的輪替參考
LEGION_REMAINING|Verfügbar für: |Disponibile per: |Disponível por: |남은 시간: |剩余时间：|剩餘時間：
LEGION_ENDS|Wechsel: |Cambio: |Troca: |변경: |更换：|更換：
LEGION_RETURNS|Rückkehr: |Ritorno: |Retorna: |재등장: |再次开放：|再次開放：
LEGION_CONTACT|Zu Dariness|Da Dariness|Ir até Dariness|다리네스에게|前往达瑞妮丝|前往達瑞妮絲
LEGION_CONTINUE|Expedition fortsetzen|Continua la spedizione|Continuar expedição|탐사 계속|继续探险|繼續探險
LEGION_NO_COORDS|Kein genauer Wegpunkt. Prüfe die Questverfolgung und Blizzard-Wegpunkte.|Punto esatto non disponibile. Controlla le missioni sulla mappa e i punti Blizzard.|Ponto exato indisponível. Confira as missões no mapa e a opção de ponto Blizzard.|정확한 경유지가 없습니다. 지도 퀘스트 추적과 블리자드 경유지 설정을 확인하세요.|无法设置精确路径点。请检查地图任务追踪及暴雪路径点设置。|無法設定精確路徑點。請檢查地圖任務追蹤及暴雪路徑點設定。
LEGION_DAYS|%dT %02dStd|%dg %02dh|%dd %02dh|%d일 %02d시간|%d天 %02d小时|%d天 %02d小時
LEGION_HOURS|%dStd %02dMin|%dh %02dm|%dh %02dm|%d시간 %02d분|%d小时 %02d分|%d小時 %02d分
LEGION_MINUTES|%dMin|%dm|%dmin|%d분|%d分|%d分
LEGION_KIND_mount|Reittier|Cavalcatura|Montaria|탈것|坐骑|坐騎
LEGION_KIND_pet|Haustier|Mascotte|Mascote|애완동물|宠物|寵物
LEGION_KIND_toy|Spielzeug|Giocattolo|Brinquedo|장난감|玩具|玩具
LEGION_KIND_item|Gegenstand|Oggetto|Item|아이템|物品|物品
PROJECT_READY|BEREIT ZUR RESTAURIERUNG|PRONTO DA RICOSTRUIRE|PRONTO PARA RESTAURAR|복원 준비 완료|可以复原|可以復原
PROJECT_READY_SHORT|BEREIT|PRONTO|PRONTO|준비 완료|就绪|就緒
LEGION_ESTIMATED|Rücksetzzeit unbekannt; Datum geschätzt|Ora di ripristino non disponibile; data approssimativa|Horário de reinício indisponível; data aproximada|초기화 시간 없음; 예상 날짜입니다|重置时间不可用，日期为估算值|重置時間不可用，日期為估算值
PROJECT_MISSING|Es fehlen: %d\nGrabe weiter nach Fragmenten dieses Volkes.|Mancano: %d\nContinua gli scavi per questa razza.|Faltam: %d\nContinue escavando para esta raça.|부족: %d\n이 종족의 발굴을 계속하세요.|还缺：%d\n请继续挖掘该种族的碎片。|還缺：%d\n請繼續挖掘該種族的碎片。
PROJECT_ROUTE|ROUTE PLANEN|PIANIFICA ITINERARIO|PLANEJAR ROTA|경로 계획|规划路线|規劃路線
PROJECT_SOLVE|ARTEFAKT RESTAURIEREN|RICOSTRUISCI MANUFATTO|RESTAURAR ARTEFATO|유물 복원|复原文物|復原文物
ROUTE_COMPACT_HINT|Klicken zum Umschalten. Gewählte Völker zuerst, dann Entfernung. Nächste löscht die Völkerwahl dieser Region.|Clicca per alternare. Prima le razze scelte, poi la distanza. Più vicino azzera le razze della regione.|Clique para alternar. Raças escolhidas primeiro, por distância. Mais próximo limpa as escolhas desta região.|클릭하여 전환합니다. 선택한 종족을 거리순으로 우선합니다. 가장 가까운 곳을 선택하면 지역 종족 선택이 초기화됩니다.|点击切换。优先显示所选种族，再按距离排序。选择最近将清除此地区的种族选择。|點擊切換。優先顯示所選種族，再按距離排序。選擇最近將清除此地區的種族選擇。
ROUTE_START_SHORT|START|INIZIA|INICIAR|시작|开始|開始
ROUTE_STOP_SHORT|BEENDEN|TERMINA|FINALIZAR|종료|结束|結束
ROUTE_RACE_HINT|Linksklick: auswählen. Rechts- oder Umschaltklick: höchste Priorität. Bei gleicher Priorität zählt die Entfernung.|Clic sinistro: seleziona. Destro o Maiusc-clic: priorità massima. A pari priorità si usa la distanza.|Clique esquerdo: selecionar. Direito ou Shift-clique: prioridade máxima. Empates são ordenados por distância.|좌클릭으로 선택. 우클릭 또는 Shift-클릭으로 최우선 지정. 우선순위가 같으면 거리순입니다.|左键选择，右键或Shift点击设为最高优先级。同优先级按距离排序。|左鍵選擇，右鍵或Shift點擊設為最高優先順序。同優先順序按距離排序。
KEYSTONE_NOT_ADDED|Steine wurden nicht geändert. Prüfe Gegenstand und Sockel; /rp debug aktiviert die Diagnose.|Pietre non modificate dal gioco. Controlla oggetto e incavi; /rp debug attiva la diagnostica.|O jogo não alterou as pedras. Confira item e engastes; /rp debug ativa o diagnóstico.|게임이 장착한 쐐기돌을 변경하지 않았습니다. 아이템과 홈을 확인하세요. /rp debug로 진단을 켭니다.|游戏未更改已镶嵌的符石。请检查物品和插槽；/rp debug可启用诊断。|遊戲未更改已鑲嵌的符石。請檢查物品和插槽；/rp debug可啟用診斷。
RESTORE_CAST|Restaurierung… %.1f s|Ricostruzione… %.1f s|Restaurando… %.1f s|복원 중… %.1f초|复原中… %.1f秒|復原中… %.1f秒
RESTORE_COMPLETE|Artefakt restauriert|Manufatto ricostruito|Artefato restaurado|유물 복원 완료|文物已复原|文物已復原
RESTORE_CANCELLED|Restaurierung abgebrochen|Ricostruzione annullata|Restauração cancelada|복원 취소됨|复原已取消|復原已取消
SUBTITLE|Dein Begleiter für Archäologie|Il tuo compagno di archeologia|Seu companheiro de arqueologia|고고학 탐사 도우미|沉浸式考古助手|沉浸式考古助手
START_EXPEDITION|EXPEDITION STARTEN|INIZIA SPEDIZIONE|INICIAR EXPEDIÇÃO|탐사 시작|开始探险|開始探險
STOP_EXPEDITION|EXPEDITION BEENDEN|TERMINA SPEDIZIONE|ENCERRAR EXPEDIÇÃO|탐사 종료|结束探险|結束探險
EXPEDITION|EXPEDITION|SPEDIZIONE|EXPEDIÇÃO|탐사|探险|探險
DIG_SITES|GRABUNGEN|SCAVI|ESCAVAÇÕES|발굴지|挖掘场|挖掘場
RACES|VÖLKER|RAZZE|RAÇAS|종족|种族|種族
RESEARCH|FORSCHUNG|RICERCHE|PESQUISA|연구|研究|研究
ARCHIVE|ARCHIV|ARCHIVIO|ARQUIVO|기록|档案|檔案
JOURNAL|JOURNAL|DIARIO|DIÁRIO|일지|日志|日誌
SETTINGS|EINSTELLUNGEN|IMPOSTAZIONI|CONFIGURAÇÕES|설정|设置|設定
NAVIGATION|Navigation|Navigazione|Navegação|길 안내|导航|導航
HUD|Fundanzeige|Pannello scavi|Painel de achados|발굴 패널|发掘面板|發掘面板
MAP|Karte|Mappa|Mapa|지도|地图|地圖
ADVANCED|Erweitert|Avanzate|Avançado|고급|高级|進階
INTERFACE|Oberfläche|Interfaccia|Interface|인터페이스|界面|介面
NEXT_TARGET|NÄCHSTES ZIEL|PROSSIMO OBIETTIVO|PRÓXIMO ALVO|다음 목표|下个目标|下個目標
NEW_TARGET|Neues Expeditionsziel|Nuovo obiettivo della spedizione|Novo alvo da expedição|새 탐사 목표|新的探险目标|新的探險目標
DIG_SITE_COMPLETE|GRABUNG ABGESCHLOSSEN|SCAVO COMPLETATO|ESCAVAÇÃO CONCLUÍDA|발굴지 완료|挖掘完成|挖掘完成
DIG_SITE|GRABUNGSSTÄTTE|SITO DI SCAVO|SÍTIO DE ESCAVAÇÃO|발굴지|挖掘场|挖掘場
ON_DIG_SITE|AN DER GRABUNGSSTÄTTE|NEL SITO DI SCAVO|NO SÍTIO DE ESCAVAÇÃO|발굴지 내부|位于挖掘场|位於挖掘場
SURVEY|Untersuchen|Rilevamento|Sondar|조사|勘测|勘測
UNKNOWN_RACE|Volk: unbekannt|Razza: sconosciuta|Raça: desconhecida|종족: 알 수 없음|种族：未知|種族：未知
UNKNOWN|Unbekannt|Sconosciuto|Desconhecido|알 수 없음|未知|未知
NO_SITES|Keine aktiven Grabungen auf der verfügbaren Karte|Nessuno scavo attivo sulla mappa disponibile|Nenhuma escavação ativa no mapa disponível|현재 지도에 활성 발굴지가 없습니다|当前地图没有可用的挖掘场|目前地圖沒有可用的挖掘場
NO_MATCHING|Keine passenden Grabungen|Nessuno scavo corrispondente|Nenhuma escavação correspondente|일치하는 발굴지 없음|没有符合条件的挖掘场|沒有符合條件的挖掘場
SHOW_ALL|Alle Grabungen anzeigen|Mostra tutti gli scavi|Mostrar todas as escavações|모든 발굴지 표시|显示全部挖掘场|顯示全部挖掘場
CLICK_DESTINATION|Klicken, um das Ziel festzulegen|Clicca per impostare la destinazione|Clique para definir o destino|클릭하여 목적지 설정|点击设置目的地|點擊設定目的地
RIGHT_CLICK|Rechtsklick für Optionen|Clic destro per le opzioni|Clique direito para opções|우클릭으로 옵션 열기|右键打开选项|右鍵開啟選項
SET_DESTINATION|Ziel festlegen|Imposta destinazione|Definir destino|목적지 설정|设置目的地|設定目的地
IGNORE_SITE|Grabung ignorieren|Ignora scavo|Ignorar escavação|발굴지 무시|忽略挖掘场|忽略挖掘場
UNIGNORE_SITE|Grabung wieder zulassen|Ripristina scavo|Restaurar escavação|발굴지 무시 해제|恢复挖掘场|恢復挖掘場
IGNORE_RACE|Rechtsklick: Volk ignorieren/wieder zulassen|Clic destro: ignora/ripristina questa razza|Clique direito: ignorar/restaurar esta raça|우클릭: 종족 무시/해제|右键忽略或恢复此种族|右鍵忽略或恢復此種族
PRIORITIZE_RACE|Volk bevorzugen|Dai priorità alla razza|Priorizar raça|종족 우선 지정|优先此种族|優先此種族
FRAGMENTS|Fragmente|Frammenti|Fragmentos|조각|碎片|碎片
KEYSTONES|Schlüsselsteine|Pietre chiave|Pedras-chave|쐐기돌|符石|符石
READY_TO_SOLVE|BEREIT ZUM ZUSAMMENSETZEN|PRONTO DA COMPLETARE|PRONTO PARA CONCLUIR|복원 가능|可以复原|可以復原
SOLVE|ZUSAMMENSETZEN|COMPLETA|CONCLUIR|복원|复原|復原
PROJECTS|ZUSAMMENBAU|RICOSTRUZIONE|MONTAGEM|복원|组装|組裝
PROJECTS_HINT|Aktuelle Projekte mit Fragmenten, Schlüsselsteinen und Restaurierung.|Progetti attuali con frammenti, pietre chiave e ricostruzione.|Projetos atuais com fragmentos, pedras-chave e restauração.|현재 고고학 프로젝트의 조각, 쐐기돌 및 유물 복원.|当前考古项目、碎片、符石及文物复原。|目前考古專案、碎片、符石及文物復原。
PROJECTS_COUNTER|Projekte: %d  •  Bereit: %d|Progetti: %d  •  Pronti: %d|Projetos: %d  •  Prontos: %d|프로젝트: %d  •  준비: %d|项目：%d  •  就绪：%d|專案：%d  •  就緒：%d
NO_PROJECTS|Derzeit keine Archäologieprojekte verfügbar.|Nessun progetto archeologico disponibile.|Nenhum projeto de arqueologia disponível.|현재 고고학 프로젝트가 없습니다.|目前没有可用的考古项目。|目前沒有可用的考古專案。
KEYSTONE_SHORT|STEINE %d/%d|PIETRE %d/%d|PEDRAS %d/%d|쐐기돌 %d/%d|符石 %d/%d|符石 %d/%d
NO_KEYSTONE_SOCKETS|KEIN STEINSOCKEL|NESSUN INCAVO|SEM ENGASTE|쐐기돌 홈 없음|没有符石插槽|沒有符石插槽
NORMAL|Gewöhnlich|Comune|Comum|일반|普通|普通
RARE|Selten|Raro|Raro|희귀|稀有|稀有
SELECTED|Für die Route ausgewählt|Selezionata per l'itinerario|Selecionada para a rota|경로에 선택됨|已选入路线|已選入路線
NOT_SELECTED|Nicht ausgewählt|Non selezionata|Não selecionada|선택 안 됨|未选择|未選擇
SHIFT_PRIORITY|Umschaltklick für höchste Priorität|Maiusc-clic per la priorità massima|Shift-clique para prioridade máxima|Shift-클릭으로 최우선 지정|Shift点击设为最高优先级|Shift點擊設為最高優先順序
ROUTE_NEAREST|Nächste|Più vicino|Mais próximo|가장 가까운 곳|最近|最近
ROUTE_PRIORITY|Völkerpriorität|Priorità razze|Prioridade de raça|종족 우선순위|种族优先级|種族優先順序
FILTER_PREFER|Bevorzugen|Preferisci|Preferir|선호|偏好|偏好
FILTER_STRICT|Strikt|Rigoroso|Estrito|엄격|严格|嚴格
ROUTE_MODE|Routenmodus|Modalità itinerario|Modo da rota|경로 모드|路线模式|路線模式
RACE_FILTER|Völkerfilter|Filtro razze|Filtro de raça|종족 필터|种族筛选|種族篩選
DISTANCE_UNITS|Entfernung|Distanza|Distância|거리|距离|距離
DISTANCE_AUTO|Auto: m / km|Auto: m / km|Auto: m / km|자동: m / km|自动：米/千米|自動：公尺/公里
DISTANCE_METERS|Nur Meter|Solo metri|Apenas metros|미터만|仅米|僅公尺
DISTANCE_KILOMETERS|Nur Kilometer|Solo chilometri|Apenas quilômetros|킬로미터만|仅千米|僅公里
AUTO_NEXT|Nächste Grabung automatisch wählen|Seleziona automaticamente il prossimo scavo|Selecionar próxima escavação automaticamente|다음 발굴지 자동 선택|自动选择下个挖掘场|自動選擇下個挖掘場
BLIZZARD_WAYPOINT|Blizzard-Wegpunkt verwenden|Punto di navigazione Blizzard|Ponto de navegação da Blizzard|블리자드 기본 경유지|暴雪内置路径点|暴雪內建路徑點
SHOW_ARROW|Pfeil anzeigen|Mostra freccia|Mostrar seta|화살표 표시|显示箭头|顯示箭頭
LOCK_HUD|Fundanzeige sperren|Blocca pannello scavi|Travar painel de achados|발굴 패널 잠금|锁定发掘面板|鎖定發掘面板
SOUNDS|Klänge|Suoni|Sons|소리|声音|音效
NOTIFICATIONS|Expeditionsmeldungen|Notifiche spedizione|Notificações de expedição|탐사 알림|探险通知|探險通知
TARGET_ALERTS|Gelegentliche Zielmeldungen|Avvisi occasionali sui nuovi obiettivi|Avisos ocasionais de novo alvo|새 목표 간헐적 알림|偶尔提示新目标|偶爾提示新目標
SHOW_MAP_PINS|Grabungsmarkierungen anzeigen|Mostra indicatori degli scavi|Mostrar marcadores de escavação|발굴지 지도 표시|显示挖掘场标记|顯示挖掘場標記
DEBUG|Diagnosemodus|Modalità debug|Modo de depuração|디버그 모드|调试模式|除錯模式
RESET_POSITION|Fensterpositionen zurücksetzen|Ripristina posizioni finestre|Redefinir posições das janelas|창 위치 초기화|重置窗口位置|重設視窗位置
RESET_DATABASE|Datenbank zurücksetzen|Reimposta database|Redefinir banco de dados|데이터베이스 초기화|重置数据库|重設資料庫
HUD_SCALE|Größe der Fundanzeige|Scala pannello scavi|Escala do painel|발굴 패널 크기|发掘面板缩放|發掘面板縮放
HUD_OPACITY|Deckkraft der Fundanzeige|Opacità pannello scavi|Opacidade do painel|발굴 패널 불투명도|发掘面板不透明度|發掘面板不透明度
INTERFACE_SCALE|Oberflächengröße|Scala interfaccia|Escala da interface|인터페이스 크기|界面缩放|介面縮放
INTERFACE_OPACITY|Oberflächendeckkraft|Opacità interfaccia|Opacidade da interface|인터페이스 불투명도|界面不透明度|介面不透明度
ARROW_SCALE|Pfeilgröße|Scala freccia|Escala da seta|화살표 크기|箭头缩放|箭頭縮放
TODAYS_EXPEDITION|HEUTIGE EXPEDITION|SPEDIZIONE DI OGGI|EXPEDIÇÃO DE HOJE|오늘의 탐사|今日探险|今日探險
DIGS_COMPLETED|Grabungen|Scavi|Escavações|발굴지|挖掘场|挖掘場
SURVEYS|Untersuchungen|Rilevamenti|Sondagens|조사 횟수|勘测次数|勘測次數
ARTIFACTS|Restaurierte Artefakte|Manufatti ricostruiti|Artefatos restaurados|복원한 유물|已复原文物|已復原文物
RARE_ARTIFACTS|Seltene Artefakte|Manufatti rari|Artefatos raros|희귀 유물|稀有文物|稀有文物
RARE_ALERT|Meldung für seltene Artefakte|Avviso manufatto raro|Alerta de artefato raro|희귀 유물 알림|稀有文物提示|稀有文物提示
ARTIFACT_RESTORED|Seltenes Artefakt restauriert|Manufatto raro ricostruito|Artefato raro restaurado|희귀 유물 복원 완료|稀有文物已复原|稀有文物已復原
FIRST_ARTIFACT|NEUES ARTEFAKT ENTDECKT|NUOVO MANUFATTO SCOPERTO|NOVO ARTEFATO DESCOBERTO|새 유물 발견|发现新文物|發現新文物
DOCK_WINDOWS|Fenster beim Bewegen verbunden halten|Mantieni le finestre collegate durante lo spostamento|Manter janelas vinculadas ao mover|이동 시 창 연결 유지|移动时保持窗口关联|移動時保持視窗連動
EXPEDITION_TIME|Expeditionsdauer|Durata spedizione|Tempo de expedição|탐사 시간|探险时间|探險時間
TOTAL_TIME|Alle Expeditionen|Tutte le spedizioni|Todas as expedições|전체 탐사|全部探险|全部探險
RECENT_ARTIFACTS|Letzte Artefakte|Manufatti recenti|Artefatos recentes|최근 유물|最近的文物|最近的文物
ARCHAEOLOGY_UNAVAILABLE|Keine Archäologiedaten für diesen Charakter verfügbar.|Dati archeologici non disponibili per questo personaggio.|Dados de arqueologia indisponíveis para este personagem.|이 캐릭터의 고고학 정보를 사용할 수 없습니다.|此角色的考古数据不可用。|此角色的考古資料不可用。
RACE_DISCOVERY_NOTE|Bekannte Völker werden sofort erkannt; neue Grabungen nach einer Untersuchung.|Le razze note sono identificate subito; i nuovi scavi dopo un rilevamento.|Raças conhecidas são identificadas de imediato; novos sítios após Sondar.|알려진 발굴지 종족은 즉시 표시되며 새 발굴지는 조사 후 학습합니다.|已知挖掘场种族会立即识别；新挖掘场将在勘测后识别。|已知挖掘場種族會立即識別；新挖掘場將在勘測後識別。
STRICT_NOTE|Strikter Modus nutzt nur Grabungen mit bekanntem, passendem Volk.|La modalità rigorosa usa solo scavi con razza nota e corrispondente.|O modo estrito usa apenas sítios com raça conhecida e correspondente.|엄격 모드는 종족이 확인되고 필터와 일치하는 발굴지만 선택합니다.|严格模式仅选择种族已知且符合筛选的挖掘场。|嚴格模式僅選擇種族已知且符合篩選的挖掘場。
WAYPOINT_FAILED|Blizzard konnte keinen Wegpunkt setzen. Der PlanetOfArchaeology-Pfeil bleibt verfügbar.|Blizzard non ha potuto impostare il punto. La freccia PlanetOfArchaeology resta disponibile.|A Blizzard não pôde definir o ponto. A seta do PlanetOfArchaeology continua disponível.|블리자드 경유지를 설정하지 못했습니다. PlanetOfArchaeology 화살표는 계속 사용할 수 있습니다.|暴雪无法设置路径点，仍可使用PlanetOfArchaeology箭头。|暴雪無法設定路徑點，仍可使用PlanetOfArchaeology箭頭。
TARGET_REACHED|GRABUNGSSTÄTTE ERREICHT|SCAVO RAGGIUNTO|ESCAVAÇÃO ALCANÇADA|발굴지 도착|已到达挖掘场|已到達挖掘場
START_HERE|Expedition hier beginnen|Inizia qui la spedizione|Iniciar expedição aqui|여기서 탐사 시작|在此开始探险|在此開始探險
START_DIGGING|GRABUNG BEGINNEN|INIZIA GLI SCAVI|INICIAR ESCAVAÇÃO|발굴 시작|开始挖掘|開始挖掘
NEARBY_SITE|Grabung in der Nähe|Scavo nelle vicinanze|Escavação próxima|근처 발굴지|附近有挖掘场|附近有挖掘場
TRACK_SITE|VERFOLGEN|SEGUI|RASTREAR|추적|追踪|追蹤
NOT_NOW|NICHT JETZT|NON ORA|AGORA NÃO|나중에|暂不|暫不
AUTO_PROMPT|Expedition bei nahen Grabungen vorschlagen|Suggerisci spedizioni vicino agli scavi|Sugerir expedição perto de escavações|발굴지 근처에서 탐사 제안|靠近挖掘场时建议探险|靠近挖掘場時建議探險
LEFT_OPEN|Linksklick: Journal öffnen|Clic sinistro: apri diario|Clique esquerdo: abrir diário|좌클릭: 일지 열기|左键：打开日志|左鍵：開啟日誌
RIGHT_START|Rechtsklick: Expeditionsmenü|Clic destro: menu spedizione|Clique direito: menu de expedição|우클릭: 탐사 메뉴|右键：探险菜单|右鍵：探險選單
MIDDLE_NEXT|Mittelklick: nächstes Ziel|Clic centrale: prossimo obiettivo|Clique do meio: próximo alvo|가운데 클릭: 다음 목표|中键：选择下个目标|中鍵：選擇下個目標
CURRENT_AREA|Aktuelles Gebiet|Zona attuale|Área atual|현재 지역|当前区域|目前區域
FINDS_REMAINING|Noch %d Funde|%d reperti rimanenti|%d achados restantes|남은 발굴: %d|剩余%d处发现|剩餘%d處發現
FINDS_SHORT|Funde: %d|Reperti: %d|Achados: %d|발굴: %d|发现：%d|發現：%d
SURVEY_READY_SHORT|BEREIT|PRONTO|PRONTO|준비 완료|就绪|就緒
FRAGMENTS_NEEDED|%d Fragmente für das Artefakt benötigt|Servono %d frammenti per il manufatto|Faltam %d fragmentos para o artefato|유물에 조각 %d개 필요|文物还需%d个碎片|文物還需%d個碎片
SURVEY_ACTION|UNTERSUCHEN|RILEVAMENTO|SONDAR|조사|勘测|勘測
SURVEY_HINT|Klicken zum Untersuchen|Clicca per il rilevamento|Clique para Sondar|클릭하여 조사|点击使用勘测|點擊使用勘測
EXPEDITION_MENU|Expeditionsmenü|Menu spedizione|Menu de expedição|탐사 메뉴|探险菜单|探險選單
OPEN_JOURNAL|Feldjournal öffnen|Apri diario sul campo|Abrir diário de campo|현장 일지 열기|打开野外日志|開啟野外日誌
SHOW_TRACKER|Routenfenster anzeigen|Mostra finestra itinerario|Mostrar janela da rota|경로 창 표시|显示路线窗口|顯示路線視窗
HIDE_TRACKER|Routenfenster ausblenden|Nascondi finestra itinerario|Ocultar janela da rota|경로 창 숨기기|隐藏路线窗口|隱藏路線視窗
CONTINENT_SITES|AKTIVE GRABUNGEN|SCAVI ATTIVI|ESCAVAÇÕES ATIVAS|활성 발굴지|当前挖掘场|目前挖掘場
CLICK_TO_TRACK|Grabung für die Navigation anklicken|Clicca uno scavo per raggiungerlo|Clique em um sítio para navegar|발굴지를 클릭하여 길 안내|点击挖掘场进行导航|點擊挖掘場進行導航
TRACKING|VERFOLGUNG|TRACCIAMENTO|RASTREANDO|추적 중|追踪中|追蹤中
ROUTE_WINDOW|Expeditionsroute|Itinerario della spedizione|Rota da expedição|탐사 경로|探险路线|探險路線
SURVEY_READY|Bereit zum Untersuchen|Pronto al rilevamento|Pronto para Sondar|조사 준비 완료|可以勘测|可以勘測
CURRENT_RESOURCES|Aktuelle Fragmente: %d / %d|Frammenti attuali: %d / %d|Fragmentos atuais: %d / %d|현재 조각: %d / %d|当前碎片：%d / %d|目前碎片：%d / %d
CURRENT_ARTIFACT|Aktuelles Artefakt|Manufatto attuale|Artefato atual|현재 유물|当前文物|目前文物
SOLVE_HINT|Linksklick zum Restaurieren des vollständigen Artefakts|Clic sinistro per ricostruire il manufatto completo|Clique esquerdo para restaurar o artefato completo|좌클릭으로 완성된 유물 복원|左键复原材料齐全的文物|左鍵復原材料齊全的文物
KEYSTONE_ADD|Linksklick: Schlüsselstein hinzufügen|Clic sinistro: aggiungi pietra chiave|Clique esquerdo: adicionar pedra-chave|좌클릭: 쐐기돌 추가|左键添加符石|左鍵新增符石
KEYSTONE_REMOVE|Rechtsklick: letzten Schlüsselstein entfernen|Clic destro: rimuovi l'ultima pietra|Clique direito: remover última pedra-chave|우클릭: 마지막 쐐기돌 제거|右键移除最后一个符石|右鍵移除最後一個符石
KEYSTONE_STATUS|Gesockelt: %d / %d  •  In Taschen: %d|Inserite: %d / %d  •  Nelle borse: %d|Engastadas: %d / %d  •  Nas bolsas: %d|장착: %d / %d  •  가방: %d|已镶嵌：%d / %d  •  背包：%d|已鑲嵌：%d / %d  •  背包：%d
MOVE_WINDOW|Zum Verschieben ziehen|Trascina per spostare|Arraste para mover|드래그하여 이동|拖动以移动|拖曳以移動
POSSIBLE_RACES|Mögliche Völker|Razze possibili|Raças possíveis|가능한 종족|可能的种族|可能的種族
TRACKER_SCALE|Routenfenstergröße|Scala finestra itinerario|Escala da janela da rota|경로 창 크기|路线窗口缩放|路線視窗縮放
DEBUG_ENABLED|Diagnose aktiviert|Debug attivato|Depuração ativada|디버그 켜짐|调试已开启|除錯已開啟
DEBUG_DISABLED|Diagnose deaktiviert|Debug disattivato|Depuração desativada|디버그 꺼짐|调试已关闭|除錯已關閉
HUD_LOCKED|Fundanzeige gesperrt|Pannello scavi bloccato|Painel travado|발굴 패널 잠김|发掘面板已锁定|發掘面板已鎖定
HUD_UNLOCKED|Fundanzeige entsperrt|Pannello scavi sbloccato|Painel destravado|발굴 패널 잠금 해제|发掘面板已解锁|發掘面板已解鎖
POSITIONS_RESET|Fensterpositionen zurückgesetzt|Posizioni finestre ripristinate|Posições das janelas redefinidas|창 위치 초기화됨|窗口位置已重置|視窗位置已重設
DATABASE_RESET|Datenbank zurückgesetzt. Oberfläche wird neu geladen.|Database reimpostato. Ricaricamento interfaccia.|Banco de dados redefinido. Recarregando interface.|데이터베이스 초기화됨. 인터페이스를 다시 불러옵니다.|数据库已重置，正在重载界面。|資料庫已重設，正在重新載入介面。
NO_TARGET|Kein Expeditionsziel|Nessun obiettivo di spedizione|Nenhum alvo de expedição|탐사 목표 없음|没有探险目标|沒有探險目標
SITES_FOUND|%d aktive Grabungen|%d scavi attivi|%d escavações ativas|활성 발굴지 %d곳|%d个当前挖掘场|%d個目前挖掘場
MANUAL_TARGET|Manuelles Ziel|Destinazione manuale|Destino manual|수동 목적지|手动目的地|手動目的地
SELECTED_REASON|Vom Routenplaner ausgewählt|Scelto dal pianificatore|Selecionado pelo planejador|경로 계획에서 선택됨|由路线规划器选择|由路線規劃器選擇
PRIORITY|Priorität #%d|Priorità n. %d|Prioridade nº %d|우선순위 #%d|优先级%d|優先順序%d
UNMAPPED|Unbekanntes Volk|Razza non osservata|Raça não observada|미확인 종족|未确认种族|未確認種族
YARDS|%d yd|%d iarde|%d jardas|%d야드|%d码|%d碼
METERS|%d m|%d m|%d m|%dm|%d米|%d公尺
KILOMETERS|%.2f km|%.2f km|%.2f km|%.2fkm|%.2f千米|%.2f公里
MINUTES|%dMin %02dSek|%dm %02ds|%dmin %02ds|%d분 %02d초|%d分 %02d秒|%d分 %02d秒
HOURS|%dStd %02dMin|%dh %02dm|%dh %02dmin|%d시간 %02d분|%d小时 %02d分|%d小時 %02d分
OPTIONS_HINT|Weitere Optionen unter Optionen > AddOns > PlanetOfArchaeology.|Altre opzioni in Opzioni > AddOn > PlanetOfArchaeology.|Mais opções em Opções > AddOns > PlanetOfArchaeology.|설정 > 애드온 > PlanetOfArchaeology에서 추가 옵션을 확인하세요.|更多选项位于选项 > 插件 > PlanetOfArchaeology。|更多選項位於選項 > 插件 > PlanetOfArchaeology。
ARCHIVE_HINT|Vollständiger Artefaktkatalog mit der Fundhistorie dieses Charakters.|Catalogo completo dei manufatti con la cronologia di questo personaggio.|Catálogo completo de artefatos com o histórico deste personagem.|이 캐릭터의 복원 기록을 포함한 전체 유물 목록입니다.|完整文物目录及此角色的复原历史。|完整文物目錄及此角色的復原歷史。
ARCHIVE_ALL|ALLE|TUTTI|TODOS|전체|全部|全部
ARCHIVE_OBTAINED|GEFUNDEN|OTTENUTI|OBTIDOS|획득|已获得|已獲得
ARCHIVE_MISSING|FEHLEND|MANCANTI|FALTANTES|미획득|未获得|未獲得
ARCHIVE_COUNTER|Gefunden: %d / %d  •  Fehlend: %d|Ottenuti: %d / %d  •  Mancanti: %d|Obtidos: %d / %d  •  Faltam: %d|획득: %d / %d  •  미획득: %d|已获得：%d / %d  •  未获得：%d|已獲得：%d / %d  •  未獲得：%d
ARCHIVE_ALL_RACES|Alle Völker|Tutte le razze|Todas as raças|모든 종족|全部种族|全部種族
ARCHIVE_RACE_COUNT|%d / %d gefunden|%d / %d ottenuti|%d / %d obtidos|%d / %d 획득|已获得%d / %d|已獲得%d / %d
ARCHIVE_OBTAINED_STATUS|Gefunden|Ottenuto|Obtido|획득|已获得|已獲得
ARCHIVE_MISSING_STATUS|Noch nicht gefunden|Non ancora ottenuto|Ainda não obtido|아직 미획득|尚未获得|尚未獲得
ARCHIVE_COMPLETIONS|Restauriert: %d|Ricostruito: %d|Restaurado: %d|복원 횟수: %d|复原次数：%d|復原次數：%d
ARCHIVE_FIRST_COMPLETION|Erstmals restauriert: %s|Prima ricostruzione: %s|Primeira restauração: %s|첫 복원: %s|首次复原：%s|首次復原：%s
ARCHIVE_NOT_YET|Dieses Artefakt wurde noch nicht restauriert.|Questo manufatto non è ancora stato ricostruito.|Este artefato ainda não foi restaurado.|이 유물은 아직 복원하지 않았습니다.|此文物尚未复原。|此文物尚未復原。
ARCHIVE_NO_DESCRIPTION|Keine Beschreibung für dieses Artefakt verfügbar.|Nessuna descrizione disponibile per questo manufatto.|Não há descrição disponível para este artefato.|이 유물의 설명이 없습니다.|此文物暂无描述。|此文物暫無描述。
ARCHIVE_SELL_PRICE|Verkaufspreis|Prezzo di vendita|Preço de venda|판매 가격|出售价格|出售價格
ARCHIVE_EMPTY|Keine Artefakte|Nessun manufatto|Nenhum artefato|유물 없음|没有文物|沒有文物
ARCHIVE_EMPTY_HINT|Keine passenden Artefakte oder Blizzard-Fundhistorie nicht verfügbar.|Nessun manufatto corrispondente o cronologia Blizzard non disponibile.|Nenhum artefato corresponde ao filtro, ou o histórico Blizzard está indisponível.|필터에 맞는 유물이 없거나 블리자드 복원 기록을 사용할 수 없습니다.|没有符合筛选的文物，或暴雪复原历史不可用。|沒有符合篩選的文物，或暴雪復原歷史不可用。
RESIZE_WINDOW|Ecke ziehen, um die Größe zu ändern|Trascina l'angolo per ridimensionare|Arraste o canto para redimensionar|모서리를 드래그하여 크기 조절|拖动边角调整大小|拖曳邊角調整大小
MAIN_WINDOW_SCALE|Hauptfenstergröße|Scala finestra principale|Escala da janela principal|주 창 크기|主窗口缩放|主視窗縮放
MINIMAP_BUTTON_SCALE|Minikartensymbolgröße|Dimensione icona minimappa|Tamanho do ícone do minimapa|미니맵 버튼 크기|小地图按钮大小|小地圖按鈕大小
EXPEDITION_ACTIVE|Expedition aktiv|Spedizione attiva|Expedição ativa|탐사 진행 중|探险进行中|探險進行中
EXPEDITION_INACTIVE|Expedition nicht gestartet|Spedizione non iniziata|Expedição não iniciada|탐사 시작 안 됨|探险尚未开始|探險尚未開始
MENU_START_HINT|Route durch die Grabungen dieses Kontinents planen|Pianifica un itinerario fra gli scavi del continente|Planejar rota pelas escavações deste continente|이 대륙의 발굴지 경로 계획|规划本大陆挖掘路线|規劃本大陸挖掘路線
MENU_STOP_HINT|Route beenden und Expeditionswerkzeuge ausblenden|Termina l'itinerario e nascondi gli strumenti|Encerrar rota e ocultar ferramentas|경로 종료 및 탐사 도구 숨기기|结束路线并隐藏探险工具|結束路線並隱藏探險工具
MENU_NEXT_HINT|Nächste passende Grabung auswählen|Seleziona il prossimo scavo corrispondente|Selecionar próxima escavação correspondente|다음 일치하는 발굴지 선택|选择下个符合条件的挖掘场|選擇下個符合條件的挖掘場
MENU_TRACKER_HINT|Grabungsliste mit Richtungspfeilen|Elenco scavi con frecce direzionali|Lista de escavações com setas de direção|방향 화살표가 있는 발굴지 목록|带实时方向箭头的挖掘场列表|附即時方向箭頭的挖掘場清單
MENU_RESEARCH_HINT|Alle Völker, gefundene und fehlende Artefakte|Tutte le razze e i manufatti ottenuti o mancanti|Todas as raças e artefatos obtidos ou faltantes|모든 종족의 획득 및 미획득 유물|所有种族及已获得和未获得的文物|所有種族及已獲得和未獲得的文物
MENU_SETTINGS_HINT|Größe, Deckkraft und Navigation|Scala, opacità e navigazione|Escala, opacidade e navegação|크기, 불투명도 및 길 안내|缩放、不透明度及导航|縮放、不透明度及導航
ACHIEVEMENTS|ERFOLGE|IMPRESE|CONQUISTAS|업적|成就|成就
ACH_WISH_ADD|ZUR WUNSCHLISTE|AGGIUNGI AI DESIDERI|ADICIONAR AOS DESEJOS|위시리스트에 추가|加入心愿单|加入願望清單
ACH_WISH_REMOVE|AUS WUNSCHLISTE ENTFERNEN|RIMUOVI DAI DESIDERI|REMOVER DOS DESEJOS|위시리스트에서 제거|移出心愿单|移出願望清單
ACH_TRACK|VERFOLGEN|SEGUI|RASTREAR|추적|追踪|追蹤
ACH_UNTRACK|NICHT MEHR VERFOLGEN|NON SEGUIRE|PARAR DE RASTREAR|추적 중지|停止追踪|停止追蹤
ACH_TRACK_ERROR|Verfolgung nicht geändert. Prüfe das Limit verfolgter Erfolge.|Impossibile modificare il tracciamento. Controlla il limite delle imprese seguite.|Não foi possível alterar o rastreamento. Confira o limite de conquistas rastreadas.|추적을 변경할 수 없습니다. 추적 중인 업적 수 제한을 확인하세요.|无法更改追踪，请检查成就追踪数量上限。|無法更改追蹤，請檢查成就追蹤數量上限。
ACH_PROGRESS|Bedingungen erfüllt: %d / %d|Requisiti soddisfatti: %d / %d|Requisitos cumpridos: %d / %d|조건 완료: %d / %d|已满足条件：%d / %d|已滿足條件：%d / %d
ACH_DONE|Abgeschlossen|Completato|Concluído|완료|已完成|已完成
ACH_EXP_ALL|Alle Erweiterungen|Tutte le espansioni|Todas as expansões|모든 확장팩|全部资料片|全部資料片
ACH_EXP_GENERAL|Allgemein / Sonstige|Generale / Altro|Geral / Outros|일반 / 기타|综合/其他|綜合/其他
ACH_EXP_CATA|Cataclysm|Cataclysm|Cataclysm|대격변|大地的裂变|浩劫與重生
ACH_EXP_MOP|Mists of Pandaria|Mists of Pandaria|Mists of Pandaria|판다리아의 안개|熊猫人之谜|潘達利亞之謎
ACH_EXP_WOD|Warlords of Draenor|Warlords of Draenor|Warlords of Draenor|드레노어의 전쟁군주|德拉诺之王|德拉諾之霸
ACH_EXP_LEGION|Legion|Legion|Legion|군단|军团再临|軍臨天下
ACH_EXP_BFA|Battle for Azeroth|Battle for Azeroth|Battle for Azeroth|격전의 아제로스|争霸艾泽拉斯|決戰艾澤拉斯
ACH_EARNED|Erreicht|Ottenuta|Obtida|달성|已获得|已獲得
ACH_MISSING|Nicht erreicht|Non ottenuta|Não obtida|미달성|未获得|未獲得
ACH_POINTS|%d Punkte|%d punti|%d pontos|%d점|%d点|%d點
ACH_COUNTER|%d / %d erreicht|%d / %d ottenute|%d / %d obtidas|%d / %d 달성|已获得%d / %d|已獲得%d / %d
ACH_REWARD|Belohnung|Ricompensa|Recompensa|보상|奖励|獎勵
ACH_CRITERIA|Bedingungen|Requisiti|Requisitos|조건|条件|條件
ACH_UNAVAILABLE|Archäologieerfolge noch nicht verfügbar. Öffne diesen Reiter nach dem Laden erneut.|Imprese archeologiche non ancora disponibili. Riapri la scheda dopo il caricamento.|Conquistas de arqueologia ainda indisponíveis. Reabra esta aba após o carregamento.|고고학 업적 정보를 아직 사용할 수 없습니다. 게임 로딩 후 이 탭을 다시 여세요.|考古成就暂不可用。请在游戏加载后重新打开此页。|考古成就暫不可用。請在遊戲載入後重新開啟此頁。
ACH_EMPTY|Keine Erfolge für diesen Filter.|Nessuna impresa corrisponde al filtro.|Nenhuma conquista corresponde ao filtro.|필터에 맞는 업적이 없습니다.|没有符合筛选条件的成就。|沒有符合篩選條件的成就。
]]
for line in messages:gmatch("[^\r\n]+") do
    local fields = {}
    for value in (line .. "|"):gmatch("(.-)|") do fields[#fields + 1] = value end
    for i, locale in ipairs(locales) do
        RP.locales[locale][fields[1]] = fields[i + 1]:gsub("\\n", "\n")
    end
end
-- Brand and numeric-only formats are intentionally language-independent.
for _, locale in ipairs(locales) do
    for _, key in ipairs({"ADDON_NAME", "ARTIFACT_PROGRESS", "ARTIFACT_PROGRESS_SHORT"}) do
        RP.locales[locale][key] = RP.locales.enUS[key]
    end
end
-- Both Spanish regions share these UI terms; keep separate dictionaries for
-- regional wording and future translations instead of coercing the locale ID.
RP.locales.esMX = {}
for key, value in pairs(RP.locales.esES) do RP.locales.esMX[key] = value end
RP.locales.esMX.SETTINGS = "CONFIGURACIÓN"
RP.locales.esMX.OPTIONS_HINT = "Más opciones en Opciones > AddOns > PlanetOfArchaeology."
