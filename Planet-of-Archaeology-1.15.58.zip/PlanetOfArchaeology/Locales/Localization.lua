local _, RP = ...
local Localization = {}
RP:RegisterModule("Localization", Localization)

-- Keep the lookup table stable: modules retain references to RP.L.
RP.L = {}
function Localization:RememberArtifact(name, itemID)
    if not name or not itemID or not RP.UkrainianArtifacts then return end
    self.artifactNames = self.artifactNames or {}
    self.artifactNames[name] = RP.UkrainianArtifacts[itemID]
end

-- Presentation only: native names remain untouched for Blizzard API matching.
function Localization:DisplayName(name, itemID)
    if self.locale ~= "ukUA" then return name end
    if RP.ContentLocalization and RP.ContentLocalization.names[name] then return RP.ContentLocalization.names[name] end
    if itemID and RP.UkrainianArtifacts[itemID] then return RP.UkrainianArtifacts[itemID] end
    if self.artifactNames and self.artifactNames[name] then return self.artifactNames[name] end
    for index, race in pairs(RP.Archaeology and RP.Archaeology.races or {}) do
        if race.name == name then return RP.UkrainianRaces[index] or name end
    end
    return name
end

function Localization:Apply()
    local choice = RP.db and RP.db.settings.language or "AUTO"
    local locale = choice == "AUTO" and GetLocale() or choice
    if locale == "enGB" then locale = "enUS" end
    if locale == "ptPT" then locale = "ptBR" end
    local selected = RP.locales[locale] or RP.locales.enUS
    local reverse = {}
    for key, value in pairs(RP.L) do reverse[value] = key end
    for key, value in pairs(RP.locales.enUS) do RP.L[key] = selected[key] or value end
    self.locale = locale
    if locale == "ukUA" then
        for _, entries in pairs(RP.ArtifactCatalog or {}) do
            for _, artifact in ipairs(entries) do
                self:RememberArtifact(artifact.name, artifact.itemID)
                if C_Item and C_Item.GetItemInfo then
                    self:RememberArtifact(C_Item.GetItemInfo(artifact.itemID), artifact.itemID)
                end
            end
        end
    end
    if not RP.initialized then return end
    local function Translate(text)
        return reverse[text] and RP.L[reverse[text]] or text
    end
    local visited = {}
    local function Visit(frame)
        if not frame or visited[frame] then return end
        visited[frame] = true
        if frame.GetRegions then
            for _, region in ipairs({frame:GetRegions()}) do
                if region.GetText and region.SetText then
                    local text = region:GetText()
                    local translated = text and Translate(text)
                    if translated and translated ~= text then region:SetText(translated) end
                end
            end
        end
        if frame.GetChildren then for _, child in ipairs({frame:GetChildren()}) do Visit(child) end end
    end
    for _, module in pairs(RP.modules) do Visit(module.frame); Visit(module.panel); Visit(module.menu) end
    local settings = RP.Settings and RP.Settings.panel
    if settings then
        for _, control in ipairs(settings.cycles) do
            control.prefix = Translate(control.prefix)
            for i, label in ipairs(control.labels) do control.labels[i] = Translate(label) end
        end
        RP.Settings:RefreshPanel()
    end
    if RP.MainFrame and RP.MainFrame.frame then
        if RP.MainFrame.LayoutTabs then RP.MainFrame:LayoutTabs() end
        RP.MainFrame.archiveDirty = true
        RP.MainFrame:Refresh()
    end
    if RP.SiteTracker and RP.SiteTracker.frame then RP.SiteTracker:Refresh() end
    if RP.HUD and RP.HUD.frame then RP.HUD:Refresh() end
    if RP.AchievementsPage and RP.AchievementsPage.frame then RP.AchievementsPage:Refresh() end
    if RP.MinimapButton and RP.MinimapButton.menu then RP.MinimapButton:RefreshMenu() end
    if StaticPopupDialogs and StaticPopupDialogs.PLANETOFARCHAEOLOGY_RESET_DATABASE then
        StaticPopupDialogs.PLANETOFARCHAEOLOGY_RESET_DATABASE.text = RP.L.RESET_DATABASE .. "?"
    end
    RP:Fire("SPECIAL_EXPEDITIONS_UPDATED")
end
