local _, RP = ...

-- Item/race/quest-line IDs match the existing MIT-licensed ArtifactDB source.
-- Rotation order and EU/US reference dates are the supplied product specification.
RP.SpecialExpeditionData = {
    legion = {
        period = 14 * 86400,
        anchors = { [3] = 1785888000, [1] = 1785801600 }, -- Eche'ro: EU Aug 5 / US Aug 4, 2026 (UTC day).
        contact = { mapID = 627, x = 0.408, y = 0.264 },
        entries = {
            { name = "Crystalline Eye of Undravius", questID = 40857, lineID = 321, itemID = 131724, raceIndex = 3, kind = "toy" },
            { name = "Starlight Beacon", questID = 41171, lineID = 322, itemID = 131717, raceIndex = 5 },
            { name = "Spear of Rethu", questID = 41186, lineID = 323, itemID = 131733, raceIndex = 4 },
            { name = "Crown Jewels of Suramar", questID = 41174, lineID = 324, itemID = 131740, raceIndex = 5 },
            { name = "Imp Generator", questID = 41158, lineID = 325, itemID = 131735, raceIndex = 3 },
            { name = "Key of Kalyndras", questID = 41177, lineID = 326, itemID = 131745, raceIndex = 5 },
            { name = "Wyrmy Tunkins", questID = 41161, lineID = 327, itemID = 136922, raceIndex = 3, kind = "pet" },
            { name = "Shard of Sciallax", questID = 41180, lineID = 328, itemID = 134078, raceIndex = 5 },
            { name = "Prizerock Neckband", questID = 41189, lineID = 329, itemID = 131736, raceIndex = 4 },
            { name = "Blood of Young Mannoroth", questID = 41164, lineID = 330, itemID = 131743, raceIndex = 3 },
            { name = "Key to Nar'thalas Academy", questID = 41183, lineID = 331, itemID = 131744, raceIndex = 5 },
            { name = "Purple Hills of Mac'Aree / Eredath", questID = 41167, lineID = 332, itemID = 131732, raceIndex = 3 },
            { name = "Spirit of Eche'ro", questID = 41192, lineID = 333, itemID = 131734, raceIndex = 4, kind = "mount" },
        },
    },
}
