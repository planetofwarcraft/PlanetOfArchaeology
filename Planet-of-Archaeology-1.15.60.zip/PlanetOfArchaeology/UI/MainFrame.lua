local _, RP = ...

local MainFrame = { pages = {}, tabs = {}, selectedPage = "sites" }
RP:RegisterModule("MainFrame", MainFrame)

local function CreateScrollArea(parent, top, bottom)
    local scroll = CreateFrame("ScrollFrame", nil, parent)
    scroll:SetPoint("TOPLEFT", 8, top)
    scroll:SetPoint("BOTTOMRIGHT", -12, bottom)
    scroll:EnableMouseWheel(true)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(710, 1)
    scroll:SetScrollChild(child)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local range = self:GetVerticalScrollRange()
        self:SetVerticalScroll(math.max(0, math.min(range, self:GetVerticalScroll() - delta * 42)))
    end)
    return scroll, child
end

local function AddPageTitle(page, text, subtitle)
    local title = RP.Widgets:CreateTitle(page, text, "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    local note = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    note:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -5)
    note:SetPoint("RIGHT", page, "RIGHT", -18, 0)
    note:SetJustifyH("LEFT")
    note:SetWordWrap(false)
    note:SetMaxLines(1)
    note:SetTextColor(unpack(RP.colors.muted))
    note:SetText(subtitle or "")
    return title, note
end

local function GetLocalizedItemName(itemID)
    if not itemID then return nil end
    local getter = C_Item and C_Item.GetItemInfo or GetItemInfo
    if not getter then return nil end
    local ok, name = pcall(getter, itemID)
    return ok and name or nil
end

function MainFrame:OnInitialize()
    local frame = CreateFrame("Frame", "PlanetOfArchaeologyJournal", UIParent)
    frame:SetSize(1050, 650)
    -- Keep Blizzard panels above this window and its children.
    frame:SetFrameStrata("LOW")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(f) f.relicDragging = true; f:StartMoving() end)
    frame:SetScript("OnDragStop", function(f)
        f:StopMovingOrSizing()
        f.relicDragging = nil
        RP.Widgets:SavePosition(f, "main")
    end)
    if UISpecialFrames then table.insert(UISpecialFrames, "PlanetOfArchaeologyJournal") end

    local leftSection = CreateFrame("Frame", nil, frame)
    leftSection:SetSize(290, 650)
    leftSection:SetPoint("TOPLEFT")
    RP.Widgets:CreateRelicShell(leftSection)
    local rightSection = CreateFrame("Frame", nil, frame)
    rightSection:SetSize(752, 650)
    rightSection:SetPoint("TOPLEFT", leftSection, "TOPRIGHT", 8, 0)
    RP.Widgets:CreateRelicShell(rightSection)
    frame.leftSection, frame.rightSection = leftSection, rightSection

    for _, handle in ipairs({ leftSection, rightSection }) do
        handle:EnableMouse(true)
        handle:RegisterForDrag("LeftButton")
        handle:SetScript("OnDragStart", function() frame.relicDragging = true; frame:StartMoving() end)
        handle:SetScript("OnDragStop", function()
            frame:StopMovingOrSizing()
            frame.relicDragging = nil
            RP.Widgets:SavePosition(frame, "main")
        end)
    end

    local projectsHeader = RP.Widgets:CreateCategoryDivider(leftSection, RP.L.DIRECTION)
    projectsHeader:SetPoint("TOPLEFT", 20, -14)
    projectsHeader:SetPoint("TOPRIGHT", -20, -14)

    local projectsScroll = CreateFrame("ScrollFrame", nil, leftSection)
    projectsScroll:SetPoint("TOPLEFT", 14, -48)
    projectsScroll:SetPoint("BOTTOMRIGHT", -14, 18)
    projectsScroll:EnableMouseWheel(true)
    local projectsChild = CreateFrame("Frame", nil, projectsScroll)
    projectsChild:SetSize(262, 1)
    projectsScroll:SetScrollChild(projectsChild)
    projectsScroll:SetScript("OnMouseWheel", function(scrollFrame, delta)
        local range = scrollFrame:GetVerticalScrollRange()
        scrollFrame:SetVerticalScroll(math.max(0, math.min(range, scrollFrame:GetVerticalScroll() - delta * 44)))
    end)
    self.projectsRaceScroll = projectsScroll
    self.projectsRaceChild = projectsChild
    self.projectsRaceRows = {}

    local close = CreateFrame("Button", nil, rightSection, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -5, -5)
    close:SetScript("OnClick", function() frame:Hide() end)
    local compact = RP.Widgets:CreateCompactButton(rightSection)
    compact:SetPoint("TOPRIGHT", -31, -5)
    self.compactButton = compact
    compact:SetScript("OnClick", function()
        if InCombatLockdown() then return end
        RP.Widgets:TransitionLayout(frame, function()
            RP.db.settings.minimalMain = not RP.db.settings.minimalMain
            self:ApplyCompactMode()
            if RP.WindowLayout then RP.WindowLayout:Apply() end
        end)
    end)
    compact:HookScript("OnEnter", function(b)
        GameTooltip:SetOwner(b, "ANCHOR_LEFT")
        GameTooltip:SetText(RP.db.settings.minimalMain and RP.L.MAIN_EXPAND or RP.L.MAIN_COLLAPSE)
        GameTooltip:Show()
    end)
    compact:HookScript("OnLeave", GameTooltip_Hide)
    local rightHeader = CreateFrame("Frame", nil, rightSection)
    rightHeader:SetPoint("TOPLEFT")
    rightHeader:SetPoint("TOPRIGHT")
    rightHeader:SetHeight(68)
    local tabNames = {
        { "archive", RP.L.RESEARCH },
        { "expeditions", RP.L.SPECIAL_EXPEDITIONS },
        { "achievements", RP.L.ACHIEVEMENTS },
        { "journal", RP.L.JOURNAL },
        { "about", RP.L.ABOUT_ADDON },
    }
    local previous
    for i = 1, #tabNames do
        local key, label = tabNames[i][1], tabNames[i][2]
        local tab = CreateFrame("Button", nil, rightHeader)
        tab.text = tab:CreateFontString(nil, "OVERLAY", "QuestFont")
        tab.text:SetText(label)
        tab.text:SetPoint("CENTER")
        tab:SetSize(tab.text:GetStringWidth() + 22, 30)
        RP.Theme:ApplyTab(tab)
        if previous then tab:SetPoint("LEFT", previous, "RIGHT", 6, 0)
        else tab:SetPoint("BOTTOMLEFT", 24, 12) end
        function tab:SetAccent(selected)
            self.selected = selected and true or false
            self:SetRelicState(self.selected and "selected" or "normal", true)
            self.text:SetTextColor(self.selected and 1 or 0.88, self.selected and 1 or 0.70, self.selected and 1 or 0.22)
        end
        tab:SetScript("OnEnter", function(self) self.text:SetTextColor(1, 0.88, 0.34) end)
        tab:SetScript("OnLeave", function(self) self:SetAccent(self.selected) end)
        tab:SetScript("OnClick", function() self:ShowPage(key) end)
        tab:SetAccent(false)
        self.tabs[key] = tab
        previous = tab
    end
    frame.location = rightHeader:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.location:SetPoint("TOPRIGHT", -66, -2)
    frame.location:SetWidth(270)
    frame.location:SetHeight(22)
    frame.location:SetJustifyH("RIGHT")
    frame.location:SetJustifyV("TOP")
    local headerDivider = RP.Widgets:CreateMajorDivider(rightSection)
    headerDivider:SetPoint("LEFT", rightHeader, "BOTTOMLEFT", 28, 0)
    headerDivider:SetPoint("RIGHT", rightHeader, "BOTTOMRIGHT", -30, 0)

    frame.expedition = RP.Widgets:CreateButton(rightSection, RP.L.START_DIGGING, 230, 34)
    frame.expedition:SetAccent(true)
    frame.expedition:SetPoint("BOTTOM", 0, 18)
    frame.expedition:SetScript("OnClick", function()
        if RP.db.expedition.active then frame:Hide(); RP.SiteTracker:SetShownByUser(true)
        else RP.Expedition:Start() end
    end)

    local pageHolder = CreateFrame("Frame", nil, rightSection)
    pageHolder:SetPoint("TOPLEFT", 20, -70)
    pageHolder:SetPoint("BOTTOMRIGHT", -20, 62)
    self.pageHolder = pageHolder
    self.frame = frame
    self:CreateProjectsPage()
    self.pages.expeditions = RP.ExpeditionsPage:Create(pageHolder)
    self.pages.achievements = RP.AchievementsPage:Create(pageHolder)
    self:CreateSitesPage()
    self:CreateRacesPage()
    self:CreateArchivePage()
    self:CreateJournalPage()
    self:CreateAboutPage()
    self:LayoutTabs()
    frame.scaleGrip = RP.Widgets:CreateScaleGrip(frame, 0.40, 1.35,
        function() return RP.db.settings.mainScale or 1 end,
        function(value)
            RP.db.settings.mainScale = value
            self:ApplySettings()
            if RP.Settings then RP.Settings:RefreshPanel() end
        end)
    self:RestorePosition()
    self:ApplySettings()
    self:ShowPage("archive")
    frame:Hide()

    RP:On("DIG_SITES_UPDATED", self, self.Refresh)
    RP:On("ARCHAEOLOGY_UPDATED", self, self.OnArchaeologyUpdated)
    RP:On("TARGET_CHANGED", self, self.Refresh)
    RP:On("EXPEDITION_CHANGED", self, self.Refresh)
    RP:On("ROUTE_SETTINGS_CHANGED", self, self.Refresh)
end

function MainFrame:LayoutTabs()
    local keys = {"archive", "expeditions", "achievements", "journal", "about"}
    local total = 0
    for _, key in ipairs(keys) do total = total + self.tabs[key].text:GetStringWidth() + 22 end
    local factor = math.min(1, 680 / (total + 24))
    for _, key in ipairs(keys) do
        local tab = self.tabs[key]
        tab:SetScale(factor)
        tab:SetWidth(tab.text:GetStringWidth() + 22)
    end
end

function MainFrame:CreateAboutPage()
    local page = CreateFrame("Frame", nil, self.pageHolder)
    page:SetAllPoints()
    AddPageTitle(page, "Planet of Archaeology", "by Planet of Warcraft")
    local version = page:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    version:SetPoint("TOPRIGHT", -24, -16)
    version:SetText("v" .. RP.version)
    local description = page:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    description:SetPoint("TOPLEFT", 14, -64)
    description:SetWidth(640)
    description:SetJustifyH("LEFT")
    description:SetWordWrap(true)
    description:SetText(RP.L.ABOUT_DESCRIPTION)
    local link = CreateFrame("EditBox", nil, page, "InputBoxTemplate")
    link:SetSize(610, 30)
    link:SetPoint("TOPLEFT", 20, -362)
    link:SetAutoFocus(false)
    local url = "https://www.youtube.com/@PlanetOfWarcraft"
    link:SetText(url)
    link:SetScript("OnEditFocusGained", function(box) box:HighlightText() end)
    link:SetScript("OnTextChanged", function(box) if box:GetText() ~= url then box:SetText(url) end end)
    link:SetScript("OnEscapePressed", function(box) box:ClearFocus() end)
    link:SetScript("OnEnterPressed", function(box) box:ClearFocus() end)
    link:SetScript("OnHide", function(box) box:ClearFocus() end)
    local hint = page:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", 14, -402)
    hint:SetWidth(640); hint:SetJustifyH("LEFT"); hint:SetWordWrap(true)
    hint:SetText(RP.L.COPY_CHANNEL_LINK)
    local channel = RP.Widgets:CreateButton(page, "YouTube — Planet of Warcraft", 310, 30)
    channel:SetPoint("TOPLEFT", 14, -322)
    channel:SetScript("OnClick", function() link:SetFocus(); link:HighlightText() end)
    local controls = {
        {"Interface\\Icons\\Trade_Archaeology", RP.L.HELP_MINIMAP},
        {"Interface\\Icons\\INV_Misc_Map_01", RP.L.HELP_ROUTE},
        {"Interface\\Icons\\INV_Misc_Shovel_01", RP.L.HELP_WINDOWS},
    }
    for i, entry in ipairs(controls) do
        local icon = page:CreateTexture(nil, "ARTWORK")
        icon:SetSize(32, 32)
        icon:SetPoint("TOPLEFT", 16, -124 - (i - 1) * 62)
        icon:SetTexture(entry[1])
        local text = page:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        text:SetPoint("TOPLEFT", 60, -124 - (i - 1) * 62)
        text:SetWidth(580)
        text:SetJustifyH("LEFT"); text:SetWordWrap(true)
        text:SetText(entry[2])
    end
    self.pages.about = page
end

function MainFrame:ApplySettings()
    if not self.frame then return end
    local wanted = (RP.db.settings.mainScale or 1) * (RP.db.settings.uiScale or 1)
    self.frame:SetScale(RP.Widgets:FitMainScale(RP.Widgets:GetPixelPerfectScale(wanted)))
    self.frame:SetAlpha(RP.db.settings.uiOpacity or 1)
    self:ApplyCompactMode()
end

function MainFrame:ApplyCompactMode()
    local frame = self.frame
    local minimal = RP.db.settings.minimalMain and true or false
    if self.compactButton then self.compactButton:SetExpanded(not minimal) end
    if self.appliedMinimal == minimal then return end
    self.appliedMinimal = minimal
    local left, top = frame:GetLeft(), frame:GetTop()
    frame.leftSection:SetShown(not minimal)
    frame.rightSection:ClearAllPoints()
    frame.rightSection:SetPoint("TOPLEFT", frame, "TOPLEFT", minimal and 0 or 298, 0)
    frame:SetWidth(minimal and 752 or 1050)
    if left and top then
        frame:ClearAllPoints()
        frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
    end
end

function MainFrame:CreateSitesPage()
    local page = CreateFrame("Frame", nil, self.pageHolder)
    page:SetAllPoints()
    AddPageTitle(page, RP.L.DIG_SITES, RP.L.RACE_DISCOVERY_NOTE)

    page.routeMode = RP.Widgets:CreateButton(page, "", 244, 30)
    page.routeMode:SetPoint("TOPLEFT", 14, -56)
    page.routeMode:SetScript("OnClick", function()
        RP.db.settings.routeMode = RP.db.settings.routeMode == "NEAREST" and "PRIORITY" or "NEAREST"
        RP:Fire("ROUTE_SETTINGS_CHANGED")
    end)
    page.filterMode = RP.Widgets:CreateButton(page, "", 244, 30)
    page.filterMode:SetPoint("LEFT", page.routeMode, "RIGHT", 8, 0)
    page.filterMode:SetScript("OnClick", function()
        RP.db.settings.raceFilter = RP.db.settings.raceFilter == "STRICT" and "PREFER" or "STRICT"
        RP:Fire("ROUTE_SETTINGS_CHANGED")
    end)

    page.scroll, page.child = CreateScrollArea(page, -101, 4)
    page.rows = {}
    page.empty = page.child:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    page.empty:SetPoint("TOP", 0, -42)
    page.empty:SetText(RP.L.NO_MATCHING)
    self.pages.sites = page
end

function MainFrame:CreateSiteRow(parent, index)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    local column = (index - 1) % 2
    local line = math.floor((index - 1) / 2)
    row:SetSize(338, 82)
    row:SetPoint("TOPLEFT", column * 346, -line * 88)
    row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    RP.Widgets:ApplyRelicCard(row, 0.90, 0.72)
    row.icon = row:CreateTexture(nil, "ARTWORK", nil, 2)
    row.icon:SetSize(52, 52)
    row.icon:SetPoint("LEFT", 13, 0)
    row.icon:SetTexture("Interface\\Icons\\Trade_Archaeology")
    row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("TOPLEFT", 76, -15)
    row.nameText:SetWidth(218)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(true)
    row.nameText:SetMaxLines(2)
    row.raceText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.raceText:SetPoint("BOTTOMLEFT", 76, 14)
    row.raceText:SetWidth(148)
    row.raceText:SetWordWrap(false)
    row.distanceText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.distanceText:SetPoint("BOTTOMRIGHT", -14, 13)
    row.ribbon = RP.Widgets:CreateSelectionRibbon(row)
    row.ribbon:SetPoint("TOPRIGHT", -12, -10)
    row:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(self.site.name or RP.L.UNKNOWN)
        GameTooltip:AddLine(RP.Localization:DisplayName(self.site.raceName) or RP.L.UNKNOWN_RACE, 0.84, 0.68, 0.35)
        GameTooltip:AddLine(RP:FormatDistance(self.site.distance), 1, 1, 1)
        GameTooltip:AddLine(RP.L.CLICK_DESTINATION, 0.5, 0.8, 0.5)
        GameTooltip:AddLine(RP.L.RIGHT_CLICK, 0.55, 0.55, 0.55)
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    row:SetScript("OnClick", function(self, button)
        if button == "LeftButton" then
            RP.RoutePlanner:SelectManual(self.site.researchSiteID)
            MainFrame:ShowPage("sites")
            if RP.db.expedition.active then RP.HUD:Show() end
        else
            MainFrame:OpenSiteMenu(self)
        end
    end)
    return row
end

function MainFrame:OpenSiteMenu(row)
    if not MenuUtil or not MenuUtil.CreateContextMenu then
        local key = tostring(row.site.researchSiteID)
        RP.db.blacklistedSites[key] = not RP.db.blacklistedSites[key] or nil
        self:Refresh()
        return
    end
    MenuUtil.CreateContextMenu(row, function(_, root)
        root:CreateTitle(row.site.name or RP.L.UNKNOWN)
        root:CreateButton(RP.L.SET_DESTINATION, function() RP.RoutePlanner:SelectManual(row.site.researchSiteID) end)
        local key = tostring(row.site.researchSiteID)
        root:CreateButton(RP.db.blacklistedSites[key] and RP.L.UNIGNORE_SITE or RP.L.IGNORE_SITE, function()
            RP.db.blacklistedSites[key] = RP.db.blacklistedSites[key] and nil or true
            RP:Fire("ROUTE_SETTINGS_CHANGED")
        end)
        if row.site.raceIndex then
            root:CreateButton(RP.L.PRIORITIZE_RACE, function() RP.Archaeology:SetHighestPriority(row.site.raceIndex) end)
        end
    end)
end

function MainFrame:CreateRacesPage()
    local page = CreateFrame("Frame", nil, self.pageHolder)
    page:SetAllPoints()
    AddPageTitle(page, RP.L.RACES, RP.L.SHIFT_PRIORITY .. "  •  " .. RP.L.STRICT_NOTE)
    local scroll, child = CreateScrollArea(page, -62, 3)
    page.scroll, page.child, page.cards = scroll, child, {}
    self.pages.races = page
end

function MainFrame:CreateProjectsPage()
    local page = CreateFrame("Frame", nil, self.pageHolder)
    page:SetAllPoints()
    page.title, page.note = AddPageTitle(page, RP.L.PROJECTS, RP.L.PROJECTS_HINT)

    local detail = CreateFrame("Frame", nil, page, "BackdropTemplate")
    detail:SetPoint("TOPLEFT", 14, -48)
    detail:SetPoint("TOPRIGHT", -14, -48)
    detail:SetHeight(390)
    RP.Widgets:ApplyRelicPanel(detail, 0.66)

    detail.raceIcon = detail:CreateTexture(nil, "ARTWORK", nil, 2)
    detail.raceIcon:SetSize(38, 38)
    detail.raceIcon:SetPoint("TOPLEFT", 20, -14)
    detail.raceIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    detail.raceName = detail:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    detail.raceName:SetPoint("TOPLEFT", 70, -22)
    detail.raceName:SetPoint("RIGHT", -24, 0)
    detail.raceName:SetJustifyH("LEFT")
    detail.raceName:SetTextColor(1, 0.80, 0.24)
    detail.raceHint = detail:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    detail.raceHint:SetPoint("TOPLEFT", detail.raceName, "BOTTOMLEFT", 0, -5)
    detail.raceHint:SetText("")

    detail.history = CreateFrame("ScrollFrame", nil, detail)
    detail.history:SetPoint("TOPLEFT", 24, -60)
    detail.history:SetPoint("TOPRIGHT", -24, -60)
    detail.history:SetHeight(68)
    detail.history:EnableMouseWheel(true)
    local historyChild = CreateFrame("Frame", nil, detail.history)
    historyChild:SetSize(610, 1)
    detail.history:SetScrollChild(historyChild)
    detail.historyText = historyChild:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    detail.historyText:SetPoint("TOPLEFT")
    detail.historyText:SetPoint("TOPRIGHT")
    detail.historyText:SetJustifyH("LEFT")
    detail.historyText:SetWordWrap(true)
    detail.historyText:SetTextColor(0.79, 0.75, 0.65)
    detail.historyChild = historyChild
    detail.history:SetScript("OnSizeChanged", function(_, width)
        historyChild:SetWidth(width)
        historyChild:SetHeight(math.max(1, detail.historyText:GetStringHeight()))
    end)
    detail.history:SetScript("OnMouseWheel", function(scroll, delta)
        scroll:SetVerticalScroll(math.max(0, math.min(math.max(0, historyChild:GetHeight() - scroll:GetHeight()), scroll:GetVerticalScroll() - delta * 24)))
    end)

    detail.artifactFrame = CreateFrame("Frame", nil, detail)
    detail.artifactFrame:SetSize(80, 80)
    detail.artifactFrame:SetPoint("TOPLEFT", 24, -146)
    detail.artifactFrame:EnableMouse(true)
    RP.Theme:ApplyIconBorder(detail.artifactFrame, "normal")
    detail.artifactIcon = detail.artifactFrame:CreateTexture(nil, "ARTWORK")
    detail.artifactIcon:SetPoint("TOPLEFT", 6, -6)
    detail.artifactIcon:SetPoint("BOTTOMRIGHT", -6, 6)
    detail.artifactIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    detail.artifactName = detail:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    detail.artifactName:SetPoint("TOPLEFT", 122, -150)
    detail.artifactName:SetPoint("RIGHT", -26, 0)
    detail.artifactName:SetJustifyH("LEFT")
    detail.artifactName:SetWordWrap(true)
    detail.artifactName:SetMaxLines(2)
    detail.meta = detail:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    detail.meta:SetPoint("TOPLEFT", detail.artifactName, "BOTTOMLEFT", 0, -7)
    detail.meta:SetPoint("RIGHT", -26, 0)
    detail.meta:SetJustifyH("LEFT")
    detail.description = detail:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    detail.description:SetPoint("TOPLEFT", detail.meta, "BOTTOMLEFT", 0, -8)
    detail.description:SetPoint("RIGHT", -28, 0)
    detail.description:SetHeight(36)
    detail.description:SetJustifyH("LEFT")
    detail.description:SetJustifyV("TOP")
    detail.description:SetWordWrap(true)

    local divider = RP.Widgets:CreateMajorDivider(detail)
    divider:SetPoint("LEFT", 28, 0)
    divider:SetPoint("RIGHT", -28, 0)
    divider:SetPoint("TOP", 0, -235)

    detail.progressLabel = detail:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    detail.progressLabel:SetPoint("TOPLEFT", 24, -257)
    detail.progressLabel:SetText(RP.L.FRAGMENTS)
    detail.progressText = detail:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    detail.progressText:SetPoint("TOPRIGHT", -24, -257)
    detail.progressText:SetJustifyH("RIGHT")
    detail.progress = RP.Widgets:CreateProgress(detail, 594, 10)
    detail.progress:SetPoint("TOPLEFT", 24, -280)
    detail.progress:SetPoint("TOPRIGHT", -24, -280)
    detail.restoreProgress = RP.AssemblyProgress:CreateDisplay(detail)
    detail.restoreProgress:ClearAllPoints()
    detail.restoreProgress:SetPoint("BOTTOMLEFT", 24, 62)
    detail.restoreProgress:SetPoint("BOTTOMRIGHT", -24, 62)

    detail.keystone = RP.Widgets:CreateButton(detail, "", 280, 30)
    detail.keystone:SetPoint("BOTTOMLEFT", 24, 18)
    detail.keystone:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    detail.keystone:SetScript("OnClick", function(_, button)
        local state = page.projectState
        if not state or not state.race then return end
        if RP.Archaeology:ToggleKeystone(state.race.index, button == "RightButton") then
            RP.Archaeology:Refresh()
            self:Refresh()
        end
    end)
    detail.keystone:HookScript("OnEnter", function(button)
        local state = page.projectState
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        if state and state.race.keystoneItemID and GameTooltip.SetItemByID then
            GameTooltip:SetItemByID(state.race.keystoneItemID)
        else
            GameTooltip:SetText(RP.L.KEYSTONES)
        end
        if state then
            GameTooltip:AddLine(RP.L.KEYSTONE_STATUS:format(state.socketed or 0, state.sockets or 0, state.race.keystones or 0), 1, 0.82, 0.35)
            if (state.sockets or 0) > 0 then
                GameTooltip:AddLine(RP.L.KEYSTONE_ADD, 0.40, 0.90, 0.45)
                GameTooltip:AddLine(RP.L.KEYSTONE_REMOVE, 0.72, 0.72, 0.72)
            end
        end
        GameTooltip:Show()
    end)
    detail.keystone:HookScript("OnLeave", GameTooltip_Hide)

    detail.solve = RP.Widgets:CreateButton(detail, RP.L.SOLVE, 196, 34)
    detail.solve:SetPoint("BOTTOMRIGHT", -24, 16)
    detail.solve:SetScript("OnClick", function()
        local state = page.projectState
        if not state or not state.race then return end
        if not state.canSolve then
            local _, localRaces = RP.Archaeology:GetPossibleRaces()
            for _, race in ipairs(localRaces) do RP.db.selectedRaces[tostring(race.index)] = nil end
            RP.db.selectedRaces[tostring(state.race.index)] = true
            RP:Fire("ROUTE_SETTINGS_CHANGED")
            if not RP.db.expedition.active then RP.Expedition:Start(); RP.RoutePlanner:SelectNext()
            else RP.RoutePlanner:SelectNext(); self.frame:Hide(); RP.SiteTracker:SetShownByUser(true) end
            return
        end
        if RP.Archaeology:Solve(state.race.index) then
            C_Timer.After(0.25, function()
                RP.Archaeology:Refresh()
                self:Refresh()
            end)
        end
    end)
    detail.artifactFrame:SetScript("OnEnter", function(iconFrame)
        local state = page.projectState
        GameTooltip:SetOwner(iconFrame, "ANCHOR_RIGHT")
        GameTooltip:SetText(state and state.artifact and RP.Localization:DisplayName(state.artifact.name) or RP.L.CURRENT_ARTIFACT)
        if state and state.artifact and state.artifact.description and state.artifact.description ~= "" then
            GameTooltip:AddLine(state.artifact.description, 1, 1, 1, true)
        end
        GameTooltip:Show()
    end)
    detail.artifactFrame:SetScript("OnLeave", GameTooltip_Hide)

    page.empty = detail:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    page.empty:SetPoint("CENTER")
    page.empty:SetWidth(620)
    page.empty:SetJustifyH("CENTER")
    page.empty:SetText(RP.L.NO_PROJECTS)
    page.empty:Hide()
    page.detail = detail
    self.pages.projects = page
end

function MainFrame:CreateProjectRaceRow(parent, index)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    local column = (index - 1) % 2
    local line = math.floor((index - 1) / 2)
    row:SetSize(127, 56)
    row:SetPoint("TOPLEFT", column * 133, -line * 62)
    RP.Widgets:ApplyRelicCard(row, 0.92, 0.72)
    row.icon = row:CreateTexture(nil, "ARTWORK", nil, 2)
    row.icon:SetSize(38, 44)
    row.icon:SetPoint("LEFT", row, "LEFT", 6, 0)
    -- Race artwork occupies only the top-left region of Blizzard's texture.
    row.icon:SetTexCoord(0, 0.5703, 0, 0.6484)
    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.nameText:SetPoint("TOPLEFT", 50, -9)
    row.nameText:SetPoint("RIGHT", -8, 0)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(false)
    row.progressText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.progressText:SetPoint("BOTTOMLEFT", 50, 9)
    row.progressText:SetPoint("RIGHT", -8, 0)
    row.progressText:SetJustifyH("LEFT")
    row.ready = row:CreateTexture(nil, "OVERLAY", nil, 3)
    row.ready:SetTexture("Interface\\Buttons\\WHITE8X8")
    row.ready:SetSize(7, 7)
    row.ready:SetPoint("TOPRIGHT", -8, -8)
    row.ready:SetRotation(math.rad(45))
    row:SetScript("OnClick", function(button)
        self.projectRaceFilter = button.raceIndex
        self:ShowPage("projects")
    end)
    row:HookScript("OnEnter", function(button)
        if not button.projectState then return end
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        GameTooltip:SetText(RP.Localization:DisplayName(button.projectState.race.name) or RP.L.UNKNOWN_RACE)
        GameTooltip:AddLine(RP.Localization:DisplayName(button.projectState.artifact.name) or RP.L.CURRENT_ARTIFACT, 1, 0.82, 0.30)
        GameTooltip:AddLine(RP.L.ARTIFACT_PROGRESS:format(button.projectState.base or 0, button.projectState.adjusted or 0, button.projectState.required or 0), 0.82, 0.82, 0.82)
        GameTooltip:Show()
    end)
    row:HookScript("OnLeave", function() GameTooltip:Hide() end)
    return row
end

function MainFrame:CreateRaceCard(parent, index)
    local card = CreateFrame("Button", nil, parent, "BackdropTemplate")
    card:SetSize(168, 58)
    card:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    local col, row = (index - 1) % 4, math.floor((index - 1) / 4)
    card:SetPoint("TOPLEFT", col * 174, -row * 64)
    RP.Widgets:ApplyRelicCard(card, 0.90, 0.70)
    card.icon = card:CreateTexture(nil, "ARTWORK")
    card.icon:SetSize(34, 34)
    card.icon:SetPoint("LEFT", 10, 0)
    card.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    card.nameText = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    card.nameText:SetPoint("TOPLEFT", 52, -8)
    card.nameText:SetPoint("RIGHT", -17, 0)
    card.nameText:SetJustifyH("LEFT")
    card.nameText:SetWordWrap(false)
    card.fragments = card:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    card.fragments:SetPoint("TOPLEFT", card.nameText, "BOTTOMLEFT", 0, -3)
    card.bar = RP.Widgets:CreateProgress(card, 104, 5)
    card.bar:SetPoint("BOTTOMLEFT", 52, 8)
    card.indicator = card:CreateTexture(nil, "OVERLAY", nil, 2)
    card.indicator:SetTexture("Interface\\Buttons\\WHITE8X8")
    card.indicator:SetSize(7, 7)
    card.indicator:SetPoint("RIGHT", -9, 1)
    card.indicator:SetRotation(math.rad(45))
    card.indicator:Hide()
    card:SetScript("OnClick", function(self, button)
        if button == "RightButton" then
            local key = tostring(self.race.index)
            RP.db.blacklistedRaces[key] = RP.db.blacklistedRaces[key] and nil or true
            RP:Fire("ROUTE_SETTINGS_CHANGED")
        elseif IsShiftKeyDown() then
            RP.Archaeology:SetHighestPriority(self.race.index)
        else
            RP.Archaeology:ToggleSelected(self.race.index)
        end
    end)
    card:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(RP.Localization:DisplayName(self.race.name))
        local selected = RP.db.selectedRaces[tostring(self.race.index)]
        GameTooltip:AddLine(selected and RP.L.SELECTED or RP.L.NOT_SELECTED, selected and 0.3 or 0.7, selected and 1 or 0.7, 0.3)
        GameTooltip:AddLine(RP.L.SHIFT_PRIORITY, 0.6, 0.6, 0.6)
        GameTooltip:AddLine(RP.L.IGNORE_RACE, 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    card:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return card
end

function MainFrame:CreateArchivePage()
    local page = CreateFrame("Frame", nil, self.pageHolder)
    page:SetAllPoints()
    page.filter = "ALL"
    page.raceFilter = nil
    page.rows = {}
    page.raceRows = {}
    page.title, page.note = AddPageTitle(page, RP.L.RESEARCH, RP.L.ARCHIVE_HINT)

    page.all = RP.Widgets:CreateButton(page, RP.L.ARCHIVE_ALL, 112, 28)
    page.all:SetPoint("TOPLEFT", 12, -53)
    page.obtained = RP.Widgets:CreateButton(page, RP.L.ARCHIVE_OBTAINED, 112, 28)
    page.obtained:SetPoint("LEFT", page.all, "RIGHT", 6, 0)
    page.missing = RP.Widgets:CreateButton(page, RP.L.ARCHIVE_MISSING, 112, 28)
    page.missing:SetPoint("LEFT", page.obtained, "RIGHT", 6, 0)
    page.all:SetScript("OnClick", function() self:SetArchiveFilter("ALL") end)
    page.obtained:SetScript("OnClick", function() self:SetArchiveFilter("OBTAINED") end)
    page.missing:SetScript("OnClick", function() self:SetArchiveFilter("MISSING") end)
    page.counter = page:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    page.counter:SetPoint("TOPRIGHT", -12, -61)
    page.counter:SetJustifyH("RIGHT")

    local raceInset = CreateFrame("Frame", nil, page, "BackdropTemplate")
    raceInset:SetPoint("TOPLEFT", 8, -91)
    raceInset:SetPoint("BOTTOMLEFT", 8, 4)
    raceInset:SetWidth(188)
    RP.Widgets:ApplyRelicPanel(raceInset, 0.58)
    local raceScroll = CreateFrame("ScrollFrame", nil, raceInset)
    raceScroll:SetPoint("TOPLEFT", 7, -8)
    raceScroll:SetPoint("BOTTOMRIGHT", -9, 8)
    raceScroll:EnableMouseWheel(true)
    local raceChild = CreateFrame("Frame", nil, raceScroll)
    raceChild:SetSize(170, 1)
    raceScroll:SetScrollChild(raceChild)
    raceScroll:SetScript("OnMouseWheel", function(scrollFrame, delta)
        local range = scrollFrame:GetVerticalScrollRange()
        scrollFrame:SetVerticalScroll(math.max(0, math.min(range, scrollFrame:GetVerticalScroll() - delta * 38)))
    end)
    page.raceScroll, page.raceChild = raceScroll, raceChild

    local listInset = CreateFrame("Frame", nil, page, "BackdropTemplate")
    listInset:SetPoint("TOPLEFT", raceInset, "TOPRIGHT", 8, 0)
    listInset:SetPoint("BOTTOMLEFT", raceInset, "BOTTOMRIGHT", 8, 0)
    listInset:SetWidth(244)
    RP.Widgets:ApplyRelicPanel(listInset, 0.58)
    local scroll = CreateFrame("ScrollFrame", nil, listInset)
    scroll:SetPoint("TOPLEFT", 8, -8)
    scroll:SetPoint("BOTTOMRIGHT", -10, 8)
    scroll:EnableMouseWheel(true)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(226, 1)
    scroll:SetScrollChild(child)
    scroll.contentHeight = 1
    scroll.maxScroll = 0
    scroll:SetScript("OnMouseWheel", function(scrollFrame, delta)
        local range = scrollFrame.maxScroll or 0
        local nextOffset = math.max(0, math.min(range, scrollFrame:GetVerticalScroll() - delta * 52))
        scrollFrame:SetVerticalScroll(nextOffset)
        self:RefreshArchiveVisibleRows()
    end)
    page.scroll, page.child = scroll, child

    local detail = CreateFrame("Frame", nil, page, "BackdropTemplate")
    detail:SetPoint("TOPLEFT", listInset, "TOPRIGHT", 8, 0)
    detail:SetPoint("BOTTOMRIGHT", -8, 4)
    RP.Widgets:ApplyRelicPanel(detail, 0.64)
    detail.bg = detail:CreateTexture(nil, "BACKGROUND")
    detail.bg:SetPoint("TOPLEFT", 3, -3)
    detail.bg:SetPoint("BOTTOMRIGHT", -3, 3)
    detail.bg:SetAlpha(0.12)
    detail.iconFrame = CreateFrame("Frame", nil, detail, "BackdropTemplate")
    detail.iconFrame:SetSize(72, 72)
    detail.iconFrame:SetPoint("TOPLEFT", 14, -15)
    RP.Theme:ApplyIconBorder(detail.iconFrame, "normal")
    detail.iconFrame:EnableMouse(true)
    detail.iconFrame:SetScript("OnEnter", function(iconFrame)
        local artifact = page.selectedArtifact
        if not artifact then return end
        GameTooltip:SetOwner(iconFrame, "ANCHOR_RIGHT")
        if artifact.itemID and GameTooltip.SetItemByID then
            GameTooltip:SetItemByID(artifact.itemID)
        else
            GameTooltip:SetText(RP.Localization:DisplayName(artifact.name) or RP.L.UNKNOWN)
            if artifact.description and artifact.description ~= "" then GameTooltip:AddLine(artifact.description, 1, 1, 1, true) end
        end
        GameTooltip:Show()
    end)
    detail.iconFrame:SetScript("OnLeave", GameTooltip_Hide)
    detail.icon = detail.iconFrame:CreateTexture(nil, "ARTWORK")
    detail.icon:SetPoint("TOPLEFT", 5, -5)
    detail.icon:SetPoint("BOTTOMRIGHT", -5, 5)
    detail.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    detail.nameText = detail:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    detail.nameText:SetPoint("TOPLEFT", 96, -18)
    detail.nameText:SetPoint("TOPRIGHT", -12, -18)
    detail.nameText:SetJustifyH("LEFT")
    detail.nameText:SetWordWrap(true)
    detail.nameText:SetNonSpaceWrap(false)
    detail.wordMeasure = detail:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    detail.wordMeasure:SetWordWrap(false)
    detail.wordMeasure:Hide()
    detail.meta = detail:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    detail.meta:SetPoint("TOPLEFT", detail.nameText, "BOTTOMLEFT", 0, -6)
    detail.meta:SetPoint("TOPRIGHT", detail.nameText, "BOTTOMRIGHT", 0, -6)
    detail.meta:SetJustifyH("LEFT")
    detail.meta:SetWordWrap(true)
    detail.status = detail:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    detail.status:SetPoint("TOPLEFT", detail.meta, "BOTTOMLEFT", 0, -7)
    detail.status:SetPoint("TOPRIGHT", detail.meta, "BOTTOMRIGHT", 0, -7)
    detail.status:SetJustifyH("LEFT")
    detail.status:SetWordWrap(true)
    local rule = RP.Widgets:CreateRule(detail)
    detail.headerRule = rule
    rule:SetPoint("TOPLEFT", 14, -108)
    rule:SetPoint("RIGHT", -14, 0)

    local detailScroll = CreateFrame("ScrollFrame", nil, detail)
    detailScroll:SetPoint("TOPLEFT", 15, -122)
    detailScroll:SetPoint("BOTTOMRIGHT", -16, 15)
    detailScroll:EnableMouseWheel(true)
    local detailChild = CreateFrame("Frame", nil, detailScroll)
    detailChild:SetSize(230, 1)
    detailScroll:SetScrollChild(detailChild)
    detailScroll:SetScript("OnMouseWheel", function(scrollFrame, delta)
        local range = scrollFrame:GetVerticalScrollRange()
        scrollFrame:SetVerticalScroll(math.max(0, math.min(range, scrollFrame:GetVerticalScroll() - delta * 42)))
    end)
    detail.description = detailChild:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    detail.description:SetPoint("TOPLEFT", 4, -4)
    detail.description:SetWidth(220)
    detail.description:SetJustifyH("LEFT")
    detail.description:SetJustifyV("TOP")
    detail.description:SetWordWrap(true)
    detail.completion = detailChild:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    detail.completion:SetPoint("TOPLEFT", detail.description, "BOTTOMLEFT", 0, -18)
    detail.completion:SetWidth(220)
    detail.completion:SetJustifyH("LEFT")
    detail.completion:SetWordWrap(true)
    detail.price = detailChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    detail.price:SetPoint("TOPLEFT", detail.completion, "BOTTOMLEFT", 0, -12)
    detail.price:SetWidth(220)
    detail.price:SetJustifyH("LEFT")
    detail.price:SetTextColor(1, 0.82, 0.28)
    page.raceInset, page.listInset = raceInset, listInset
    page.detail, page.detailScroll, page.detailChild = detail, detailScroll, detailChild
    self.pages.archive = page
end

function MainFrame:CreateArchiveRow(parent, index)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    row:SetSize(226, 64)
    row:SetPoint("TOPLEFT", 0, -(index - 1) * 68)
    RP.Widgets:ApplyRelicCard(row, 0.92, 0.62)
    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetSize(42, 42)
    row.icon:SetPoint("LEFT", 10, 0)
    row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    RP.Widgets:AddIconRing(row.icon, 42)
    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("TOPLEFT", 61, -12)
    row.nameText:SetWidth(124)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(false)
    row.subText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.subText:SetPoint("BOTTOMLEFT", 61, 12)
    row.subText:SetWidth(124)
    row.subText:SetJustifyH("LEFT")
    row.subText:SetWordWrap(false)
    row.statusMarker = RP.Widgets:CreateStatusMarker(row, "completed")
    row.statusMarker:SetPoint("RIGHT", -10, 0)
    row.statusMarker:Hide()
    row:SetScript("OnClick", function(button) self:SelectArchiveArtifact(button.artifact) end)
    row:SetScript("OnEnter", function(button)
        button.nameText:SetTextColor(1, 0.84, 0.42)
    end)
    row:SetScript("OnLeave", function(button)
        if button.artifact then
            button.nameText:SetTextColor(button.artifact.rarity == 1 and 0.72 or 0.96, button.artifact.rarity == 1 and 0.50 or 0.93, button.artifact.rarity == 1 and 1 or 0.86)
        end
    end)
    return row
end

function MainFrame:CreateArchiveRaceRow(parent, index)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    row:SetSize(170, 54)
    row:SetPoint("TOPLEFT", 0, -(index - 1) * 58)
    RP.Widgets:ApplyRelicCard(row, 0.92, 0.58)
    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetSize(44, 50)
    row.icon:SetPoint("LEFT", 6, 0)
    row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    row.iconGlow = CreateFrame("Frame", nil, row)
    row.iconGlow:SetAllPoints(row.icon)
    row.iconGlow:EnableMouse(false)
    row.iconGlow.layers = {}
    -- Reuse the race texture's alpha silhouette, not a rectangular button glow.
    for _, offset in ipairs({{-1,0},{1,0},{0,-1},{0,1},{-1,-1},{-1,1},{1,-1},{1,1},{0,0}}) do
        local layer = row.iconGlow:CreateTexture(nil, "OVERLAY")
        layer:SetPoint("TOPLEFT", row.icon, "TOPLEFT", offset[1], offset[2])
        layer:SetPoint("BOTTOMRIGHT", row.icon, "BOTTOMRIGHT", offset[1], offset[2])
        layer:SetBlendMode("ADD")
        layer:SetDesaturated(true)
        layer:SetVertexColor(1, 0.78, 0.32)
        layer:SetAlpha(offset[1] == 0 and offset[2] == 0 and 0.22 or 0.12)
        row.iconGlow.layers[#row.iconGlow.layers + 1] = layer
    end
    row.iconGlow:SetAlpha(0)
    function row:SetRaceArtwork(texture, isRace)
        texture = texture or "Interface\\Icons\\Trade_Archaeology"
        -- Blizzard's ArchaeologyRaceTemplate uses only this part of the sheet.
        local left, right, top, bottom = 0.07, 0.93, 0.07, 0.93
        if isRace then left, right, top, bottom = 0, 0.5703, 0, 0.6484 end
        self.icon:SetSize(44, isRace and 50 or 44)
        self.icon:SetTexture(texture)
        self.icon:SetTexCoord(left, right, top, bottom)
        for _, layer in ipairs(self.iconGlow.layers) do
            layer:SetTexture(texture)
            layer:SetTexCoord(left, right, top, bottom)
        end
    end
    function row:UpdateIconHighlight()
        local target = self.iconSelected and 0.85 or (self.iconHovered and 0.48 or 0)
        self:SetScript("OnUpdate", function(button, elapsed)
            local alpha = button.iconGlow:GetAlpha()
            alpha = alpha + (target - alpha) * (1 - math.exp(-20 * elapsed))
            if math.abs(target - alpha) < 0.005 then
                alpha = target
                button:SetScript("OnUpdate", nil)
            end
            button.iconGlow:SetAlpha(alpha)
        end)
    end
    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.nameText:SetPoint("TOPLEFT", 54, -11)
    row.nameText:SetWidth(107)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(false)
    row.countText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.countText:SetPoint("BOTTOMLEFT", 54, 10)
    row.countText:SetWidth(107)
    row.countText:SetJustifyH("LEFT")
    row:SetScript("OnClick", function(button) self:SetArchiveRace(button.raceIndex) end)
    row:SetScript("OnEnter", function(button)
        button.iconHovered = true
        button:UpdateIconHighlight()
        if button.fullName then
            GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
            GameTooltip:SetText(button.fullName)
            GameTooltip:AddLine(button.countText:GetText() or "", 0.78, 0.70, 0.55)
            GameTooltip:Show()
        end
    end)
    row:SetScript("OnLeave", function(button)
        button.iconHovered = nil
        button:UpdateIconHighlight()
        GameTooltip:Hide()
    end)
    row:SetScript("OnHide", function(button)
        button.iconHovered = nil
        button:SetScript("OnUpdate", nil)
        button.iconGlow:SetAlpha(button.iconSelected and 0.85 or 0)
    end)
    return row
end

function MainFrame:CreateProjectRow(parent, index)
    local row = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    row:SetSize(690, 64)
    row:SetPoint("TOPLEFT", 2, -(index - 1) * 68)
    RP.Widgets:ApplyRelicCard(row, 0.92, 0.66)

    row.raceIcon = row:CreateTexture(nil, "ARTWORK", nil, 2)
    row.raceIcon:SetSize(38, 38)
    row.raceIcon:SetPoint("LEFT", 12, 0)
    row.raceIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    row.artifactFrame = CreateFrame("Frame", nil, row)
    row.artifactFrame:SetSize(42, 42)
    row.artifactFrame:SetPoint("LEFT", 60, 0)
    row.artifactFrame:EnableMouse(true)
    RP.Theme:ApplyIconBorder(row.artifactFrame, "normal")
    row.artifactIcon = row.artifactFrame:CreateTexture(nil, "ARTWORK")
    row.artifactIcon:SetPoint("TOPLEFT", 4, -4)
    row.artifactIcon:SetPoint("BOTTOMRIGHT", -4, 4)
    row.artifactIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("TOPLEFT", 116, -8)
    row.nameText:SetWidth(330)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(false)
    row.raceText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.raceText:SetPoint("TOPLEFT", row.nameText, "BOTTOMLEFT", 0, -2)
    row.raceText:SetWidth(330)
    row.raceText:SetJustifyH("LEFT")
    row.progressText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.progressText:SetPoint("BOTTOMLEFT", 116, 16)
    row.progressText:SetWidth(326)
    row.progressText:SetJustifyH("LEFT")
    row.progress = RP.Widgets:CreateProgress(row, 326, 6)
    row.progress:SetPoint("BOTTOMLEFT", 116, 8)

    row.solve = RP.Widgets:CreateButton(row, RP.L.SOLVE, 96, 26)
    row.solve:SetPoint("RIGHT", -12, 0)
    row.solve:SetScript("OnClick", function()
        local state = row.projectState
        if not state or not state.canSolve or not row.raceIndex then return end
        if RP.Archaeology:Solve(row.raceIndex) then
            C_Timer.After(0.25, function()
                RP.Archaeology:Refresh()
                self:RefreshProjects()
            end)
        end
    end)

    row.keystone = RP.Widgets:CreateButton(row, "", 110, 26)
    row.keystone:SetPoint("RIGHT", row.solve, "LEFT", -8, 0)
    row.keystone:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    row.keystone:SetScript("OnClick", function(_, button)
        if not row.raceIndex then return end
        if RP.Archaeology:ToggleKeystone(row.raceIndex, button == "RightButton") then
            RP.Archaeology:Refresh()
            self:RefreshProjects()
        end
    end)
    row.keystone:HookScript("OnEnter", function(button)
        local state = row.projectState
        GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
        if state and state.race and state.race.keystoneItemID and GameTooltip.SetItemByID then
            GameTooltip:SetItemByID(state.race.keystoneItemID)
        else
            GameTooltip:SetText(RP.L.KEYSTONES)
        end
        if state then
            GameTooltip:AddLine(RP.L.KEYSTONE_STATUS:format(state.socketed or 0, state.sockets or 0, state.race.keystones or 0), 1, 0.82, 0.35)
            if (state.sockets or 0) > 0 then
                GameTooltip:AddLine(RP.L.KEYSTONE_ADD, 0.40, 0.90, 0.45)
                GameTooltip:AddLine(RP.L.KEYSTONE_REMOVE, 0.72, 0.72, 0.72)
            end
        end
        GameTooltip:Show()
    end)
    row.keystone:HookScript("OnLeave", GameTooltip_Hide)
    row.artifactFrame:SetScript("OnEnter", function(iconFrame)
        local state = row.projectState
        GameTooltip:SetOwner(iconFrame, "ANCHOR_RIGHT")
        GameTooltip:SetText(state and state.artifact and RP.Localization:DisplayName(state.artifact.name) or RP.L.CURRENT_ARTIFACT)
        if state and state.artifact and state.artifact.description and state.artifact.description ~= "" then
            GameTooltip:AddLine(state.artifact.description, 1, 1, 1, true)
        end
        GameTooltip:Show()
    end)
    row.artifactFrame:SetScript("OnLeave", GameTooltip_Hide)
    return row
end

function MainFrame:SetArchiveFilter(filter)
    local page = self.pages.archive
    page.filter = filter
    self:RefreshArchive()
end

function MainFrame:SetArchiveRace(raceIndex)
    local page = self.pages.archive
    page.raceFilter = raceIndex
    page.selectedKey = nil
    self:RefreshArchive()
end

function MainFrame:UpdateArtifactPrice(artifact)
    local page = self.pages.archive
    if not page or not page.detail or not page.detail.price then return end
    local detail = page.detail
    detail.price:SetText("")
    if not artifact or not artifact.itemID then return end
    local selectedKey = artifact.key
    local function RefreshPrice()
        if page.selectedKey ~= selectedKey then return end
        local getter = C_Item and C_Item.GetItemInfo or GetItemInfo
        if not getter then return end
        local ok, sellPrice = pcall(function() return select(11, getter(artifact.itemID)) end)
        if ok and type(sellPrice) == "number" and sellPrice > 0 then
            local money = GetMoneyString and GetMoneyString(sellPrice, true)
                or (GetCoinTextureString and GetCoinTextureString(sellPrice))
                or tostring(sellPrice)
            detail.price:SetText(RP.L.ARCHIVE_SELL_PRICE .. ":  " .. money)
            self:UpdateArchiveDetailHeight()
        end
    end
    RefreshPrice()
    if detail.price:GetText() == "" and Item and Item.CreateFromItemID then
        local item = Item:CreateFromItemID(artifact.itemID)
        item:ContinueOnItemLoad(RefreshPrice)
    end
end

function MainFrame:SelectArchiveArtifact(artifact)
    local page = self.pages.archive
    page.selectedArtifact = artifact
    if self.archiveSpellCancel then
        self.archiveSpellCancel()
        self.archiveSpellCancel = nil
    end
    page.selectedKey = artifact and artifact.key or nil
    for i = 1, #page.rows do
        local row = page.rows[i]
        local selected = row:IsShown() and row.artifact and row.artifact.key == page.selectedKey
        local state = selected and "selected" or (row.artifact and row.artifact.obtained and "completed" or "normal")
        row:SetRelicState(state, true)
    end

    local detail = page.detail
    if not artifact then
        detail.icon:SetTexture("Interface\\Icons\\Trade_Archaeology")
        detail.icon:SetDesaturated(true)
        detail.iconFrame:SetRelicState("disabled", true)
        detail.bg:SetTexture(nil)
        detail.nameText:SetText(RP.L.ARCHIVE_EMPTY)
        detail.meta:SetText("")
        detail.status:SetText("")
        detail.description:SetText(RP.L.ARCHIVE_EMPTY_HINT)
        detail.completion:SetText("")
        detail.price:SetText("")
    else
        detail.icon:SetTexture(artifact.icon or "Interface\\Icons\\Trade_Archaeology")
        detail.icon:SetDesaturated(not artifact.obtained)
        detail.iconFrame:SetRelicState(artifact.obtained and "selected" or "disabled", true)
        detail.icon:SetVertexColor(artifact.obtained and 1 or 0.62, artifact.obtained and 1 or 0.62, artifact.obtained and 1 or 0.62)
        detail.bg:SetTexture(artifact.background)
        detail.nameText:SetText(RP.Localization:DisplayName(artifact.name))
        detail.meta:SetText(RP.Localization:DisplayName(artifact.raceName) .. "  •  " .. (artifact.rarity == 1 and RP.L.RARE or RP.L.NORMAL))
        detail.status:SetText(artifact.obtained and RP.L.ARCHIVE_OBTAINED_STATUS or RP.L.ARCHIVE_MISSING_STATUS)
        detail.status:SetTextColor(artifact.obtained and 0.38 or 0.82, artifact.obtained and 0.86 or 0.66, artifact.obtained and 0.46 or 0.38)
        detail.description:SetText(RP.ContentLocalization:Get("artifact", artifact.itemID, artifact.description ~= "" and artifact.description or RP.L.ARCHIVE_NO_DESCRIPTION))
        if artifact.rarity == 0 and artifact.spellID and Spell and Spell.CreateFromSpellID then
            local spell = Spell:CreateFromSpellID(artifact.spellID)
            self.archiveSpellCancel = spell:ContinueWithCancelOnSpellLoad(function()
                if page.selectedKey ~= artifact.key then return end
                local loadedDescription = spell:GetSpellDescription()
                if loadedDescription and loadedDescription ~= "" then
                    detail.description:SetText(RP.ContentLocalization:Get("artifact", artifact.itemID, loadedDescription, true))
                    self:UpdateArchiveDetailHeight()
                end
            end)
        end
        local completion = RP.L.ARCHIVE_NOT_YET
        if artifact.obtained then
            completion = RP.L.ARCHIVE_COMPLETIONS:format(artifact.completionCount)
            if artifact.firstCompletionTime and artifact.firstCompletionTime > 0 then
                local completedDate = date("*t", artifact.firstCompletionTime)
                local formattedDate = FormatShortDate and FormatShortDate(completedDate.day, completedDate.month, completedDate.year)
                    or date("%d.%m.%Y", artifact.firstCompletionTime)
                completion = completion .. "\n" .. RP.L.ARCHIVE_FIRST_COMPLETION:format(formattedDate)
            end
        end
        detail.completion:SetText(completion)
        self:UpdateArtifactPrice(artifact)
    end
    page.detailScroll:SetVerticalScroll(0)
    self:UpdateArchiveDetailHeight()
end

function MainFrame:UpdateArchiveDetailHeight()
    local page = self.pages.archive
    if not page or not page.detailChild then return end
    C_Timer.After(0, function()
        if not page.detailChild then return end
        local detail = page.detail
        local title = detail.nameText
        local besideWidth = math.max(1, detail:GetWidth() - 108)
        local belowIcon = false
        for word in (title:GetText() or ""):gmatch("%S+") do
            detail.wordMeasure:SetText(word)
            if detail.wordMeasure:GetStringWidth() > besideWidth then belowIcon = true; break end
        end
        title:ClearAllPoints()
        title:SetPoint("TOPLEFT", detail, "TOPLEFT", 96, -18)
        title:SetPoint("TOPRIGHT", detail, "TOPRIGHT", -12, -18)
        if title:GetStringHeight() > 72 then belowIcon = true end
        local titleTop = belowIcon and 99 or 18
        if belowIcon then
            title:ClearAllPoints()
            title:SetPoint("TOPLEFT", detail, "TOPLEFT", 14, -titleTop)
            title:SetPoint("TOPRIGHT", detail, "TOPRIGHT", -12, -titleTop)
        end
        -- Reserve the actual wrapped heading height, rather than a fixed 108px.
        local headerBottom = math.max(87, titleTop + detail.nameText:GetStringHeight()
            + 6 + detail.meta:GetStringHeight() + 7 + detail.status:GetStringHeight())
        detail.headerRule:ClearAllPoints()
        detail.headerRule:SetPoint("TOPLEFT", detail, "TOPLEFT", 14, -headerBottom - 14)
        detail.headerRule:SetPoint("TOPRIGHT", detail, "TOPRIGHT", -14, -headerBottom - 14)
        page.detailScroll:ClearAllPoints()
        page.detailScroll:SetPoint("TOPLEFT", detail, "TOPLEFT", 15, -headerBottom - 28)
        page.detailScroll:SetPoint("BOTTOMRIGHT", detail, "BOTTOMRIGHT", -16, 15)
        local width = math.max(1, detail:GetWidth() - 31)
        page.detailChild:SetWidth(width)
        for _, text in ipairs({detail.description, detail.completion, detail.price}) do
            text:SetWidth(math.max(1, width - 8))
        end
        local priceHeight = detail.price:GetText() ~= "" and ((detail.price:GetStringHeight() or 14) + 14) or 0
        local height = (detail.description:GetStringHeight() or 20) + (detail.completion:GetStringHeight() or 14) + priceHeight + 34
        page.detailChild:SetHeight(math.max(1, height))
    end)
end

function MainFrame:CreateJournalPage()
    local page = CreateFrame("Frame", nil, self.pageHolder)
    page:SetAllPoints()
    AddPageTitle(page, RP.L.TODAYS_EXPEDITION, RP.L.SUBTITLE)
    local statsPanel = CreateFrame("Frame", nil, page, "BackdropTemplate")
    statsPanel:SetPoint("TOPLEFT", 14, -64)
    statsPanel:SetSize(330, 176)
    RP.Widgets:ApplyRelicPanel(statsPanel, 0.66)
    local statsTitle = RP.Widgets:CreateCategoryDivider(statsPanel, RP.L.EXPEDITION)
    statsTitle:SetPoint("TOPLEFT", 18, -17)
    statsTitle:SetPoint("TOPRIGHT", -18, -17)
    page.stats = statsPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    page.stats:SetPoint("TOPLEFT", 24, -54)
    page.stats:SetWidth(282)
    page.stats:SetJustifyH("LEFT")
    page.stats:SetJustifyV("TOP")
    local racesPanel = CreateFrame("Frame", nil, page, "BackdropTemplate")
    racesPanel:SetPoint("TOPRIGHT", -14, -64)
    racesPanel:SetSize(330, 176)
    RP.Widgets:ApplyRelicPanel(racesPanel, 0.66)
    local racesTitle = RP.Widgets:CreateCategoryDivider(racesPanel, RP.L.RACES)
    racesTitle:SetPoint("TOPLEFT", 18, -17)
    racesTitle:SetPoint("TOPRIGHT", -18, -17)
    page.races = racesPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    page.races:SetPoint("TOPLEFT", 24, -54)
    page.races:SetWidth(282)
    page.races:SetJustifyH("LEFT")
    page.races:SetJustifyV("TOP")
    local recentPanel = CreateFrame("Frame", nil, page, "BackdropTemplate")
    recentPanel:SetPoint("TOPLEFT", 14, -254)
    recentPanel:SetPoint("BOTTOMRIGHT", -14, 8)
    RP.Widgets:ApplyRelicPanel(recentPanel, 0.66)
    local recentTitle = RP.Widgets:CreateCategoryDivider(recentPanel, RP.L.RECENT_ARTIFACTS)
    recentTitle:SetPoint("TOPLEFT", 18, -17)
    recentTitle:SetPoint("TOPRIGHT", -18, -17)
    page.recent = recentPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    page.recent:SetPoint("TOPLEFT", 24, -54)
    page.recent:SetPoint("BOTTOMRIGHT", -24, 18)
    page.recent:SetJustifyH("LEFT")
    page.recent:SetJustifyV("TOP")
    self.pages.journal = page
end

function MainFrame:ShowPage(key)
    if key == "sites" then
        RP.SiteTracker:SetShownByUser(true)
        self.frame:Hide()
        return
    end
    local changed = self.selectedPage ~= key
    self.selectedPage = key
    for pageKey, page in pairs(self.pages) do page:SetShown(pageKey == key) end
    for tabKey, tab in pairs(self.tabs) do
        tab:SetAccent(tabKey == key or (tabKey == "archive" and key == "projects"))
    end
    if self.frame.expedition then self.frame.expedition:SetShown(key ~= "projects" and key ~= "expeditions" and key ~= "achievements" and key ~= "about") end
    self:RefreshProjectRaceSelection()
    self:RefreshVisiblePage()
    local page = self.pages[key]
    if changed and self.frame:IsShown() and page.PlayRelicAppearance then
        page:PlayRelicAppearance()
    end
end

function MainFrame:GetCurrentProjects()
    if self.projectCache then return self.projectCache, self.projectCacheReady or 0 end
    local projects, ready = {}, 0
    for i = 1, #(RP.Archaeology.races or {}) do
        local race = RP.Archaeology.races[i]
        if race.artifact and (tonumber(race.required) or 0) > 0 then
            -- Listing races must not change Blizzard's selected project or its sockets.
            local state = RP.Archaeology:GetProjectState(race.index)
            if state and state.artifact then
                projects[#projects + 1] = state
                if state.canSolve then ready = ready + 1 end
            end
        end
    end
    table.sort(projects, function(left, right)
        if left.canSolve ~= right.canSolve then return left.canSolve end
        return (left.race.name or "") < (right.race.name or "")
    end)
    self.projectCache, self.projectCacheReady = projects, ready
    return projects, ready
end

function MainFrame:RefreshProjectRaceSelection()
    for i = 1, #(self.projectsRaceRows or {}) do
        local row = self.projectsRaceRows[i]
        if row:IsShown() and row.projectState then
            local selected = self.selectedPage == "projects" and self.projectRaceFilter == row.raceIndex
            row:SetRelicState(selected and "selected" or (row.projectState.canSolve and "progress" or "normal"), true)
        end
    end
end

function MainFrame:RefreshVisiblePage()
    if self.selectedPage == "sites" then
        self:RefreshSites()
    elseif self.selectedPage == "races" then
        self:RefreshRaces()
    elseif self.selectedPage == "projects" then
        self:RefreshProjects()
    elseif self.selectedPage == "archive" then
        if self.archiveDirty or not self.archiveUIReady then self:RefreshArchive() end
    elseif self.selectedPage == "journal" then
        self:RefreshJournal()
    elseif self.selectedPage == "expeditions" then
        RP.ExpeditionsPage:Refresh()
    elseif self.selectedPage == "achievements" then
        RP.AchievementsPage:Refresh()
    end
end

function MainFrame:OnArchaeologyUpdated()
    self.projectCache, self.projectCacheReady = nil, nil
    self.archiveDirty = true
    self:Refresh()
end

function MainFrame:RefreshProjectRaceSelector()
    local projects = self:GetCurrentProjects()
    local entries = {}
    local filterExists = false
    for i = 1, #projects do
        local state = projects[i]
        entries[#entries + 1] = {
            raceIndex = state.race.index,
            name = state.race.name or RP.L.UNKNOWN_RACE,
            texture = state.race.texture or "Interface\\Icons\\Trade_Archaeology",
            progress = state.canSolve and RP.L.PROJECT_READY_SHORT or (RP.Archaeology.collectionStats and RP.Archaeology.collectionStats[state.race.index] or "—"),
            ready = state.canSolve,
            projectState = state,
        }
        if self.projectRaceFilter == state.race.index then filterExists = true end
    end
    if not filterExists then
        self.projectRaceFilter = projects[1] and projects[1].race.index or nil
    end

    for i = 1, math.max(#entries, #self.projectsRaceRows) do
        if not self.projectsRaceRows[i] then
            self.projectsRaceRows[i] = self:CreateProjectRaceRow(self.projectsRaceChild, i)
        end
        local row, entry = self.projectsRaceRows[i], entries[i]
        if entry then
            row.raceIndex = entry.raceIndex
            row.projectState = entry.projectState
            row.icon:SetTexture(entry.texture)
            row.nameText:SetText(RP.Localization:DisplayName(entry.name))
            row.progressText:SetText(entry.progress)
            row.progressText:SetTextColor(entry.ready and 0.90 or 0.6, entry.ready and 0.73 or 0.6, entry.ready and 0.35 or 0.6)
            row.ready:SetShown(entry.ready)
            row.ready:SetColorTexture(1, 0.72, 0.12, 1)
            local selected = self.selectedPage == "projects" and self.projectRaceFilter == entry.raceIndex
            row:SetRelicState(selected and "selected" or (entry.ready and "progress" or "normal"), true)
            row:Show()
        else
            row.raceIndex, row.projectState = nil, nil
            row:Hide()
        end
    end
    self.projectsRaceChild:SetHeight(math.max(1, math.ceil(#entries / 2) * 62))
end

function MainFrame:RefreshSites()
    local page = self.pages.sites
    page.routeMode:SetText(RP.L.ROUTE_MODE .. ": " .. (RP.db.settings.routeMode == "NEAREST" and RP.L.ROUTE_NEAREST or RP.L.ROUTE_PRIORITY))
    page.filterMode:SetText(RP.L.RACE_FILTER .. ": " .. (RP.db.settings.raceFilter == "STRICT" and RP.L.FILTER_STRICT or RP.L.FILTER_PREFER))
    local sites = RP.DigSites.sites
    for i = 1, math.max(#sites, #page.rows) do
        if not page.rows[i] then page.rows[i] = self:CreateSiteRow(page.child, i) end
        local row, site = page.rows[i], sites[i]
        if site then
            row.site = site
            row.nameText:SetText(site.name or RP.L.UNKNOWN)
            row.raceText:SetText(RP.Localization:DisplayName(site.raceName) or RP.L.UNKNOWN_RACE)
            row.distanceText:SetText(RP:FormatDistance(site.distance))
            row.icon:SetTexture(site.raceTexture or "Interface\\Icons\\Trade_Archaeology")
            local ignored = RP.db.blacklistedSites[tostring(site.researchSiteID)]
            local targeted = RP.RoutePlanner.currentTarget and RP.RoutePlanner.currentTarget.researchSiteID == site.researchSiteID
            row:SetAlpha(ignored and 0.55 or 1)
            row.ribbon:SetShown(targeted)
            local state = ignored and "disabled" or (targeted and "selected" or "normal")
            row:SetRelicState(state, true)
            row:Show()
        else row:Hide() end
    end
    page.child:SetHeight(math.max(1, math.ceil(#sites / 2) * 88))
    page.empty:SetShown(#sites == 0)
end

function MainFrame:RefreshRaces()
    local page, races = self.pages.races, RP.Archaeology.races
    for i = 1, math.max(#races, #page.cards) do
        if not page.cards[i] then page.cards[i] = self:CreateRaceCard(page.child, i) end
        local card, race = page.cards[i], races[i]
        if race then
            card.race = race
            card.icon:SetTexture(race.texture or "Interface\\Icons\\Trade_Archaeology")
            card.nameText:SetText(RP.Localization:DisplayName(race.name))
            card.fragments:SetText(race.fragments .. " / " .. race.required)
            card.bar:SetMinMaxValues(0, math.max(1, race.required))
            card.bar:SetValue(race.fragments)
            local selected = RP.db.selectedRaces[tostring(race.index)]
            local ignored = RP.db.blacklistedRaces[tostring(race.index)]
            local state = ignored and "disabled" or (selected and "selected" or ((race.fragments or 0) > 0 and "progress" or "normal"))
            card:SetRelicState(state, true)
            if ignored then card.indicator:SetColorTexture(0.46, 0.44, 0.40, 0.82); card.indicator:Show()
            elseif selected then card.indicator:SetColorTexture(1, 0.72, 0.16, 1); card.indicator:Show()
            elseif (race.fragments or 0) > 0 then card.indicator:SetColorTexture(0.82, 0.48, 0.10, 0.72); card.indicator:Show()
            else card.indicator:Hide() end
            card:SetAlpha(ignored and 0.48 or 1)
            card:Show()
        else card:Hide() end
    end
    page.child:SetHeight(math.max(1, math.ceil(#races / 4) * 64))
end

function MainFrame:RefreshProjects()
    local page = self.pages.projects
    if not page then return end
    if not self.frame:IsShown() then return end
    local allProjects = self:GetCurrentProjects()
    local state
    for i = 1, #allProjects do
        if allProjects[i].race.index == self.projectRaceFilter then
            state = RP.Archaeology:GetProjectState(allProjects[i].race.index)
            break
        end
    end
    local detail = page.detail
    page.projectState = state
    RP.AssemblyProgress:Render()
    page.empty:SetShown(not state)
    local content = {
        detail.raceIcon, detail.raceName, detail.raceHint, detail.artifactFrame,
        detail.artifactName, detail.meta, detail.description, detail.progressLabel,
        detail.progressText, detail.progress, detail.keystone, detail.solve, detail.history,
    }
    for i = 1, #content do content[i]:SetShown(state ~= nil) end
    if not state then
        page.title:SetText(RP.L.PROJECTS)
        return
    end

    local race, artifact = state.race, state.artifact
    local totalProgress = (state.base or 0) + (state.adjusted or 0)
    page.title:SetText(RP.L.PROJECTS)
    page.note:SetText("")
    detail.raceIcon:SetTexture(race.texture or "Interface\\Icons\\Trade_Archaeology")
    detail.raceName:SetText(RP.Localization:DisplayName(race.name) or RP.L.UNKNOWN_RACE)
    detail.artifactIcon:SetTexture(artifact.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    detail.artifactName:SetText(RP.Localization:DisplayName(artifact.name) or RP.L.CURRENT_ARTIFACT)
    detail.artifactName:SetTextColor(artifact.rarity == 1 and 0.76 or 1, artifact.rarity == 1 and 0.54 or 0.92, artifact.rarity == 1 and 1 or 0.72)
    detail.meta:SetText((artifact.rarity == 1 and RP.L.RARE or RP.L.NORMAL) .. "  •  " .. (RP.Localization:DisplayName(race.name) or RP.L.UNKNOWN_RACE))
    local description = artifact.description
    if not description or description == "" then description = artifact.hoverDescription end
    description = RP.ContentLocalization:ProjectHistory(race.index, artifact, description)
    local history = description and description ~= "" and description or RP.L.ARCHIVE_NO_DESCRIPTION
    if detail.historyText:GetText() ~= history then
        detail.historyText:SetText(history)
        detail.historyChild:SetWidth(math.max(1, detail.history:GetWidth()))
        detail.historyChild:SetHeight(math.max(1, detail.historyText:GetStringHeight()))
        detail.history:SetVerticalScroll(0)
    end
    detail.description:SetText(state.canSolve and RP.L.PROJECT_READY or RP.L.PROJECT_MISSING:format(math.max(0, (state.required or 0) - totalProgress)))
    detail.progressText:SetText(string.format("%d / %d", totalProgress, state.required or 0))
    detail.progress:SetMinMaxValues(0, math.max(1, state.required or 0))
    detail.progress:SetValue(math.min(totalProgress, state.required or totalProgress))

    local sockets, socketed = state.sockets or 0, state.socketed or 0
    if sockets > 0 then
        local keystoneName = GetLocalizedItemName(race.keystoneItemID)
        detail.keystone:SetText((keystoneName or RP.L.KEYSTONES) .. "  " .. socketed .. "/" .. sockets)
        if not keystoneName and race.keystoneItemID then
            if C_Item and C_Item.RequestLoadItemDataByID then
                C_Item.RequestLoadItemDataByID(race.keystoneItemID)
            end
            if Item and Item.CreateFromItemID then
                local selectedRaceIndex = race.index
                local item = Item:CreateFromItemID(race.keystoneItemID)
                item:ContinueOnItemLoad(function()
                    if not page.projectState or page.projectState.race.index ~= selectedRaceIndex then return end
                    local loadedName = GetLocalizedItemName(race.keystoneItemID)
                    if loadedName then detail.keystone:SetText(loadedName .. "  " .. socketed .. "/" .. sockets) end
                end)
            end
        end
        if socketed > 0 or (race.keystones or 0) > 0 then
            detail.keystone:Enable()
            detail.keystone:SetAccent(socketed > 0)
        else
            detail.keystone:SetAccent(false)
            detail.keystone:Disable()
        end
    else
        detail.keystone:SetText(RP.L.NO_KEYSTONE_SOCKETS)
        detail.keystone:SetAccent(false)
        detail.keystone:Disable()
    end

    if state.canSolve then
        detail.solve:SetText(RP.L.PROJECT_SOLVE)
        detail.solve:Enable()
        detail.solve:SetAccent(true)
    else
        detail.solve:SetText(RP.L.PROJECT_ROUTE)
        detail.solve:SetAccent(true)
        detail.solve:Enable()
    end
    detail.artifactFrame:SetRelicState(state.canSolve and "selected" or "normal", true)
end

function MainFrame:RefreshArchiveVisibleRows()
    local page = self.pages.archive
    if not page or not page.filteredArtifacts then return end
    local firstIndex = math.floor((page.scroll:GetVerticalScroll() or 0) / 68) + 1
    for slot = 1, 8 do
        if not page.rows[slot] then page.rows[slot] = self:CreateArchiveRow(page.child, slot) end
        local row = page.rows[slot]
        local artifactIndex = firstIndex + slot - 1
        local artifact = page.filteredArtifacts[artifactIndex]
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", 0, -(artifactIndex - 1) * 68)
        if artifact then
            row.artifact = artifact
            row.icon:SetTexture(artifact.icon or "Interface\\Icons\\Trade_Archaeology")
            row.icon:SetDesaturated(not artifact.obtained)
            row.icon:SetVertexColor(artifact.obtained and 1 or 0.58, artifact.obtained and 1 or 0.58, artifact.obtained and 1 or 0.58)
            row.nameText:SetText(RP.Localization:DisplayName(artifact.name))
            row.nameText:SetTextColor(artifact.rarity == 1 and 0.72 or 0.96, artifact.rarity == 1 and 0.50 or 0.93, artifact.rarity == 1 and 1 or 0.86)
            local status = artifact.obtained and RP.L.ARCHIVE_OBTAINED_STATUS or RP.L.ARCHIVE_MISSING_STATUS
            row.subText:SetText(RP.Localization:DisplayName(artifact.raceName) .. "  •  " .. status)
            local selected = artifact.key == page.selectedKey
            row:SetRelicState(selected and "selected" or (artifact.obtained and "completed" or "normal"), true)
            if row.icon.relicFrame then row.icon.relicFrame:SetRelicState(artifact.obtained and "completed" or "disabled", true) end
            row.statusMarker:SetShown(artifact.obtained)
            row:SetAlpha(artifact.obtained and 1 or 0.78)
            row:Show()
        else
            row.artifact = nil
            row:Hide()
        end
    end
end


function MainFrame:RefreshArchive()
    local page = self.pages.archive
    if not page then return end
    local artifacts, stats
    if self.archiveDirty or not self.archiveDataReady then
        artifacts, stats = RP.Archaeology:RefreshArchive()
        self.archiveDataReady = true
    else
        artifacts = RP.Archaeology.archive or {}
        stats = RP.Archaeology.archiveStats or { total = 0, obtained = 0, missing = 0, rare = 0 }
    end
    local raceStats = {}
    self:RefreshProjectRaceSelector()
    for i = 1, #artifacts do
        local artifact = artifacts[i]
        local scope = raceStats[artifact.raceIndex]
        if not scope then
            local race = RP.Archaeology:GetRace(artifact.raceIndex)
            scope = { raceIndex = artifact.raceIndex, name = artifact.raceName, texture = race and race.texture, total = 0, obtained = 0 }
            raceStats[artifact.raceIndex] = scope
        end
        scope.total = scope.total + 1
        if artifact.obtained then scope.obtained = scope.obtained + 1 end
    end

    local raceEntries = {
        { raceIndex = nil, name = RP.L.ARCHIVE_ALL_RACES, texture = "Interface\\Icons\\Trade_Archaeology", total = stats.total or 0, obtained = stats.obtained or 0 },
    }
    for raceIndex = 1, 20 do
        local scope = raceStats[raceIndex]
        if scope then raceEntries[#raceEntries + 1] = scope end
    end
    for i = 1, math.max(#raceEntries, #page.raceRows) do
        if not page.raceRows[i] then page.raceRows[i] = self:CreateArchiveRaceRow(page.raceChild, i) end
        local row, entry = page.raceRows[i], raceEntries[i]
        if entry then
            row.raceIndex = entry.raceIndex
            row.fullName = RP.Localization:DisplayName(entry.name)
            row:SetRaceArtwork(entry.texture, entry.raceIndex ~= nil and entry.texture ~= nil)
            row.nameText:SetText(RP.Localization:DisplayName(entry.name))
            row.countText:SetText(RP.L.ARCHIVE_RACE_COUNT:format(entry.obtained, entry.total))
            local selectedRace = page.raceFilter == entry.raceIndex
            row.iconSelected = selectedRace
            row:UpdateIconHighlight()
            local state = selectedRace and "selected" or "normal"
            row:SetRelicState(state, true)
            row:Show()
        else
            row.raceIndex, row.fullName = nil, nil
            row:Hide()
        end
    end
    page.raceChild:SetHeight(math.max(1, #raceEntries * 58))

    local filtered = {}
    for i = 1, #artifacts do
        local artifact = artifacts[i]
        local raceMatches = not page.raceFilter or artifact.raceIndex == page.raceFilter
        local statusMatches = page.filter == "ALL" or (page.filter == "OBTAINED" and artifact.obtained) or (page.filter == "MISSING" and not artifact.obtained)
        if raceMatches and statusMatches then
            filtered[#filtered + 1] = artifact
        end
    end

    page.all:SetAccent(page.filter == "ALL")
    page.obtained:SetAccent(page.filter == "OBTAINED")
    page.missing:SetAccent(page.filter == "MISSING")
    local currentStats = page.raceFilter and raceStats[page.raceFilter] or stats
    local total = currentStats and currentStats.total or 0
    local obtained = currentStats and currentStats.obtained or 0
    page.counter:SetText(RP.L.ARCHIVE_COUNTER:format(obtained, total, math.max(0, total - obtained)))

    local selected
    for i = 1, #filtered do
        if filtered[i].key == page.selectedKey then
            selected = filtered[i]
            break
        end
    end
    page.filteredArtifacts = filtered
    local contentHeight = math.max(1, #filtered * 68)
    local viewportHeight = page.scroll:GetHeight()
    if not viewportHeight or viewportHeight < 1 then viewportHeight = 404 end
    page.scroll.contentHeight = contentHeight
    page.scroll.maxScroll = math.max(0, contentHeight - viewportHeight)
    page.child:SetHeight(math.max(contentHeight, viewportHeight))
    page.scroll:SetVerticalScroll(0)
    if page.scroll.UpdateScrollChildRect then page.scroll:UpdateScrollChildRect() end
    self:RefreshArchiveVisibleRows()
    C_Timer.After(0, function()
        if not page.scroll or not page.child then return end
        local actualViewport = page.scroll:GetHeight()
        if not actualViewport or actualViewport < 1 then actualViewport = viewportHeight end
        page.scroll.maxScroll = math.max(0, page.scroll.contentHeight - actualViewport)
        page.child:SetHeight(math.max(page.scroll.contentHeight, actualViewport))
        page.scroll:SetVerticalScroll(math.min(page.scroll:GetVerticalScroll(), page.scroll.maxScroll))
        if page.scroll.UpdateScrollChildRect then page.scroll:UpdateScrollChildRect() end
        self:RefreshArchiveVisibleRows()
    end)
    self:SelectArchiveArtifact(selected or filtered[1])
    self.archiveDirty = false
    self.archiveUIReady = true
end

function MainFrame:RefreshJournal()
    local page, stats = self.pages.journal, RP.db.stats
    local duration = (stats.totalExpeditionSeconds or 0) + RP.Expedition:GetCurrentDuration()
    page.stats:SetText(table.concat({
        RP.L.DIGS_COMPLETED .. ":  |cFFFFD37F" .. (stats.digSites or 0) .. "|r",
        RP.L.SURVEYS .. ":  |cFFFFD37F" .. (stats.surveys or 0) .. "|r",
        RP.L.ARTIFACTS .. ":  |cFFFFD37F" .. (stats.artifacts or 0) .. "|r",
        RP.L.RARE_ARTIFACTS .. ":  |cFFFFD37F" .. (stats.rareArtifacts or 0) .. "|r",
        "",
        RP.L.EXPEDITION_TIME .. ":  " .. RP:FormatDuration(RP.Expedition:GetCurrentDuration()),
        RP.L.TOTAL_TIME .. ":  " .. RP:FormatDuration(duration),
    }, "\n"))
    local raceLines = {}
    for raceName, count in pairs(stats.byRace or {}) do raceLines[#raceLines + 1] = RP.Localization:DisplayName(raceName) .. " — " .. count end
    table.sort(raceLines)
    local visibleRaceLines = {}
    for i = 1, math.min(7, #raceLines) do visibleRaceLines[#visibleRaceLines + 1] = raceLines[i] end
    if #raceLines > 7 then visibleRaceLines[#visibleRaceLines + 1] = "…  +" .. (#raceLines - 7) end
    page.races:SetText(#visibleRaceLines > 0 and table.concat(visibleRaceLines, "\n") or "—")
    local recent = {}
    for i = 1, #(stats.recentArtifacts or {}) do recent[#recent + 1] = "• " .. RP.Localization:DisplayName(stats.recentArtifacts[i]) end
    page.recent:SetText(table.concat(recent, "\n"))
end

function MainFrame:Refresh()
    if not self.frame then return end
    local active = RP.db.expedition.active
    self.frame.expedition:SetText(RP.L.START_DIGGING)
    self.frame.expedition:SetAccent(not active)
    local mapID = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local mapInfo = mapID and C_Map.GetMapInfo(mapID)
    self.frame.location:SetText("|cFFD5B768" .. (mapInfo and mapInfo.name or RP.L.UNKNOWN) .. "|r\n" .. RP.L.SITES_FOUND:format(#RP.DigSites.sites))
    self:RefreshProjectRaceSelector()
    self:RefreshVisiblePage()
end

function MainFrame:RestorePosition()
    RP.Widgets:RestorePosition(self.frame, "main")
end

function MainFrame:Toggle()
    if not self.frame then return end
    if self.frame:IsShown() then self.frame:Hide()
    else
        RP.Archaeology:Refresh()
        RP.DigSites:Refresh("journal-open")
        self:Refresh()
        self:ApplySettings()
        self.frame:Show()
        self:RefreshVisiblePage()
    end
end

function MainFrame:OnLogin()
    self:Refresh()
end
