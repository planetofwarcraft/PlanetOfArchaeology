local _, RP = ...

local SiteTracker = { rows = {}, elapsed = 0 }
RP:RegisterModule("SiteTracker", SiteTracker)

-- An open compass needle, drawn with bronze/gold strokes instead of a map atlas.
local function CreateNeedle(parent)
    local needle = CreateFrame("Frame", nil, parent)
    needle:SetSize(18, 18)
    needle:SetPoint("RIGHT", -22, -1)
    needle:SetScale(0.85)
    local points = { {0, 9}, {-5, -6}, {0, -3}, {5, -6}, {0, 9} }
    needle.strokes = {}
    for i = 1, 4 do
        local line = needle:CreateLine(nil, "ARTWORK")
        line:SetThickness(1.6)
        line:SetColorTexture(0.88, 0.68, 0.31, 0.95)
        needle.strokes[i] = line
    end
    function needle:SetRotation(angle)
        local c, s = math.cos(angle), math.sin(angle)
        for i, line in ipairs(self.strokes) do
            local a, b = points[i], points[i + 1]
            line:SetStartPoint("CENTER", self, a[1] * c - a[2] * s, a[1] * s + a[2] * c)
            line:SetEndPoint("CENTER", self, b[1] * c - b[2] * s, b[1] * s + b[2] * c)
        end
    end
    needle:SetRotation(0)
    return needle
end

local function UpdateNeedle(row)
    local angle = RP.Navigation:GetDirectionTo(row.site)
    row.targetAngle = angle
    row.arrow:SetShown(angle ~= nil and RP.db.settings.showArrow)
    if angle and not row.angle then row.angle = angle; row.arrow:SetRotation(angle) end
end

local function CreateRow(parent, index)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    row:SetSize(220, 74)
    row:SetPoint("TOPLEFT", 0, -(index - 1) * 80)
    RP.Widgets:ApplyRelicCard(row, 0.93, 0.72)

    row.icon = row:CreateTexture(nil, "ARTWORK", nil, 2)
    row.icon:SetSize(34, 34)
    row.icon:SetPoint("LEFT", 8, 0)
    row.icon:SetTexture("Interface\\Icons\\Trade_Archaeology")
    row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("TOPLEFT", 48, -9)
    row.nameText:SetWidth(112)
    row.nameText:SetJustifyH("LEFT")
    row.nameText:SetWordWrap(true)
    row.nameText:SetMaxLines(2)
    row.raceText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.raceText:SetPoint("BOTTOMLEFT", 48, 11)
    row.raceText:SetWidth(90)
    row.raceText:SetJustifyH("LEFT")
    row.raceText:SetWordWrap(false)

    row.arrow = CreateNeedle(row)
    row.distance = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.distance:SetPoint("BOTTOMRIGHT", -13, 13)
    row.distance:SetWidth(55)
    row.distance:SetJustifyH("RIGHT")
    row.ribbon = RP.Widgets:CreateSelectionRibbon(row)
    row.ribbon:SetPoint("TOPRIGHT", -12, -10)

    row:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine(self.site.name or RP.L.UNKNOWN)
        GameTooltip:AddLine(RP.Localization:DisplayName(self.site.raceName) or RP.L.UNKNOWN_RACE, 0.82, 0.72, 0.52)
        GameTooltip:AddLine(RP.L.CLICK_TO_TRACK, 0.35, 0.95, 0.45, true)
        GameTooltip:Show()
    end)
    row:HookScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    row:SetScript("OnClick", function(self)
        if RP.db.expedition.active then
            RP.RoutePlanner:SelectManual(self.site.researchSiteID)
        else
            RP.Expedition:Start(self.site)
        end
    end)
    return row
end

function SiteTracker:OnInitialize()
    local frame = CreateFrame("Frame", "PlanetOfArchaeologySiteTracker", UIParent)
    frame:SetSize(248, 480)
    -- Keep Blizzard panels above this window and its children.
    frame:SetFrameStrata("LOW")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(f) f.relicDragging = true; f:StartMoving() end)
    frame:SetScript("OnDragStop", function(f)
        f:StopMovingOrSizing()
        f.relicDragging = nil
        RP.Widgets:SavePosition(f, "tracker")
    end)
    RP.Widgets:CreateRelicShell(frame)
    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -3, -3)
    close:SetScript("OnClick", function()
        RP.db.settings.showTracker = false
        frame:Hide()
    end)

    local heading = RP.Widgets:CreateCategoryDivider(frame, RP.L.ROUTE_WINDOW)
    heading:SetPoint("TOPLEFT", 18, -25)
    heading:SetPoint("TOPRIGHT", -18, -25)
    local compact = RP.Widgets:CreateCompactButton(frame)
    compact:SetPoint("TOPRIGHT", -29, -3)
    compact:SetScript("OnClick", function()
        RP.Widgets:TransitionLayout(frame, function()
            RP.db.settings.minimalTracker = not RP.db.settings.minimalTracker
            self:Refresh()
            if RP.WindowLayout then RP.WindowLayout:Apply() end
        end)
    end)
    compact:HookScript("OnEnter", function(b)
        GameTooltip:SetOwner(b, "ANCHOR_LEFT")
        GameTooltip:SetText(RP.db.settings.minimalTracker and RP.L.TRACKER_EXPAND or RP.L.TRACKER_COLLAPSE)
        GameTooltip:Show()
    end)
    compact:HookScript("OnLeave", GameTooltip_Hide)
    self.compactButton = compact
    local summary = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    summary:SetPoint("TOPLEFT", 18, -54)
    summary:SetPoint("TOPRIGHT", -18, -54)
    summary:SetHeight(62)
    RP.Widgets:ApplyRelicCard(summary, 0.96, 0.90)
    frame.area = summary:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    frame.area:SetPoint("TOPLEFT", 14, -12)
    frame.area:SetPoint("TOPRIGHT", -14, -12)
    frame.area:SetJustifyH("LEFT")
    frame.area:SetWordWrap(true)
    frame.races = summary:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.races:SetPoint("TOPLEFT", frame.area, "BOTTOMLEFT", 0, -7)
    frame.races:SetPoint("TOPRIGHT", frame.area, "BOTTOMRIGHT", 0, -7)
    frame.races:SetJustifyH("LEFT")
    frame.races:SetWordWrap(true)
    frame.races:SetTextColor(0.84, 0.74, 0.55)
    self.summary = summary
    frame.note = summary:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.note:SetText("")

    local controls = CreateFrame("Frame", nil, frame)
    controls:SetPoint("TOPLEFT", summary, "BOTTOMLEFT", 0, -8)
    controls:SetPoint("TOPRIGHT", summary, "BOTTOMRIGHT", 0, -8)
    controls:SetHeight(28)
    self.controls, self.raceButtons = controls, {}
    controls.choose = RP.Widgets:CreateButton(controls, "", 212, 26)
    controls.choose:SetPoint("TOP")
    controls.choose.text:SetPoint("RIGHT", -28, 0)
    local chevron = controls.choose:CreateLine(nil, "OVERLAY")
    chevron:SetThickness(1.5)
    chevron:SetColorTexture(0.9, 0.72, 0.35, 1)
    chevron:SetStartPoint("RIGHT", controls.choose, -20, 2)
    chevron:SetEndPoint("RIGHT", controls.choose, -16, -2)
    local chevronEnd = controls.choose:CreateLine(nil, "OVERLAY")
    chevronEnd:SetThickness(1.5)
    chevronEnd:SetColorTexture(0.9, 0.72, 0.35, 1)
    chevronEnd:SetStartPoint("RIGHT", controls.choose, -16, -2)
    chevronEnd:SetEndPoint("RIGHT", controls.choose, -12, 2)
    local popup = CreateFrame("Frame", nil, controls)
    popup:SetPoint("TOP", controls.choose, "BOTTOM", 0, -4)
    popup:SetWidth(224)
    popup:SetFrameStrata("LOW")
    popup:SetFrameLevel(frame:GetFrameLevel() + 100)
    popup:EnableMouse(true)
    RP.Widgets:ApplyRelicCard(popup, 1, 1)
    popup:Hide()
    self.racePopup = popup
    controls.choose:SetScript("OnClick", function() popup:SetShown(not popup:IsShown()) end)
    frame:HookScript("OnHide", function() popup:Hide() end)
    popup:SetScript("OnUpdate", function()
        if IsMouseButtonDown("LeftButton") and not popup:IsMouseOver() and not controls.choose:IsMouseOver() then popup:Hide() end
    end)
    RP.Theme:BindAppearance(popup, 0.12)
    popup.nearest = RP.Widgets:CreateButton(popup, RP.L.ROUTE_NEAREST, 204, 26)
    popup.nearest:SetPoint("TOP", 0, -10)
    popup.nearest:SetScript("OnClick", function()
        local _, races = RP.Archaeology:GetPossibleRaces()
        for _, race in ipairs(races) do RP.db.selectedRaces[tostring(race.index)] = nil end
        RP:Fire("ROUTE_SETTINGS_CHANGED")
        popup:Hide()
    end)
    local sitesHeading = RP.Widgets:CreateCategoryDivider(frame, RP.L.DIG_SITES)
    sitesHeading:SetPoint("TOPLEFT", controls, "BOTTOMLEFT", 0, -4)
    sitesHeading:SetPoint("TOPRIGHT", controls, "BOTTOMRIGHT", 0, -4)
    self.sitesHeading = sitesHeading

    local scroll = CreateFrame("ScrollFrame", nil, frame)
    scroll:SetPoint("TOPLEFT", sitesHeading, "BOTTOMLEFT", -4, -7)
    scroll:SetPoint("BOTTOMRIGHT", -14, 52)
    scroll:EnableMouseWheel(true)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(220, 1)
    scroll:SetScrollChild(child)
    self.empty = scroll:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    self.empty:SetPoint("TOPLEFT", 18, -20)
    self.empty:SetPoint("TOPRIGHT", -18, -20)
    self.empty:SetWordWrap(true)
    self.empty:SetText(RP.L.NO_MATCHING)
    self.empty:Hide()
    self.exclusionNotice = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    self.exclusionNotice:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 20, 90)
    self.exclusionNotice:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -20, 90)
    self.exclusionNotice:SetWordWrap(true)
    self.exclusionNotice:Hide()
    self.clearExclusions = RP.Widgets:CreateButton(frame, "", 190, 26)
    self.clearExclusions:SetPoint("BOTTOM", frame, "BOTTOM", 0, 56)
    self.clearExclusions:Hide()
    self.clearExclusions:SetScript("OnClick", function()
        -- Only clear exclusions affecting the currently loaded continent.
        for _, site in ipairs(RP.DigSites.sites) do
            RP.db.blacklistedSites[tostring(site.researchSiteID)] = nil
            if site.raceIndex then RP.db.blacklistedRaces[tostring(site.raceIndex)] = nil end
        end
        RP:Fire("ROUTE_SETTINGS_CHANGED")
        self:Refresh()
    end)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local range = self:GetVerticalScrollRange()
        self:SetVerticalScroll(math.max(0, math.min(range, self:GetVerticalScroll() - delta * 45)))
    end)

    self.frame, self.scroll, self.child = frame, scroll, child
    local expedition = RP.Widgets:CreateButton(frame, "", 190, 26)
    expedition:SetPoint("BOTTOM", 0, 18)
    expedition:SetScript("OnClick", function() RP.Expedition:Toggle() end)
    self.expeditionButton = expedition
    frame.scaleGrip = RP.Widgets:CreateScaleGrip(frame, 0.40, 1.60,
        function() return RP.db.settings.trackerScale or 1 end,
        function(value)
            RP.db.settings.trackerScale = value
            self:ApplySettings()
            if RP.Settings then RP.Settings:RefreshPanel() end
        end)
    self:RestorePosition()
    self:ApplySettings()
    frame:SetScript("OnShow", function() self:Refresh() end)
    frame:SetScript("OnUpdate", function(_, elapsed) self:OnUpdate(elapsed) end)
    frame:Hide()

    RP:On("DIG_SITES_UPDATED", self, self.Refresh)
    RP:On("TARGET_CHANGED", self, self.Refresh)
    RP:On("EXPEDITION_CHANGED", self, self.OnExpeditionChanged)
    RP:On("ROUTE_SETTINGS_CHANGED", self, self.Refresh)
end

function SiteTracker:ApplySettings()
    if not self.frame then return end
    local wanted = (RP.db.settings.trackerScale or 1) * (RP.db.settings.uiScale or 1)
    self.frame:SetScale(RP.Widgets:GetPixelPerfectScale(wanted))
    self.frame:SetAlpha(RP.db.settings.uiOpacity or 1)
end

function SiteTracker:RestorePosition()
    if self.frame then RP.Widgets:RestorePosition(self.frame, "tracker") end
end

function SiteTracker:OnExpeditionChanged(active)
    if active and RP.db.settings.showTracker then self.frame:Show() else self.frame:Hide() end
end

function SiteTracker:SetShownByUser(shown)
    RP.db.settings.showTracker = shown and true or false
    self.frame:SetShown(shown)
    if shown then
        RP.DigSites:Refresh("tracker-open")
        self:Refresh()
    end
end

function SiteTracker:Toggle()
    self:SetShownByUser(not self.frame:IsShown())
end

function SiteTracker:Refresh()
    if not self.frame then return end
    local minimal = RP.db.settings.minimalTracker
    if minimal then self.frame:SetHeight(132) end
    self.summary:SetShown(not minimal)
    self.controls:SetShown(not minimal)
    self.sitesHeading:SetShown(not minimal)
    self.expeditionButton:SetShown(not minimal)
    if self.frame.scaleGrip then self.frame.scaleGrip:SetShown(not minimal) end
    self.compactButton:SetExpanded(not minimal)
    self.scroll:ClearAllPoints()
    if minimal then
        self.racePopup:Hide()
        self.scroll:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14, -46)
        self.scroll:SetPoint("BOTTOMRIGHT", self.frame, "BOTTOMRIGHT", -14, 12)
        self.scroll:SetVerticalScroll(0)
    else
        self.scroll:SetPoint("TOPLEFT", self.sitesHeading, "BOTTOMLEFT", -4, -7)
        self.scroll:SetPoint("BOTTOMRIGHT", self.frame, "BOTTOMRIGHT", -14, 52)
    end
    self.scroll:EnableMouseWheel(not minimal)
    RP.DigSites:UpdateDistances()
    local mapInfo = RP.DigSites.mapID and C_Map and C_Map.GetMapInfo(RP.DigSites.mapID)
    self.frame.area:SetText(mapInfo and mapInfo.name or RP.L.UNKNOWN)
    local possibleRaces, localRaces = RP.Archaeology:GetPossibleRaces()
    self.frame.races:SetText(table.concat(possibleRaces, " • "))
    self.summary:SetHeight(math.max(62, 31 + self.frame.area:GetStringHeight() + self.frame.races:GetStringHeight()))

    local selectedCount = 0
    for _, race in ipairs(localRaces) do if RP.db.selectedRaces[tostring(race.index)] then selectedCount = selectedCount + 1 end end
    self.controls.choose:SetText(selectedCount > 0 and (RP.L.RACES .. ": " .. selectedCount) or RP.L.ROUTE_NEAREST)
    self.racePopup.nearest:SetAccent(selectedCount == 0)
    self.expeditionButton:SetText(RP.db.expedition.active and RP.L.ROUTE_STOP_SHORT or RP.L.ROUTE_START_SHORT)
    for i = 1, math.max(#localRaces, #self.raceButtons) do
        local button = self.raceButtons[i]
        if not button then
            button = RP.Widgets:CreateButton(self.racePopup, "", 204, 26)
            button:SetPoint("TOP", 0, -40 - (i - 1) * 30)
            button.text:SetPoint("LEFT", 26, 0)
            button.mark = button:CreateTexture(nil, "OVERLAY")
            button.mark:SetColorTexture(0.95, 0.76, 0.3, 1)
            button.mark:SetSize(6, 6)
            button.mark:SetPoint("LEFT", 12, 0)
            button.mark:SetRotation(math.pi / 4)
            button:SetScript("OnClick", function(b)
                RP.Archaeology:ToggleSelected(b.race.index)
            end)
            button:HookScript("OnEnter", function(b)
                GameTooltip:SetOwner(b, "ANCHOR_LEFT")
                GameTooltip:SetText(RP.Localization:DisplayName(b.race.name))
                GameTooltip:AddLine(RP.L.ROUTE_COMPACT_HINT, 0.85, 0.75, 0.55, true)
                GameTooltip:Show()
            end)
            button:HookScript("OnLeave", GameTooltip_Hide)
            self.raceButtons[i] = button
        end
        local race = localRaces[i]
        button.race = race
        button:SetShown(race ~= nil)
        if race then
            local selected = RP.db.selectedRaces[tostring(race.index)]
            button:SetText(RP.Localization:DisplayName(race.name))
            button.mark:SetShown(selected and true or false)
            button:SetAccent(selected)
        end
    end
    self.racePopup:SetHeight(46 + #localRaces * 30)
    local sites, excluded = {}, 0
    for _, site in ipairs(RP.DigSites.sites) do
        local eligible, reason = RP.RoutePlanner:IsEligible(site)
        if eligible then sites[#sites + 1] = site
        elseif reason == "site-blacklist" or reason == "race-blacklist" then excluded = excluded + 1 end
    end
    table.sort(sites, function(a, b)
        local sa, sb = RP.RoutePlanner:Score(a), RP.RoutePlanner:Score(b)
        if sa == sb then return a.researchSiteID < b.researchSiteID end
        return sa < sb
    end)
    if minimal then
        sites = RP.RoutePlanner.currentTarget and { RP.RoutePlanner.currentTarget } or {}
    end
    for i = 1, math.max(#sites, #self.rows) do
        if not self.rows[i] then self.rows[i] = CreateRow(self.child, i) end
        local row, site = self.rows[i], sites[i]
        if site then
            if not row.site or row.site.researchSiteID ~= site.researchSiteID then row.angle = nil end
            row.site = site
            row.nameText:SetText(site.name or RP.L.UNKNOWN)
            row.raceText:SetText(RP.Localization:DisplayName(site.raceName) or RP.L.UNKNOWN_RACE)
            row.icon:SetTexture(site.raceTexture or "Interface\\Icons\\Trade_Archaeology")
            row.distance:SetText(RP:FormatDistance(site.distance))
            UpdateNeedle(row)
            local targeted = RP.RoutePlanner.currentTarget and RP.RoutePlanner.currentTarget.researchSiteID == site.researchSiteID
            local state = targeted and "selected" or "normal"
            row:SetRelicState(state, true)
            row.ribbon:SetShown(targeted)
            row:Show()
        else
            row:Hide()
        end
    end
    if not minimal then
        self.frame:SetHeight(180 + self.summary:GetHeight() + math.max(1, math.min(4, #sites)) * 80)
    end
    self.child:SetHeight(math.max(1, #sites * 80))
    self.empty:SetShown(#sites == 0)
    local hiddenByExclusions = not minimal and excluded > 0
    self.empty:SetText(RP.L.NO_MATCHING)
    self.empty:SetShown(#sites == 0 and not hiddenByExclusions)
    self.exclusionNotice:SetText(RP.L.ROUTE_HIDDEN:format(excluded))
    self.exclusionNotice:SetShown(hiddenByExclusions)
    self.clearExclusions:SetText(RP.L.ROUTE_CLEAR_EXCLUSIONS)
    self.clearExclusions:SetShown(hiddenByExclusions)
    if hiddenByExclusions then
        local footerHeight = self.exclusionNotice:GetStringHeight() + 48
        self.scroll:SetPoint("BOTTOMRIGHT", self.frame, "BOTTOMRIGHT", -14, 52 + footerHeight)
        self.frame:SetHeight(self.frame:GetHeight() + footerHeight)
    end
    self.scroll:SetVerticalScroll(math.min(self.scroll:GetVerticalScroll(), math.max(0, #sites * 80 - self.scroll:GetHeight())))
end

function SiteTracker:OnUpdate(elapsed)
    self.sortElapsed = (self.sortElapsed or 0) + elapsed
    if self.sortElapsed >= 2 then self.sortElapsed = 0; self:Refresh() end
    self.elapsed = self.elapsed + elapsed
    self.directionElapsed = (self.directionElapsed or 0) + elapsed
    local updateDistance = self.elapsed >= 0.25
    local updateDirection = self.directionElapsed >= 0.05
    if updateDistance then self.elapsed = 0; RP.DigSites:UpdateDistances() end
    if updateDirection then self.directionElapsed = 0 end
    for i = 1, #self.rows do
        local row = self.rows[i]
        if row:IsShown() and row.site then
            if updateDistance then row.distance:SetText(RP:FormatDistance(row.site.distance)) end
            if updateDirection then UpdateNeedle(row) end
            if row.arrow:IsShown() and row.targetAngle and row.angle then
                local delta = (row.targetAngle - row.angle + math.pi) % (2 * math.pi) - math.pi
                if math.abs(delta) > 0.0001 then
                    row.angle = (row.angle + delta * (1 - math.exp(-14 * elapsed))) % (2 * math.pi)
                    row.arrow:SetRotation(row.angle)
                end
            end
        end
    end
end

function SiteTracker:OnLogin()
    if RP.db.expedition.active and RP.db.settings.showTracker then self.frame:Show() end
end
