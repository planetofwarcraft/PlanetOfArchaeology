local _, RP = ...

local Widgets = {}
RP:RegisterModule("Widgets", Widgets)

function Widgets:ApplyBackdrop(frame, inset)
    inset = inset or 7
    RP.Theme:ApplyPanel(frame, 0.97)
    if not frame.relicShadow then
        local shadow = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
        shadow:SetColorTexture(0, 0, 0, 0.72)
        shadow:SetPoint("TOPLEFT", -10, 10)
        shadow:SetPoint("BOTTOMRIGHT", 10, -10)
        frame.relicShadow = shadow
    end
end

function Widgets:CreateRelicShell(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints(parent)
    panel:SetFrameLevel(parent:GetFrameLevel())
    RP.Theme:ApplyPanel(panel, 0.90)
    return panel
end

function Widgets:CreateMajorDivider(parent)
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetHeight(16)
    local left = frame:CreateTexture(nil, "ARTWORK")
    left:SetColorTexture(0.56, 0.41, 0.23, 0.64)
    left:SetPoint("LEFT")
    left:SetPoint("RIGHT", frame, "CENTER", -8, 0)
    left:SetHeight(1)
    local right = frame:CreateTexture(nil, "ARTWORK")
    right:SetColorTexture(0.56, 0.41, 0.23, 0.64)
    right:SetPoint("LEFT", frame, "CENTER", 8, 0)
    right:SetPoint("RIGHT")
    right:SetHeight(1)
    local diamond = frame:CreateTexture(nil, "ARTWORK")
    diamond:SetColorTexture(0.68, 0.50, 0.26, 0.82)
    diamond:SetSize(8, 8)
    diamond:SetPoint("CENTER")
    diamond:SetRotation(math.rad(45))
    local core = frame:CreateTexture(nil, "OVERLAY")
    core:SetColorTexture(0.035, 0.027, 0.020, 1)
    core:SetSize(4, 4)
    core:SetPoint("CENTER")
    core:SetRotation(math.rad(45))
    return frame
end

function Widgets:CreateCategoryDivider(parent, text)
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetHeight(26)
    local label = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetPoint("CENTER")
    label:SetText(text or "")
    label:SetTextColor(unpack(RP.colors.parchment))
    local left = frame:CreateTexture(nil, "BACKGROUND")
    left:SetTexture("Interface\\Buttons\\WHITE8X8")
    left:SetHeight(1)
    left:SetPoint("LEFT", 6, 0)
    left:SetPoint("RIGHT", label, "LEFT", -8, 0)
    left:SetGradient("HORIZONTAL", CreateColor(0.55, 0.40, 0.20, 0), CreateColor(0.55, 0.40, 0.20, 0.70))
    local right = frame:CreateTexture(nil, "BACKGROUND")
    right:SetTexture("Interface\\Buttons\\WHITE8X8")
    right:SetHeight(1)
    right:SetPoint("LEFT", label, "RIGHT", 8, 0)
    right:SetPoint("RIGHT", -6, 0)
    right:SetGradient("HORIZONTAL", CreateColor(0.55, 0.40, 0.20, 0.70), CreateColor(0.55, 0.40, 0.20, 0))
    return frame
end

function Widgets:CreateStatusMarker(parent, status)
    local marker = CreateFrame("Frame", nil, parent)
    marker:SetSize(26, 26)
    marker:SetFrameLevel(parent:GetFrameLevel() + 20)
    RP.Theme:ApplyNineSlice(marker, { cut = 5, fillAlpha = 1, borderAlpha = 0.92, grainAlpha = 0 })

    local function CreateStroke(width, height, x, y, rotation)
        local stroke = marker:CreateTexture(nil, "OVERLAY", nil, 2)
        stroke:SetTexture("Interface\\Buttons\\WHITE8X8")
        stroke:SetSize(width, height)
        stroke:SetPoint("CENTER", x, y)
        stroke:SetRotation(math.rad(rotation))
        stroke:Hide()
        return stroke
    end

    marker.strokeA = CreateStroke(2, 8, -4, -4, 45)
    marker.strokeB = CreateStroke(2, 14, 2, -1, -45)
    marker.dot = marker:CreateTexture(nil, "OVERLAY", nil, 2)
    marker.dot:SetTexture("Interface\\Buttons\\WHITE8X8")
    marker.dot:SetSize(7, 7)
    marker.dot:SetPoint("CENTER")
    marker.dot:SetRotation(math.rad(45))
    marker.dot:Hide()

    function marker:SetSymbol(kind, red, green, blue)
        self.strokeA:Hide()
        self.strokeB:Hide()
        self.dot:Hide()
        if kind == "check" then
            self.strokeA:SetSize(2, 8)
            self.strokeA:ClearAllPoints()
            self.strokeA:SetPoint("CENTER", -4, -4)
            self.strokeA:SetRotation(math.rad(45))
            self.strokeB:SetSize(2, 14)
            self.strokeB:ClearAllPoints()
            self.strokeB:SetPoint("CENTER", 2, -1)
            self.strokeB:SetRotation(math.rad(-45))
            self.strokeA:SetColorTexture(red, green, blue, 1)
            self.strokeB:SetColorTexture(red, green, blue, 1)
            self.strokeA:Show()
            self.strokeB:Show()
        elseif kind == "cross" then
            self.strokeA:SetSize(2, 12)
            self.strokeA:ClearAllPoints()
            self.strokeA:SetPoint("CENTER", 0, 0)
            self.strokeA:SetRotation(math.rad(45))
            self.strokeB:SetSize(2, 12)
            self.strokeB:ClearAllPoints()
            self.strokeB:SetPoint("CENTER", 0, 0)
            self.strokeB:SetRotation(math.rad(-45))
            self.strokeA:SetColorTexture(red, green, blue, 1)
            self.strokeB:SetColorTexture(red, green, blue, 1)
            self.strokeA:Show()
            self.strokeB:Show()
        else
            self.dot:SetColorTexture(red, green, blue, 1)
            self.dot:Show()
        end
    end

    function marker:SetStatus(value)
        self.status = value or "selected"
        if self.status == "completed" then
            self:SetRelicState("completed", true)
            self:SetSymbol("check", 0.35, 0.95, 0.36)
        elseif self.status == "progress" then
            self:SetRelicState("progress", true)
            self:SetSymbol("dot", 1, 0.72, 0.10)
        elseif self.status == "unavailable" then
            self:SetRelicState("disabled", true)
            self:SetSymbol("cross", 0.62, 0.60, 0.56)
        else
            self:SetRelicState("selected", true)
            self:SetSymbol("check", 1, 0.76, 0.20)
        end
    end
    marker:SetStatus(status)
    return marker
end

function Widgets:CreateSelectionRibbon(parent)
    -- A single compact outline, drawn at its actual size. Scaling a decorated
    -- 26px marker down produced overlapping borders and uneven check strokes.
    local marker = CreateFrame("Frame", nil, parent)
    marker:SetSize(18, 18)
    marker:SetFrameLevel(parent:GetFrameLevel() + 20)
    marker:EnableMouse(false)
    local background = marker:CreateTexture(nil, "BACKGROUND")
    background:SetColorTexture(0.055, 0.038, 0.012, 0.85)
    background:SetPoint("TOPLEFT", 3, -3)
    background:SetPoint("BOTTOMRIGHT", -3, 3)
    local function Stroke(x1, y1, x2, y2, thickness)
        local line = marker:CreateLine(nil, "OVERLAY")
        line:SetThickness(thickness)
        line:SetColorTexture(1, 0.76, 0.20, 1)
        line:SetStartPoint("TOPLEFT", marker, x1, -y1)
        line:SetEndPoint("TOPLEFT", marker, x2, -y2)
    end
    local points = {{4,1},{14,1},{17,4},{17,14},{14,17},{4,17},{1,14},{1,4},{4,1}}
    for i = 1, #points - 1 do
        Stroke(points[i][1], points[i][2], points[i+1][1], points[i+1][2], 1)
    end
    Stroke(4, 9, 7, 12, 1.5)
    Stroke(7, 12, 14, 5, 1.5)
    marker:Hide()
    return marker
end

function Widgets:CreateBlizzardFrame(name, parent)
    local frame = CreateFrame("Frame", name, parent, "BackdropTemplate")
    self:ApplyBackdrop(frame)

    local header = frame:CreateTexture(nil, "BACKGROUND", nil, 1)
    header:SetTexture("Interface\\Buttons\\WHITE8X8")
    header:SetPoint("TOPLEFT", 8, -8)
    header:SetPoint("TOPRIGHT", -8, -8)
    header:SetHeight(45)
    header:SetGradient("VERTICAL", CreateColor(0.11, 0.065, 0.035, 0.92), CreateColor(0.025, 0.021, 0.018, 0.96))
    frame.HeaderBackground = header

    local inset = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    inset:SetPoint("TOPLEFT", 11, -54)
    inset:SetPoint("BOTTOMRIGHT", -11, 11)
    inset:SetFrameLevel(frame:GetFrameLevel())
    inset:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    inset:SetBackdropColor(0.010, 0.011, 0.012, 0.72)
    inset:SetBackdropBorderColor(0.25, 0.20, 0.14, 0.82)
    frame.Inset = inset

    local portraitFrame = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    portraitFrame:SetSize(42, 42)
    portraitFrame:SetPoint("TOPLEFT", 13, -10)
    portraitFrame:SetFrameLevel(frame:GetFrameLevel() + 5)
    portraitFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 11, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    portraitFrame:SetBackdropColor(0.02, 0.018, 0.015, 1)
    portraitFrame:SetBackdropBorderColor(0.94, 0.72, 0.28, 1)
    local portrait = portraitFrame:CreateTexture(nil, "ARTWORK")
    portrait:SetPoint("TOPLEFT", 5, -5)
    portrait:SetPoint("BOTTOMRIGHT", -5, 5)
    portrait:SetTexture("Interface\\Icons\\Trade_Archaeology")
    portrait:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    frame.Portrait = portrait

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 64, -17)
    title:SetPoint("RIGHT", -42, 0)
    title:SetJustifyH("LEFT")
    title:SetTextColor(unpack(RP.colors.parchment))
    frame.TitleText = title
    function frame:SetTitle(value) self.TitleText:SetText(value or "") end
    function frame:SetPortraitToAsset(asset) self.Portrait:SetTexture(asset) end

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetSize(29, 29)
    close:SetPoint("TOPRIGHT", -8, -8)
    close:SetFrameLevel(frame:GetFrameLevel() + 10)
    frame.CloseButton = close
    frame:SetTitle(RP.L.ADDON_NAME)
    return frame
end

function Widgets:CreatePanel(name, parent)
    local frame = CreateFrame("Frame", name, parent, "BackdropTemplate")
    self:ApplyBackdrop(frame)
    return frame
end

function Widgets:CreateButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent)
    button:SetSize(width or 150, height or 30)
    RP.Theme:ApplyButton(button)
    button.text = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.text:SetPoint("LEFT", 8, 0)
    button.text:SetPoint("RIGHT", -8, 0)
    button.text:SetJustifyH("CENTER")
    button.text:SetText(text or "")
    function button:SetText(value) self.text:SetText(value or "") end
    function button:GetFontString() return self.text end
    function button:SetAccent(enabled)
        self.selected = enabled and true or false
        if enabled then
            self:SetRelicState("selected", true)
            self.text:SetTextColor(1, 0.82, 0.18)
        else
            self:SetRelicState("normal", true)
            self.text:SetTextColor(0.93, 0.84, 0.67)
        end
    end
    button:HookScript("OnEnter", function(self)
        if not self.selected then
            self.text:SetTextColor(1, 0.82, 0.42)
        end
    end)
    button:HookScript("OnLeave", function(self)
        if not self.selected then self:SetAccent(false) end
    end)
    button:SetAccent(false)
    return button
end

function Widgets:ApplyRelicCard(frame, backgroundAlpha, borderAlpha)
    RP.Theme:ApplyListItem(frame, (frame:GetHeight() or 0) <= 58)
end

function Widgets:ApplyRelicPanel(frame, alpha)
    RP.Theme:ApplyPanel(frame, alpha)
end

function Widgets:AddIconFrame(texture, size, state)
    if not texture or texture.relicFrame then return texture and texture.relicFrame end
    local frame = CreateFrame("Frame", nil, texture:GetParent())
    frame:SetSize((size or texture:GetWidth()) + 8, (size or texture:GetHeight()) + 8)
    frame:SetPoint("CENTER", texture)
    frame:SetFrameLevel(texture:GetParent():GetFrameLevel() + 8)
    RP.Theme:ApplyIconBorder(frame, state or "normal")
    texture.relicFrame = frame
    return frame
end

function Widgets:AddIconRing(texture, size, state)
    return self:AddIconFrame(texture, size, state)
end

function Widgets:GetResolutionScale()
    -- One continuous rule for 1080p, 1440p, 4K and ultrawide viewports.
    -- Frame coordinates live in UIParent units, not physical/render pixels.
    -- Mixing the two can double the size on 4K with resolution/UI scaling.
    local uiWidth, uiHeight = UIParent:GetWidth(), UIParent:GetHeight()
    if not uiWidth or not uiHeight or uiWidth <= 0 or uiHeight <= 0 then return 1 end
    local boost = 1
    if type(GetPhysicalScreenSize) == "function" then
        local _, physicalHeight = GetPhysicalScreenSize()
        if physicalHeight and physicalHeight > 0 then
            -- 15% more readable at 1080p; taper to the existing size at 1440p.
            -- Physical pixels only choose the boost, never the frame coordinates.
            boost = 1 + 0.15 * math.max(0, math.min(1, (1440 - physicalHeight) / 360))
        end
    end
    return math.min(uiWidth / 1600, uiHeight / 1000) * boost
end

function Widgets:FitMainScale(scale)
    local width, height = UIParent:GetWidth(), UIParent:GetHeight()
    if not width or not height or width <= 0 or height <= 0 then return scale end
    -- Reserve room for the route and screen edges, including saved large sliders.
    local settings = RP.db and RP.db.settings or {}
    local reserve = 0
    if settings.dockWindows ~= false then
        local global = settings.uiScale or 0.9
        local route = 248 * self:GetPixelPerfectScale(global * (settings.trackerScale or 1))
        reserve = route + 24
    end
    return math.min(scale, math.max(width * 0.35, width - reserve - 32) / 1050, width * 0.76 / 1050, height * 0.80 / 650)
end

function Widgets:GetPixelPerfectScale(value, ignoreResolution)
    value = tonumber(value) or 1
    -- Allow the full product of the global and individual 40% sliders.
    return math.max(0.16, value) * (ignoreResolution and 1 or self:GetResolutionScale())
end

function Widgets:OnLogin()
    local driver = CreateFrame("Frame")
    for _, event in ipairs({"PLAYER_ENTERING_WORLD", "DISPLAY_SIZE_CHANGED", "UI_SCALE_CHANGED", "PLAYER_REGEN_ENABLED"}) do
        driver:RegisterEvent(event)
    end
    local function RefreshScale()
        if self.resolutionPending then return end
        self.resolutionPending = true
        C_Timer.After(0.2, function()
            self.resolutionPending = nil
            if InCombatLockdown() then return end
            for _, key in ipairs({"MainFrame", "HUD", "SiteTracker", "Proximity", "Notifications", "MinimapButton"}) do
                local module = RP[key]
                if module and module.ApplySettings then module:ApplySettings() end
            end
        end)
    end
    driver:SetScript("OnEvent", RefreshScale)
    self.resolutionDriver = driver
    -- Initial frames are built during ADDON_LOADED, before the final viewport
    -- and UI scale are guaranteed. Use the same calculation as interface reset
    -- after login as well, without rewriting any saved slider values.
    RefreshScale()
end

function Widgets:CreateNavButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent)
    button:SetSize(width or 150, height or 34)
    RP.Theme:ApplyButton(button)
    button.accent = button:CreateTexture(nil, "ARTWORK")
    button.accent:SetColorTexture(0.76, 0.48, 0.15, 1)
    button.accent:SetPoint("TOPLEFT", 1, -1)
    button.accent:SetPoint("BOTTOMLEFT", 1, 1)
    button.accent:SetWidth(2)
    button.accent:Hide()
    button.iconGlow = button:CreateTexture(nil, "BACKGROUND")
    button.iconGlow:SetTexture("Interface\\Buttons\\WHITE8X8")
    button.iconGlow:SetGradient("HORIZONTAL", CreateColor(0.40, 0.18, 0.045, 0.72), CreateColor(0.03, 0.02, 0.015, 0))
    button.iconGlow:SetPoint("TOPLEFT", 5, -5)
    button.iconGlow:SetPoint("BOTTOMRIGHT", -5, 5)
    button.iconGlow:Hide()
    button.text = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.text:SetPoint("LEFT", 14, 0)
    button.text:SetPoint("RIGHT", -8, 0)
    button.text:SetJustifyH("LEFT")
    button.text:SetText(text or "")
    function button:SetText(value) self.text:SetText(value or "") end
    function button:SetAccent(enabled)
        self.selected = enabled and true or false
        self.accent:SetShown(self.selected)
        self.iconGlow:SetShown(self.selected)
        self:SetRelicState(self.selected and "selected" or "normal", true)
        self.text:SetTextColor(self.selected and 1 or 0.78, self.selected and 0.82 or 0.69, self.selected and 0.34 or 0.52)
    end
    button:HookScript("OnEnter", function(self)
        if not self.selected then
            self.text:SetTextColor(1, 0.82, 0.42)
        end
    end)
    button:HookScript("OnLeave", function(self)
        if not self.selected then
            self.text:SetTextColor(0.78, 0.69, 0.52)
        end
    end)
    button:SetAccent(false)
    return button
end

function Widgets:DecorateWindow(frame)
    if frame.relicTopAccent then return end
    local top = frame:CreateTexture(nil, "OVERLAY")
    top:SetColorTexture(0.72, 0.44, 0.13, 0.9)
    top:SetPoint("TOPLEFT", 12, -53)
    top:SetPoint("TOPRIGHT", -12, -53)
    top:SetHeight(1)
    local glow = frame:CreateTexture(nil, "ARTWORK")
    glow:SetTexture("Interface\\Buttons\\WHITE8X8")
    glow:SetGradient("HORIZONTAL", CreateColor(0.72, 0.38, 0.08, 0), CreateColor(0.72, 0.38, 0.08, 0.22))
    glow:SetPoint("TOPLEFT", top, "BOTTOMLEFT", 0, -1)
    glow:SetPoint("TOPRIGHT", top, "BOTTOMRIGHT", 0, -1)
    glow:SetHeight(7)
    frame.relicTopAccent = top
end

function Widgets:CreateCompactButton(parent)
    local button = CreateFrame("Button", nil, parent, "UIPanelHideButtonNoScripts")
    button:SetSize(24, 24)
    button:SetFrameLevel(parent:GetFrameLevel() + 25)
    function button:SetExpanded(expanded)
        self:GetNormalTexture():SetAtlas(expanded and "RedButton-MiniCondense" or "RedButton-Expand")
        self:GetPushedTexture():SetAtlas(expanded and "RedButton-MiniCondense-pressed" or "RedButton-Expand-Pressed")
    end
    return button
end

function Widgets:TransitionLayout(frame, change)
    if frame.relicTransition or InCombatLockdown() then return end
    if frame.relicAppearance then frame.relicAppearance:Stop() end
    local alpha = frame:GetAlpha()
    local fade = frame:CreateAnimationGroup()
    local out = fade:CreateAnimation("Alpha")
    out:SetFromAlpha(alpha); out:SetToAlpha(0); out:SetDuration(0.10)
    out:SetSmoothing("OUT")
    frame.relicTransition = fade
    fade:SetScript("OnFinished", function()
        frame.relicTransition = nil
        if InCombatLockdown() or not frame:IsShown() then return end
        change()
        if frame.PlayRelicAppearance then frame:PlayRelicAppearance() end
    end)
    fade:Play()
end

function Widgets:CreateScaleGrip(parent, minimum, maximum, getter, setter)
    local grip = CreateFrame("Button", nil, parent)
    grip:SetSize(24, 24)
    grip:SetPoint("BOTTOMRIGHT", -7, 7)
    grip:SetFrameLevel(parent:GetFrameLevel() + 20)
    grip:RegisterForDrag("LeftButton")
    for i = 0, 2 do
        local line = grip:CreateTexture(nil, "OVERLAY")
        line:SetColorTexture(0.88, 0.67, 0.27, 0.72 - i * 0.12)
        line:SetSize(2, 7 + i * 4)
        line:SetPoint("BOTTOMRIGHT", -5 - i * 4, 5)
        line:SetRotation(math.rad(-45))
    end
    grip:SetScript("OnDragStart", function(self)
        if InCombatLockdown() then return end
        GameTooltip:Hide()
        parent.relicResizing = true
        local x, y = GetCursorPosition()
        local scale = parent:GetEffectiveScale()
        self.startX, self.startY = x, y
        self.left, self.top = parent:GetLeft() * scale, parent:GetTop() * scale
        self.width, self.height = parent:GetWidth() * scale, parent:GetHeight() * scale
        self.startValue = parent:GetScale() / ((RP.db.settings.uiScale or 1) * Widgets:GetResolutionScale())
        self.value = self.startValue
        self.startScale = parent:GetScale()
        self.lower = minimum
        self:SetScript("OnUpdate", function(handle, elapsed)
            if InCombatLockdown() then handle:GetScript("OnDragStop")(handle); return end
            local currentX, currentY = GetCursorPosition()
            local ratio = 1 + ((currentX - handle.startX) * handle.width
                - (currentY - handle.startY) * handle.height) / (handle.width ^ 2 + handle.height ^ 2)
            local target = math.max(handle.lower, math.min(maximum, handle.startValue * ratio))
            handle.value = handle.value + (target - handle.value) * (1 - math.exp(-24 * elapsed))
            ratio = handle.value / handle.startValue
            parent:SetScale(handle.startScale * ratio)
            local effective = parent:GetEffectiveScale()
            parent:ClearAllPoints()
            parent:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", handle.left / effective, handle.top / effective)
        end)
    end)
    grip:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
        parent.relicResizing = nil
        if not self.value or InCombatLockdown() then return end
        setter(self.value, false)
        local scale = parent:GetEffectiveScale()
        parent:ClearAllPoints()
        parent:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", self.left / scale, self.top / scale)
        if parent.relicPositionKey then Widgets:SavePosition(parent, parent.relicPositionKey) end
        self.value = nil
    end)
    grip:SetScript("OnHide", function(self)
        self:SetScript("OnUpdate", nil)
        parent.relicResizing = nil
        self.value = nil
    end)
    grip:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:AddLine(RP.L.RESIZE_WINDOW or "Drag to resize")
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave", GameTooltip_Hide)
    return grip
end

function Widgets:CreateTitle(parent, text, template)
    local title = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormalLarge")
    title:SetText(text or "")
    title:SetTextColor(unpack(RP.colors.gold))
    return title
end

function Widgets:CreateRule(parent)
    local rule = parent:CreateTexture(nil, "ARTWORK")
    rule:SetColorTexture(unpack(RP.colors.bronze))
    rule:SetHeight(1)
    return rule
end

function Widgets:CreateProgress(parent, width, height)
    local bar = CreateFrame("StatusBar", nil, parent, "BackdropTemplate")
    bar:SetSize(width, height)
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetStatusBarColor(0.58, 0.39, 0.17, 1)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    bar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    bar:SetBackdropColor(0.025, 0.018, 0.012, 0.9)
    bar:SetBackdropBorderColor(0.34, 0.23, 0.12, 1)
    return bar
end

function Widgets:SavePosition(frame, key)
    local point, _, relativePoint, x, y = frame:GetPoint(1)
    RP.db.positions[key] = { point = point, relativePoint = relativePoint, x = x, y = y }
end

function Widgets:RestorePosition(frame, key)
    frame.relicPositionKey = key
    local position = RP.db.positions[key]
    frame:ClearAllPoints()
    if position then
        frame:SetPoint(position.point or "CENTER", UIParent, position.relativePoint or position.point or "CENTER", position.x or 0, position.y or 0)
    else
        frame:SetPoint("CENTER")
    end
end
