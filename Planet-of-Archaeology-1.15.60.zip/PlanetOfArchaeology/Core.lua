local addonName, RP = ...

RP.addonName = addonName
RP.version = "1.15.60"
RP.modules = RP.modules or {}
RP.callbacks = RP.callbacks or {}

local GOLD = "|cFFD5B768"
local RESET = "|r"

function RP:RegisterModule(name, module)
    self.modules[name] = module
    self[name] = module
    module.name = name
end

function RP:Print(message)
    DEFAULT_CHAT_FRAME:AddMessage(GOLD .. "Planet of Archaeology: " .. RESET .. tostring(message))
end

function RP:Debug(formatString, ...)
    if not self.db or not self.db.settings.debug then return end
    local ok, message = pcall(string.format, tostring(formatString), ...)
    self:Print("|cFF8FBBD9[debug]|r " .. (ok and message or tostring(formatString)))
end

function RP:On(message, owner, callback)
    self.callbacks[message] = self.callbacks[message] or {}
    table.insert(self.callbacks[message], { owner = owner, callback = callback })
end

function RP:Fire(message, ...)
    local callbacks = self.callbacks[message]
    if not callbacks then return end
    for i = 1, #callbacks do
        local item = callbacks[i]
        local ok, err = pcall(item.callback, item.owner, ...)
        if not ok then self:Print("Callback error: " .. tostring(err)) end
    end
end

function RP:SafeCall(api, ...)
    if type(api) ~= "function" then return false end
    return pcall(api, ...)
end

function RP:FormatDistance(yards)
    if type(yards) ~= "number" then return "—" end
    local meters = math.max(0, yards * 0.9144)
    local units = self.db and self.db.settings and self.db.settings.distanceUnits or "AUTO"
    if units == "AUTO" then
        -- Client locale is a default preference, not a guess about citizenship.
        units = GetLocale() == "enUS" and "IMPERIAL" or "METRIC"
    end
    if units == "IMPERIAL" then
        yards = math.max(0, yards)
        if yards >= 1760 then return ("%.2f mi"):format(yards / 1760) end
        return ("%d yd"):format(math.floor(yards + 0.5))
    end
    if units == "KILOMETERS" or (units == "METRIC" and meters >= 1000) then
        return self.L.KILOMETERS:format(meters / 1000)
    end
    return self.L.METERS:format(math.floor(meters + 0.5))
end

function RP:FormatDuration(seconds)
    seconds = math.max(0, math.floor(seconds or 0))
    if seconds >= 3600 then
        return self.L.HOURS:format(math.floor(seconds / 3600), math.floor(seconds / 60) % 60)
    end
    return self.L.MINUTES:format(math.floor(seconds / 60), seconds % 60)
end

function RP:GetVectorXY(vector)
    if not vector then return nil end
    if type(vector.GetXY) == "function" then
        local ok, x, y = pcall(vector.GetXY, vector)
        if ok then return x, y end
    end
    return vector.x, vector.y
end

local bootstrap = CreateFrame("Frame")
bootstrap:RegisterEvent("ADDON_LOADED")
bootstrap:RegisterEvent("PLAYER_LOGIN")
bootstrap:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" and ... == addonName then
        if RP.Database then RP.Database:Initialize() end
        if RP.Localization then RP.Localization:Apply() end
        for _, module in pairs(RP.modules) do
            if module.OnInitialize then module:OnInitialize() end
        end
        RP.initialized = true
    elseif event == "PLAYER_LOGIN" then
        for _, module in pairs(RP.modules) do
            if module.OnLogin then module:OnLogin() end
        end
        RP.loggedIn = true
        RP:Fire("PLAYER_READY")
    end
end)

function PlanetOfArchaeology_AddonCompartmentClick(_, button)
    if button == "RightButton" and Settings and Settings.OpenToCategory and RP.Settings and RP.Settings.categoryID then
        Settings.OpenToCategory(RP.Settings.categoryID)
    elseif RP.MainFrame then
        RP.MainFrame:Toggle()
    end
end
