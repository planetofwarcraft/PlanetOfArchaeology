local _, RP = ...

local DigSites = { sites = {}, mapID = nil, continentMapID = nil }
RP:RegisterModule("DigSites", DigSites)

local function MapPosition(mapID, unit)
    if not C_Map or not C_Map.GetPlayerMapPosition then return nil end
    local ok, position = pcall(C_Map.GetPlayerMapPosition, mapID, unit)
    if ok then return position end
end

local function WorldPosition(mapID, position)
    if not C_Map or not C_Map.GetWorldPosFromMapPos or not position then return nil end
    local ok, continentID, world = pcall(C_Map.GetWorldPosFromMapPos, mapID, position)
    if not ok or not world then return nil end
    local x, y = RP:GetVectorXY(world)
    if type(x) ~= "number" or type(y) ~= "number" then return nil end
    return continentID, x, y, world
end

-- Cities may not expose the player's position on the continent map. Convert
-- the position from the current city/floor instead; never mix world instances.
function DigSites:GetPlayerWorldPosition(preferredMapID)
    local continent, x, y = WorldPosition(preferredMapID, MapPosition(preferredMapID, "player"))
    if x then return continent, x, y end
    for _, mapID in ipairs(self:GetMapChain()) do
        if mapID ~= preferredMapID then
            continent, x, y = WorldPosition(mapID, MapPosition(mapID, "player"))
            if x then return continent, x, y end
        end
    end
end

function DigSites:GetMapChain()
    local chain = {}
    if not C_Map or not C_Map.GetBestMapForUnit then return chain end
    local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
    if not ok then return chain end
    local seen = {}
    while mapID and mapID > 0 and not seen[mapID] and #chain < 8 do
        seen[mapID] = true
        chain[#chain + 1] = mapID
        local infoOK, info = pcall(C_Map.GetMapInfo, mapID)
        if infoOK and info and Enum and Enum.UIMapType and info.mapType == Enum.UIMapType.Continent then
            break
        end
        mapID = infoOK and info and info.parentMapID or nil
    end
    return chain
end

function DigSites:GetRawSites(mapID)
    if not C_ResearchInfo or type(C_ResearchInfo.GetDigSitesForMap) ~= "function" then return {} end
    local ok, sites = pcall(C_ResearchInfo.GetDigSitesForMap, mapID)
    if not ok or type(sites) ~= "table" then return {} end
    return sites
end

function DigSites:Refresh(reason)
    wipe(self.sites)
    self.mapID = nil
    self.continentMapID = nil

    local bestMapID, bestRaw, bestReachable = nil, {}, -1
    local chain = self:GetMapChain()
    for i = 1, #chain do
        local mapID = chain[i]
        local raw = self:GetRawSites(mapID)
        if #raw > 0 then
            local player = MapPosition(mapID, "player")
            local reachable = player and #raw or 0
            if #raw > #bestRaw or (#raw == #bestRaw and reachable > bestReachable) then
                bestMapID, bestRaw, bestReachable = mapID, raw, reachable
            end
        end
    end

    if not bestMapID and chain[1] then
        bestMapID, bestRaw = chain[1], self:GetRawSites(chain[1])
    end
    self.mapID = bestMapID
    for i = 1, #chain do
        if RP.DigSiteRaceDB and RP.DigSiteRaceDB[chain[i]] then
            self.continentMapID = chain[i]
            break
        end
    end

    -- A continent overview need not expose every active zone marker. Merge
    -- live zone results by site ID; retain each marker's coordinate map.
    local entries, seen = {}, {}
    local function AddSites(mapID, rawSites)
        for _, raw in ipairs(rawSites) do
            local x, y = RP:GetVectorXY(raw.position)
            if raw.researchSiteID and type(x) == "number" and type(y) == "number"
                and not seen[raw.researchSiteID] then
                seen[raw.researchSiteID] = true
                entries[#entries + 1] = { raw = raw, mapID = mapID }
            end
        end
    end
    AddSites(bestMapID, bestRaw)
    local continentMapID = self.continentMapID
    if continentMapID and C_Map and type(C_Map.GetMapChildrenInfo) == "function" then
        local ok, zones = pcall(C_Map.GetMapChildrenInfo, continentMapID, Enum.UIMapType.Zone, true)
        if ok and type(zones) == "table" then
            for _, zone in ipairs(zones) do
                if zone.mapID and zone.mapID ~= bestMapID then
                    AddSites(zone.mapID, self:GetRawSites(zone.mapID))
                end
            end
        end
    end
    self.mapID = continentMapID or bestMapID

    local playerContinent, playerWorldX, playerWorldY = self:GetPlayerWorldPosition(bestMapID)

    for i = 1, #entries do
        local raw, siteMapID = entries[i].raw, entries[i].mapID
        local playerPosition = MapPosition(siteMapID, "player")
        local x, y = RP:GetVectorXY(raw.position)
        if type(x) == "number" and type(y) == "number" then
            local continentID, worldX, worldY, worldVector = WorldPosition(siteMapID, raw.position)
            local site = {
                researchSiteID = raw.researchSiteID,
                position = raw.position,
                x = x,
                y = y,
                name = raw.name,
                poiBlobID = raw.poiBlobID,
                textureIndex = raw.textureIndex,
                mapID = siteMapID,
                continentID = continentID,
                worldX = worldX,
                worldY = worldY,
                worldVector = worldVector,
            }

            if playerWorldX and worldX and continentID == playerContinent then
                local dx, dy = worldX - playerWorldX, worldY - playerWorldY
                site.distance = math.sqrt(dx * dx + dy * dy)
            elseif playerPosition then
                local px, py = RP:GetVectorXY(playerPosition)
                if px and C_Map.GetMapWorldSize then
                    local sizeOK, width, height = pcall(C_Map.GetMapWorldSize, siteMapID)
                    if sizeOK and width and height then
                        local dx, dy = (x - px) * width, (y - py) * height
                        site.distance = math.sqrt(dx * dx + dy * dy)
                    end
                end
            end

            local mapRaces = RP.DigSiteRaceDB and RP.DigSiteRaceDB[self.continentMapID]
            local staticRaceIndex = mapRaces and mapRaces[site.name]
            if staticRaceIndex then
                local race = RP.Archaeology:GetRace(staticRaceIndex)
                if not race and type(GetArchaeologyRaceInfo) == "function" then
                    local raceOK, raceName, raceTexture = pcall(GetArchaeologyRaceInfo, staticRaceIndex, false)
                    if raceOK and raceName and raceName ~= UNKNOWN then
                        race = { index = staticRaceIndex, name = raceName, texture = raceTexture }
                    end
                end
                site.raceIndex = staticRaceIndex
                site.raceName = race and race.name or nil
                site.raceTexture = race and race.texture or nil
                site.raceSource = "database"
            end

            local branchID = RP.db.learnedSiteRaces[tostring(site.researchSiteID)]
            if branchID then
                local race = RP.Archaeology:GetRaceByBranchID(branchID)
                site.branchID = branchID
                site.raceIndex = race and race.index or site.raceIndex
                site.raceName = race and race.name or nil
                site.raceTexture = race and race.texture or nil
                site.raceSource = "observed"
            end
            self.sites[#self.sites + 1] = site
        end
    end

    table.sort(self.sites, function(a, b)
        return (a.distance or math.huge) < (b.distance or math.huge)
    end)

    RP:Debug("Refresh sites (%s): uiMapID=%s continentMapID=%s count=%d", tostring(reason), tostring(self.mapID), tostring(self.continentMapID), #self.sites)
    for i = 1, #self.sites do
        local site = self.sites[i]
        RP:Debug("site[%d] id=%s texture=%s name=%s x=%.4f y=%.4f race=%s source=%s distance=%s", i,
            tostring(site.researchSiteID), tostring(site.textureIndex), tostring(site.name), site.x, site.y,
            tostring(site.raceName or "Unknown"), tostring(site.raceSource or "none"), tostring(site.distance))
    end
    RP:Fire("DIG_SITES_UPDATED", self.sites, reason)
    return self.sites
end

function DigSites:GetSiteByID(researchSiteID)
    for i = 1, #self.sites do
        if self.sites[i].researchSiteID == researchSiteID then return self.sites[i] end
    end
end

function DigSites:GetNearestSite()
    local nearest, distance
    for i = 1, #self.sites do
        local site = self.sites[i]
        if site.distance and (not distance or site.distance < distance) then
            nearest, distance = site, site.distance
        end
    end
    return nearest, distance
end

function DigSites:GetCurrentSite()
    if type(CanScanResearchSite) ~= "function" then return nil end
    local scanOK, canScan = pcall(CanScanResearchSite)
    if not scanOK or not canScan then return nil end
    self:UpdateDistances()
    local site, distance = self:GetNearestSite()
    -- CanScanResearchSite is Blizzard's authoritative inside-site check. The
    -- map marker may sit far from the edge of a large dig-site polygon.
    if site then return site, distance end
    return nil
end

function DigSites:LearnCurrentSite(branchID)
    if not branchID then return end
    local canScan = type(CanScanResearchSite) == "function" and CanScanResearchSite()
    if not canScan then return end

    self:Refresh("race-observation")
    local site, distance = self:GetNearestSite()
    if site then
        RP.db.learnedSiteRaces[tostring(site.researchSiteID)] = branchID
        local race = RP.Archaeology:GetRaceByBranchID(branchID)
        site.branchID = branchID
        site.raceIndex = race and race.index or site.raceIndex
        site.raceName = race and race.name or nil
        site.raceTexture = race and race.texture or nil
        RP:Debug("Learned site %s -> branch %s (%s)", tostring(site.researchSiteID), tostring(branchID), tostring(site.raceName))
        RP:Fire("DIG_SITES_UPDATED", self.sites, "race-learned")
    end
end

function DigSites:UpdateDistances()
    if not self.mapID then return end
    local playerContinent, px, py = self:GetPlayerWorldPosition(self.mapID)
    for i = 1, #self.sites do
        local site = self.sites[i]
        site.distance = nil
        if px and site.worldX and site.continentID == playerContinent then
            local dx, dy = site.worldX - px, site.worldY - py
            site.distance = math.sqrt(dx * dx + dy * dy)
        end
    end
end

function DigSites:OnLogin()
    C_Timer.After(1, function() self:Refresh("login") end)
end
