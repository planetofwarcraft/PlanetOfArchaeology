local _, RP = ...
local lockedRaces = { enUS = "Not unlocked", ruRU = "Не открыто", ukUA = "Не відкрито", deDE = "Gesperrt", frFR = "Non débloqué", esES = "Sin desbloquear", esMX = "Sin desbloquear", itIT = "Non sbloccato", ptBR = "Não desbloqueado", koKR = "미해금", zhCN = "未解锁", zhTW = "未解鎖" }
for locale, text in pairs(lockedRaces) do RP.locales[locale].RACE_NOT_UNLOCKED = text end
local exclusions = {
    enUS = {"Dig sites hidden by exclusions: %d. Nearest mode still respects exclusions.", "Remove exclusions"},
    ruRU = {"Раскопки скрыты исключениями: %d. Режим «Ближайшая» не отменяет исключения.", "Снять исключения"},
    ukUA = {"Розкопки приховано винятками: %d. Режим «Найближча» не скасовує винятки.", "Зняти винятки"},
    deDE = {"Durch Ausschlüsse ausgeblendete Grabungsstätten: %d. Auch die Suche nach dem nächsten Ziel beachtet Ausschlüsse.", "Ausschlüsse aufheben"},
    frFR = {"Sites masqués par les exclusions : %d. Le mode le plus proche respecte aussi les exclusions.", "Retirer les exclusions"},
    esES = {"Excavaciones ocultas por exclusiones: %d. El modo más cercano también respeta las exclusiones.", "Quitar exclusiones"},
    esMX = {"Excavaciones ocultas por exclusiones: %d. El modo más cercano también respeta las exclusiones.", "Quitar exclusiones"},
    itIT = {"Siti nascosti dalle esclusioni: %d. Anche la modalità più vicina rispetta le esclusioni.", "Rimuovi esclusioni"},
    ptBR = {"Escavações ocultas por exclusões: %d. O modo mais próximo também respeita as exclusões.", "Remover exclusões"},
    koKR = {"제외 설정으로 숨겨진 발굴지: %d. 가장 가까운 대상 모드에서도 제외 설정이 적용됩니다.", "제외 해제"},
    zhCN = {"因排除设置而隐藏的挖掘场：%d。最近目标模式仍会遵循排除设置。", "取消排除"},
    zhTW = {"因排除設定而隱藏的挖掘場：%d。最近目標模式仍會遵循排除設定。", "取消排除"},
}
for locale, values in pairs(exclusions) do
    RP.locales[locale].ROUTE_HIDDEN = values[1]
    RP.locales[locale].ROUTE_CLEAR_EXCLUSIONS = values[2]
end
local help = {
    enUS = {"Minimap: left click — journal; right click — expedition menu; middle click — next available dig site.", "Route: click a dig site to select it. The check marks your target; the arrow shows its direction.", "Windows: drag to move; drag the bottom corner to resize. Docking and scale are in Settings."},
    ruRU = {"Мини-карта: ЛКМ — журнал; ПКМ — меню экспедиции; СКМ — следующие доступные раскопки.", "Маршрут: нажмите на раскопки для выбора. Галочка — ваша цель; стрелка — направление к ней.", "Окна: перетаскивайте для перемещения; тяните нижний угол для масштаба. Привязка и масштаб — в настройках."},
    ukUA = {"Мінікарта: ЛКМ — журнал; ПКМ — меню експедиції; СКМ — наступні доступні розкопки.", "Маршрут: натисніть на розкопки для вибору. Позначка — ваша ціль; стрілка — напрямок до неї.", "Вікна: перетягуйте для переміщення; тягніть нижній кут для масштабу. Прив’язування й масштаб — у налаштуваннях."},
    deDE = {"Minikarte: Linksklick — Journal; Rechtsklick — Expeditionsmenü; Mittelklick — nächste Grabungsstätte.", "Route: Grabungsstätte anklicken. Haken: Ziel. Pfeil: Richtung.", "Fenster zum Verschieben ziehen; untere Ecke zum Skalieren ziehen. Andocken und Größe in den Einstellungen."},
    frFR = {"Minicarte : clic gauche — journal ; droit — menu ; milieu — site de fouilles suivant.", "Itinéraire : cliquez sur un site. Coche : votre cible. Flèche : sa direction.", "Déplacez les fenêtres en les faisant glisser ; tirez le coin inférieur pour les redimensionner. Ancrage et échelle dans les paramètres."},
    itIT = {"Minimappa: clic sinistro — diario; destro — menu; centrale — prossimo sito di scavo.", "Percorso: clicca un sito. Spunta: obiettivo. Freccia: direzione.", "Trascina le finestre per spostarle e l’angolo inferiore per ridimensionarle. Ancoraggio e scala nelle impostazioni."},
    esES = {"Minimapa: clic izquierdo — diario; derecho — menú; central — siguiente excavación.", "Ruta: pulsa una excavación. Marca: objetivo. Flecha: dirección.", "Arrastra las ventanas para moverlas y la esquina inferior para cambiar su tamaño. Acoplamiento y escala en ajustes."},
    esMX = {"Minimapa: clic izquierdo — diario; derecho — menú; central — siguiente excavación.", "Ruta: selecciona una excavación. Marca: objetivo. Flecha: dirección.", "Arrastra las ventanas para moverlas y la esquina inferior para cambiar su tamaño. Acoplamiento y escala en ajustes."},
    ptBR = {"Minimapa: clique esquerdo — diário; direito — menu; central — próxima escavação.", "Rota: clique em uma escavação. Marca: alvo. Seta: direção.", "Arraste as janelas para mover e o canto inferior para redimensionar. Acoplamento e escala nas configurações."},
    koKR = {"미니맵: 왼쪽 클릭 — 일지; 오른쪽 — 탐험 메뉴; 가운데 — 다음 발굴지.", "경로: 발굴지를 클릭하여 선택하세요. 체크는 목표, 화살표는 방향입니다.", "창을 끌어 이동하고 아래 모서리를 끌어 크기를 조절하세요. 창 연결과 배율은 설정에서 변경합니다."},
    zhCN = {"小地图：左键打开日志；右键打开探险菜单；中键选择下一个挖掘场。", "路线：点击挖掘场以选择。勾号表示目标，箭头表示方向。", "拖动窗口以移动，拖动下角以缩放。可在设置中调整窗口连接和缩放。"},
    zhTW = {"小地圖：左鍵開啟日誌；右鍵開啟探險選單；中鍵選擇下一個挖掘場。", "路線：點擊挖掘場以選擇。勾號表示目標，箭頭表示方向。", "拖曳視窗以移動，拖曳下角以縮放。可在設定中調整視窗連結和縮放。"},
}
for locale, values in pairs(help) do
    for i, key in ipairs({"HELP_MINIMAP", "HELP_ROUTE", "HELP_WINDOWS"}) do RP.locales[locale][key] = values[i] end
end
local about = {
    enUS = {"About", "Search achievements…", "An archaeology companion by Planet of Warcraft. Research artifacts, plan expeditions and track achievements.", "Select the link and press Ctrl+C to copy it, then paste it into your browser."},
    ruRU = {"Об аддоне", "Поиск достижений…", "Археологический помощник от Planet of Warcraft. Изучайте артефакты, планируйте экспедиции и отслеживайте достижения.", "Выделите ссылку и нажмите Ctrl+C, затем вставьте её в браузер."},
    ukUA = {"Про аддон", "Пошук досягнень…", "Археологічний помічник від Planet of Warcraft. Досліджуйте артефакти, плануйте експедиції та відстежуйте досягнення.", "Виділіть посилання й натисніть Ctrl+C, а потім вставте його в браузер."},
    deDE = {"Über", "Erfolge suchen…", "Dein Archäologiehelfer von Planet of Warcraft. Erforsche Artefakte, plane Expeditionen und verfolge Erfolge.", "Link markieren, mit Strg+C kopieren und im Browser einfügen."},
    frFR = {"À propos", "Rechercher un haut fait…", "Un compagnon d’archéologie par Planet of Warcraft. Étudiez les artéfacts, planifiez vos expéditions et suivez vos hauts faits.", "Sélectionnez le lien, copiez-le avec Ctrl+C, puis collez-le dans votre navigateur."},
    itIT = {"Informazioni", "Cerca imprese…", "Un assistente di archeologia di Planet of Warcraft. Studia manufatti, pianifica spedizioni e segui le imprese.", "Seleziona il collegamento, premi Ctrl+C e incollalo nel browser."},
    esES = {"Acerca de", "Buscar logros…", "Un asistente de arqueología de Planet of Warcraft. Investiga artefactos, planifica expediciones y sigue tus logros.", "Selecciona el enlace, pulsa Ctrl+C y pégalo en tu navegador."},
    esMX = {"Acerca de", "Buscar logros…", "Un asistente de arqueología de Planet of Warcraft. Investiga artefactos, planea expediciones y sigue tus logros.", "Selecciona el enlace, presiona Ctrl+C y pégalo en tu navegador."},
    ptBR = {"Sobre", "Buscar conquistas…", "Um assistente de arqueologia de Planet of Warcraft. Pesquise artefatos, planeje expedições e acompanhe conquistas.", "Selecione o link, pressione Ctrl+C e cole no navegador."},
    koKR = {"정보", "업적 검색…", "Planet of Warcraft의 고고학 도우미입니다. 유물을 연구하고 탐험을 계획하며 업적을 추적하세요.", "링크를 선택하고 Ctrl+C로 복사한 다음 브라우저에 붙여넣으세요."},
    zhCN = {"关于", "搜索成就…", "Planet of Warcraft 制作的考古助手。研究文物、规划探险并追踪成就。", "选中链接，按 Ctrl+C 复制，然后粘贴到浏览器中。"},
    zhTW = {"關於", "搜尋成就…", "Planet of Warcraft 製作的考古助手。研究文物、規劃探險並追蹤成就。", "選取連結，按 Ctrl+C 複製，再貼到瀏覽器中。"},
}
for locale, values in pairs(about) do
    local L = RP.locales[locale]
    L.ADDON_NAME = "Planet of Archaeology"
    for i, key in ipairs({"ABOUT_ADDON", "SEARCH_ACHIEVEMENTS", "ABOUT_DESCRIPTION", "COPY_CHANNEL_LINK"}) do L[key] = values[i] end
end
local translations = {
    enUS = {"Reset interface", "Automatic (client locale)", "Metric: m / km", "Imperial: yd / mi"},
    ruRU = {"Сбросить настройки интерфейса", "Авто (язык клиента)", "Метрические: м / км", "Имперские: ярды / мили"},
    ukUA = {"Скинути налаштування інтерфейсу", "Авто (мова клієнта)", "Метричні: м / км", "Імперські: ярди / милі"},
    deDE = {"Oberfläche zurücksetzen", "Automatisch (Client-Sprache)", "Metrisch: m / km", "Imperial: yd / mi"},
    frFR = {"Réinitialiser l’interface", "Auto (langue du client)", "Métrique : m / km", "Impérial : yd / mi"},
    itIT = {"Ripristina interfaccia", "Auto (lingua del client)", "Metriche: m / km", "Imperiali: yd / mi"},
    esES = {"Restablecer interfaz", "Auto (idioma del cliente)", "Métricas: m / km", "Imperiales: yd / mi"},
    esMX = {"Restablecer interfaz", "Auto (idioma del cliente)", "Métricas: m / km", "Imperiales: yd / mi"},
    ptBR = {"Redefinir interface", "Auto (idioma do cliente)", "Métricas: m / km", "Imperiais: yd / mi"},
    koKR = {"인터페이스 초기화", "자동 (클라이언트 언어)", "미터법: m / km", "야드·마일: yd / mi"},
    zhCN = {"重置界面设置", "自动（客户端语言）", "公制：米 / 千米", "英制：码 / 英里"},
    zhTW = {"重設介面設定", "自動（用戶端語言）", "公制：公尺 / 公里", "英制：碼 / 英里"},
}
for locale, values in pairs(translations) do
    local L = RP.locales[locale]
    for i, key in ipairs({"RESET_INTERFACE", "UNITS_AUTOMATIC", "UNITS_METRIC", "UNITS_IMPERIAL"}) do
        L[key] = values[i]
    end
end
